package com.navigine.sdk;

import android.content.Context;
import android.os.Build;
import android.util.Log;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class NativeLibLoader
{
    public static boolean sNativeLibraryLoaded = false;

    public static synchronized boolean loadLibrary(String libraryName) {
        try {
            System.loadLibrary("c++_shared");
            System.loadLibrary(libraryName);
            sNativeLibraryLoaded = true;
            return true;
        } catch (final SecurityException | UnsatisfiedLinkError | NullPointerException e) {
            Log.e("NAVIGINE_LOG", "Failed to load native navigine libraries", e);
            return false;
        }
    }
}
