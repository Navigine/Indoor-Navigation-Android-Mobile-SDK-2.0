package com.navigine.common;

import java.util.WeakHashMap;
import java.util.Map;

/**
 * Class providing weak subscription.
 * Subscribed listeners will be auto unsubscribed
 * and then they will be garbage collected.
 * @hidden
 */
public abstract class Subscription<Listener> {
    /**
     * Subscribes listener if not subscribed.
     * @return listener's NativeObject or null if listener itself is null.
     */
    public NativeObject get(Listener listener) {
        if (listener == null) {
            return null;
        }
        NativeObject nativeObject = storage.get(listener);
        if (nativeObject == null) {
            nativeObject = createNativeListener(listener);
            storage.put(listener, nativeObject);
        }
        return nativeObject;
    }

    /**
     * Abstract method to create native listener.
     */
    public abstract NativeObject createNativeListener(Listener listener);

    protected final Map<Listener, NativeObject> storage =
       new WeakHashMap<Listener, NativeObject>();
}
