package com.navigine.common;

import android.os.Handler;
import android.os.Looper;

/// @cond EXCLUDE
public final class NativeObject {
    private static final class Cleaner implements Runnable {
        public Cleaner(long nativeObject) {
           this.nativeObject = nativeObject;
        }

        @Override
        public void run() {
            deleteNative(nativeObject);
        }

        private final long nativeObject;
    }

    public NativeObject(long nativeObject) {
        this.nativeObject = nativeObject;
    }

    public boolean isEmpty() {
        return nativeObject == 0L;
    }

    public long release() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            throw new IllegalStateException(
                "Cannot release native object outside the UI thread");
        }

        long result = nativeObject;
        nativeObject = 0L;
        return result;
    }

    public void reset() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            throw new IllegalStateException(
                "Cannot reset native object outside the UI thread");
        }

        deleteNative(nativeObject);
        nativeObject = 0L;
    }

    @Override
    public void finalize() throws Throwable {
        // Could be called twice from unit tests (once manually, once by GC).
        if (isEmpty()) {
            return;
        }

        new Handler(Looper.getMainLooper())
            .post(new Cleaner(nativeObject));
        nativeObject = 0L;
    }

    private static native void deleteNative(long nativeObject);

    private long nativeObject;
}
/// @endcond