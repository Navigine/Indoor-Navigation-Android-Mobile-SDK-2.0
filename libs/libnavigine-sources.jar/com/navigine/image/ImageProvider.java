package com.navigine.image;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.Log;

import androidx.core.content.ContextCompat;

import java.util.UUID;
import java.io.InputStream;
import java.io.IOException;

/**
 * Provides {@link Bitmap} objects from different input sources. Extend this class to provide images from
 * custom sources.
 */
public abstract class ImageProvider {
    private final boolean cacheable;

    public ImageProvider() {
        this(true);
    }
    public ImageProvider(final boolean cacheable) {
        this.cacheable = cacheable;
    }

    /**
     * Determines whether image should be cached on GPU or not.
     */
    public boolean isCacheable() {
        return cacheable;
    }

    /**
     * Returns the unique identifier for an image. Providers can be cached based on it.
     */
    public abstract String getId();

    /**
     * Returns the image in bitmap format.
     */
    public abstract Bitmap getImage();

    private static abstract class ImageProviderImpl extends ImageProvider {
        private final String id;

        public ImageProviderImpl(final String id, final boolean cacheable) {
            super(cacheable);
            this.id = id;
        }

        @Override
        public String getId() { return id; }

        @Override
        public Bitmap getImage() {
            return loadBitmap();
        }

        protected abstract Bitmap loadBitmap();
    }

    public static ImageProvider fromBitmap(final Bitmap bitmap) {
        return fromBitmap(bitmap, true, "bitmap:" + UUID.randomUUID().toString());
    }

    /**
     * Returns the image provider based on a given bitmap.
     */
    public static ImageProvider fromBitmap(final Bitmap bitmap, final boolean cacheable, final String id) {
        if (bitmap.getConfig() != Bitmap.Config.ARGB_8888) {
            throw new IllegalArgumentException("Bitmap config value should be ARGB_8888");
        }

        return new ImageProvider(cacheable) {
            @Override
            public String getId() { return id; }

            @Override
            public Bitmap getImage() { return bitmap; }
        };
    }

    public static ImageProvider fromAsset(final Context context, final String assetName) {
        return fromAsset(context, assetName, true);
    }

    /**
     * Returns the image provider based on a given asset (from the assets/ folder).
     */
    public static ImageProvider fromAsset(final Context context, final String assetName, final boolean cacheable) {
        final AssetManager assetManager = context.getAssets();
        return new ImageProviderImpl("asset:" + assetName, cacheable) {
            @Override
            protected Bitmap loadBitmap() {
                Bitmap result = null;
                try {
                    InputStream i = assetManager.open(assetName);
                    try {
                        result = BitmapFactory.decodeStream(i);
                    } finally {
                        i.close();
                    }
                } catch (IOException ex) {
                    Log.e("navigine", "Can't load image from asset: " + assetName, ex);
                }
                return result;
            }
        };
    }

    public static ImageProvider fromResource(final Context context, final int resourceId) {
        return fromResource(context, resourceId, true);
    }
    /**
     * Returns the image provider based on an application resource (from the res/ folder).
     */
    public static ImageProvider fromResource(Context context, final int resourceId, boolean cacheable) {
        return new ImageProviderImpl("resource:" + resourceId, cacheable) {
            protected Bitmap loadBitmap() {
                Drawable drawable = ContextCompat.getDrawable(context, resourceId);
                if (drawable == null) {
                    return null;
                }

                Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(bitmap);
                drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
                drawable.draw(canvas);
                return bitmap;
            }
        };
    }

    public static ImageProvider fromFile(final String fileName) {
        return fromFile(fileName, true);
    }

    /**
     * Returns the image provider based on an image file from the internal storage.
     */
    public static ImageProvider fromFile(final String fileName, final boolean cacheable) {
        return new ImageProviderImpl("file:" + fileName, cacheable) {
            @Override
            protected Bitmap loadBitmap() {
                return BitmapFactory.decodeFile(fileName);
            }
        };
    }
}
