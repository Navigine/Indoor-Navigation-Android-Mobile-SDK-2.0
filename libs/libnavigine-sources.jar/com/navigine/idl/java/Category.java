package com.navigine.idl.java;

/**
 * class is used for storing venue categories.
 * Referenced from {@link com.navigine.idl.java.Location Location} {@link com.navigine.idl.java.Venue Venue}.
 */
public final class Category {


    /*package*/ final int id;

    /*package*/ final String name;

    /*package*/ final String imageUrl;

    /**
     * Default constructor for class Category
     */
    public Category(
            int id,
            String name,
            String imageUrl) {
        this.id = id;
        this.name = name;
        this.imageUrl = imageUrl;
    }

    /**
     * category identifier.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get category ID
     * int categoryId = category.getId();
     * System.out.println("Category ID: " + categoryId);
     * }
     * </pre>
     * @return category identifier.
     */
    public int getId() {
        return id;
    }

    /**
     * category name.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get category name
     * String categoryName = category.getName();
     * System.out.println("Category name: " + categoryName);
     * }
     * </pre>
     * @return category name.
     */
    public String getName() {
        return name;
    }

    /**
     * image source. If presented.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get category image URL
     * String imageUrl = category.getImageUrl();
     * if (imageUrl != null) {
     *    System.out.println("Category image URL: " + imageUrl);
     * }
     * }
     * </pre>
     * @return image source. If presented.
     */
    public String getImageUrl() {
        return imageUrl;
    }

    @Override
    public String toString() {
        return "Category{" +
                "id=" + id +
                "," + "name=" + name +
                "," + "imageUrl=" + imageUrl +
        "}";
    }

}
