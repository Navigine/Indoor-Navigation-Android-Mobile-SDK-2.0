package com.navigine.idl.java;

import com.navigine.common.NativeObject;
import com.navigine.common.Subscription;

public abstract class LocationEditManager {
    public abstract void addBeacon(int subLocId, String uuid, int major, int minor, Point point, String name, Integer power);

    public abstract void editBeacon(int subLocId, String uuid, int major, int minor, Point point, String name, Integer power);

    public abstract void removeBeacon(int subLocId, String uuid, int major, int minor);

    public abstract void addEddystone(int subLocId, String namespaceId, String instanceId, Point point, String name, Integer power);

    public abstract void editEddystone(int subLocId, String namespaceId, String instanceId, Point point, String name, Integer power);

    public abstract void removeEddystone(int subLocId, String namespaceId, String instanceId);

    public abstract void addWifi(int subLocId, String mac, Point point, String name);

    public abstract void editWifi(int subLocId, String mac, Point point, String name);

    public abstract void removeWifi(int subLocId, String mac);

    public abstract void addWifiRtt();

    public abstract void editWifiRtt();

    public abstract void removeWifiRtt(int subLocId, String mac);

    public abstract void addLocationEditListener(LocationEditListener locationEditListener);

    public abstract void removeLocationEditListener(LocationEditListener locationEditListener);
}
