package com.navigine.idl.java;

/**
 * Enum described animation functions.
 * Referenced from {@link com.navigine.idl.java.CircleMapObject CircleMapObject}, {@link com.navigine.idl.java.IconMapObject IconMapObject}, {@link com.navigine.idl.java.LocationWindow LocationWindow}.
 *
 * <p><b>Example:</b></p>
 * <pre>
 * {@code
 * AnimationType[] animationTypes = {
 *    AnimationType.LINEAR,
 *    AnimationType.CUBIC,
 *    AnimationType.QUINT,
 *    AnimationType.SINE,
 *    AnimationType.NONE,
 * };
 * }
 * </pre>
 */
public enum AnimationType {
    /**
     * disable animation
     */
    NONE,
    /**
     * animation according to formula `f(t) = t`.
     */
    LINEAR,
    /**
     * animation according to formula `f(t) = (-2 * t + 3) * t * t`.
     */
    CUBIC,
    /**
     * animation according to formula `f(t) = (6 * t * t - 15 * t + 10) * t * t * t`.
     */
    QUINT,
    /**
     * animation according to formula `f(t) = 0.5 - 0.5 * cos(PI * t)`.
     */
    SINE,
    ;
}
