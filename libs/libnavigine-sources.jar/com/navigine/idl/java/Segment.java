package com.navigine.idl.java;

/**
 * line between two points.
 *
 * <p><b>Example:</b></p>
 * <pre>
 * {@code
 * // Create segments
 * Segment segment1 = new Segment(start1, end1);
 * Segment segment2 = new Segment(start2, end2);
 * System.out.println("Created segments: S1((" + segment1.getStart().getX() + ", " + segment1.getStart().getY() +
 *                  ") -> (" + segment1.getEnd().getX() + ", " + segment1.getEnd().getY() +
 *                  ")), S2((" + segment2.getStart().getX() + ", " + segment2.getStart().getY() +
 *                  ") -> (" + segment2.getEnd().getX() + ", " + segment2.getEnd().getY() + "))");
 * }
 * </pre>
 */
public final class Segment {


    /*package*/ final Point start;

    /*package*/ final Point end;

    /**
     * Default constructor for class Segment
     */
    public Segment(
            Point start,
            Point end) {
        this.start = start;
        this.end = end;
    }

    /**
     * Start point of the segment.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get start point
     * Point segment1Start = segment1.getStart();
     * System.out.println("Segment1 start point: (" + segment1Start.getX() + ", " + segment1Start.getY() + ")");
     * }
     * </pre>
     * @return Start point of the segment.
     */
    public Point getStart() {
        return start;
    }

    /**
     * End point of the segment.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get end point
     * Point segment1End = segment1.getEnd();
     * System.out.println("Segment1 end point: (" + segment1End.getX() + ", " + segment1End.getY() + ")");
     * }
     * </pre>
     * @return End point of the segment.
     */
    public Point getEnd() {
        return end;
    }

    @Override
    public String toString() {
        return "Segment{" +
                "start=" + start +
                "," + "end=" + end +
        "}";
    }

}
