package com.navigine.idl.java;

/**
 * Class is used for getting bitmaps (png, jpg, svg) from byte array.
 */
public abstract class BitmapRegionDecoder {
    /**
     * Method is used to decode rectangle region in the image specified by rect.
     * @param rect area to render {@link com.navigine.idl.java.Rectangle Rectangle}
     * @param sampleSize if set to a value > 1, requests the decoder to subsample the original image, returning a smaller image to save memory.
     * @return constructed bitmap
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Decode region with sample size 1 (full resolution)
     * ImageWrapper decodedImage = decoder.decodeRegion(sampleRect, 1);
     * System.out.println("Decoded region: " + sampleRect.getWidth() + "x" + sampleRect.getHeight() + " at sample size 1");
     * }
     * </pre>
     */
    public abstract android.graphics.Bitmap decodeRegion(Rectangle rect, float sampleSize);

    /**
     * Width of the source image in pixels (after header parse / decode metadata).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * int sourceWidth = decoder.getWidth();
     * System.out.println("Source image width: " + sourceWidth);
     * }
     * </pre>
     * @return Width of the source image in pixels (after header parse / decode metadata).
     */
    public abstract int getWidth();

    /**
     * Height of the source image in pixels (after header parse / decode metadata).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * int sourceHeight = decoder.getHeight();
     * System.out.println("Source image height: " + sourceHeight);
     * }
     * </pre>
     * @return Height of the source image in pixels (after header parse / decode metadata).
     */
    public abstract int getHeight();

    /**
     * Tells if this {@link BitmapRegionDecoder} is valid or not. Any other method
     * (except for this one) called on an invalid {@link BitmapRegionDecoder} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();

    /**
     * Method is used to create instance of BitmapRegionDecoder
     * @param data raw image data (could be raw svg string)
     * @return instance of decoder, which could be used for decoding byte array to bitmap.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Create new instance of BitmapRegionDecoder
     * decoder = BitmapRegionDecoder.newInstance(imageData);
     * System.out.println("Created BitmapRegionDecoder instance");
     * }
     * </pre>
     */
    public static BitmapRegionDecoder newInstance(byte[] data)
    {
        return com.navigine.idl.java.internal.BitmapRegionDecoderBinding.newInstance(data);
    }

    /**
     * Creates decoder from {@link com.navigine.idl.java.Image Image} without copying raw bytes again.
     * @param data image instance (e.g. from SDK pipeline); must remain valid while decoder is used
     * @return decoder instance or null on error
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // When you already have an Image (e.g. from SDK), create decoder without passing raw bytes again
     * Image imageForDecoder = null; // set from your pipeline when available
     * BitmapRegionDecoder decoderFromImage = BitmapRegionDecoder.newInstanceFromImage(imageForDecoder);
     * System.out.println("Decoder from Image: " + (decoderFromImage != null));
     * }
     * </pre>
     */
    public static BitmapRegionDecoder newInstanceFromImage(Image data)
    {
        return com.navigine.idl.java.internal.BitmapRegionDecoderBinding.newInstanceFromImage(data);
    }
}
