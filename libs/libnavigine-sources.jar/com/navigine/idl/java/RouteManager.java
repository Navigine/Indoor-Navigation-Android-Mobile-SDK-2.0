package com.navigine.idl.java;

import com.navigine.platform.NativeObject;
import com.navigine.platform.Subscription;
import java.util.ArrayList;

/**
 * Class is used for evaluating {@link com.navigine.idl.java.RoutePath RoutePath} from point to point.
 * Referenced from {@link com.navigine.idl.java.NavigineSdk NavigineSdk}.
 */
public abstract class RouteManager {
    /**
     * Method is used to build a route between points
     * about evaluated {@link com.navigine.idl.java.RoutePath RoutePath} from your position to target point.
     * @param from starting {@link com.navigine.idl.java.LocationPoint LocationPoint}.
     * @param to destination {@link com.navigine.idl.java.LocationPoint LocationPoint}.
     * @return {@link com.navigine.idl.java.RoutePath RoutePath} from starting to destination point.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Make route from point to point
     * RoutePath routePath = routeManager.makeRoute(startLocationPoint, endLocationPoint);
     * System.out.println("Route created with length: " + routePath.getLength() + " meters");
     * }
     * </pre>
     */
    public abstract RoutePath makeRoute(LocationPoint from, LocationPoint to);

    /**
     * Method is used to build a route between the starting point and several destination points
     * @param from starting {@link com.navigine.idl.java.LocationPoint LocationPoint}.
     * @param to destination list of {@link com.navigine.idl.java.LocationPoint LocationPoint}s.
     * @return vector of {@link com.navigine.idl.java.RoutePath RoutePath}s from starting to destination point.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Make routes to multiple destinations
     * List<LocationPoint> destinations = new ArrayList<>();
     * destinations.add(new LocationPoint(new Point(30.0, 40.0), 12345, 1));
     * destinations.add(new LocationPoint(new Point(70.0, 80.0), 12345, 1));
     * List<RoutePath> routePaths = routeManager.makeRoutes(startLocationPoint, destinations);
     * System.out.println("Created " + routePaths.size() + " routes");
     * }
     * </pre>
     */
    public abstract ArrayList<RoutePath> makeRoutes(LocationPoint from, ArrayList<LocationPoint> to);

    /**
     * Method is used to set target point in your location.
     * Through {@link com.navigine.idl.java.RouteListener RouteListener} you will be notified about new paths to target point.
     * @param target finish {@link com.navigine.idl.java.LocationPoint LocationPoint}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set target point
     * routeManager.setTarget(endLocationPoint);
     * }
     * </pre>
     */
    public abstract void setTarget(LocationPoint target);

    /**
     * Method is used to add target point in your location.
     * Through {@link com.navigine.idl.java.RouteListener RouteListener} you will be notified about new paths to target point.
     * @param target finish {@link com.navigine.idl.java.LocationPoint LocationPoint}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Add additional target point
     * LocationPoint additionalTarget = new LocationPoint(new Point(90.0, 100.0), 12345, 1);
     * routeManager.addTarget(additionalTarget);
     * }
     * </pre>
     */
    public abstract void addTarget(LocationPoint target);

    /**
     * Method is used for removing current target points to where the routes were built.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Cancel current target
     * routeManager.cancelTarget();
     * }
     * </pre>
     */
    public abstract void cancelTarget();

    /**
     * Method is used for removing all target points to where the routes were built.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Clear all targets
     * routeManager.clearTargets();
     * }
     * </pre>
     */
    public abstract void clearTargets();

    /**
     * Method is used to select graph tag (Default: "default").
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set graph tag
     * routeManager.setGraphTag("main");
     * }
     * </pre>
     */
    public abstract void setGraphTag(String tag);

    /**
     * Method is used to get current graph tag (Default: "default").
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get current graph tag
     * String currentGraphTag = routeManager.getGraphTag();
     * System.out.println("Current graph tag: " + currentGraphTag);
     * }
     * </pre>
     */
    public abstract String getGraphTag();

    /**
     * Method is used to get all graph tags,
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get all graph tags
     * List<String> graphTags = routeManager.getGraphTags();
     * System.out.println("Available graph tags: " + graphTags);
     * }
     * </pre>
     */
    public abstract ArrayList<String> getGraphTags();

    /**
     * Method is used to add {@link com.navigine.idl.java.RouteListener RouteListener} class element
     * which will notify about evaluated route path from your position to target point.
     * <p><b>Note:</b> Do not forget to remove listener if it is no longer needed!</p>
     * @param listener Corresponding {@link com.navigine.idl.java.RouteListener RouteListener} class.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Add route listener
     * routeManager.addRouteListener(routeListener);
     * }
     * </pre>
     */
    public abstract void addRouteListener(RouteListener listener);

    /**
     * Method is used for removing previously added {@link com.navigine.idl.java.RouteListener RouteListener} class element.
     * @param listener Corresponding {@link com.navigine.idl.java.RouteListener RouteListener} class to remove.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove route listener
     * routeManager.removeRouteListener(routeListener);
     * }
     * </pre>
     */
    public abstract void removeRouteListener(RouteListener listener);
}
