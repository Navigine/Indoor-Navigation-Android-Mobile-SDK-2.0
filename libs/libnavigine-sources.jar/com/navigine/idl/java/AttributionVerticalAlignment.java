package com.navigine.idl.java;

/**
 * Vertical placement of the OSM attribution overlay.
 * Used with {@link com.navigine.idl.java.AttributionAlignment AttributionAlignment}.
 */
public enum AttributionVerticalAlignment {
    /**
     * Align to the top edge of the map.
     */
    TOP,
    /**
     * Align to the bottom edge of the map.
     */
    BOTTOM,
    ;
}
