package com.navigine.idl.java;

/**
 * General information about location
 * Referenced from: {@link com.navigine.idl.java.LocationListListener LocationListListener}, {@link com.navigine.idl.java.LocationListListener LocationListListener}
 */
public final class LocationInfo {


    /*package*/ final int id;

    /*package*/ final int version;

    /*package*/ final String name;

    /**
     * Default constructor for class LocationInfo
     */
    public LocationInfo(
            int id,
            int version,
            String name) {
        this.id = id;
        this.version = version;
        this.name = name;
    }

    /**
     * Unique location identifier.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get location ID
     * int id = locationInfo.getId();
     * System.out.println("Location ID: " + id);
     * }
     * </pre>
     * @return Unique location identifier.
     */
    public int getId() {
        return id;
    }

    /**
     * Current location version.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get location version
     * int version = locationInfo.getVersion();
     * System.out.println("Location version: " + version);
     * }
     * </pre>
     * @return Current location version.
     */
    public int getVersion() {
        return version;
    }

    /**
     * location name.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get location name
     * String name = locationInfo.getName();
     * System.out.println("Location name: " + name);
     * }
     * </pre>
     * @return location name.
     */
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "LocationInfo{" +
                "id=" + id +
                "," + "version=" + version +
                "," + "name=" + name +
        "}";
    }

}
