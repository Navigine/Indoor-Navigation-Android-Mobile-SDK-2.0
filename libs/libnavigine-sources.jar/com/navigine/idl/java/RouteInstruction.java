package com.navigine.idl.java;

/**
 * Next instruction for a guidance banner.
 * Built from the next {@link com.navigine.idl.java.RouteAnnotation RouteAnnotation} ahead of the
 * current route progress. {@code distance} is meters along the route, not a
 * straight-line chord. This is a pedestrian manoeuvre (no lanes, signs, or road
 * events).
 */
public final class RouteInstruction {


    /*package*/ final RouteAnnotationType type;

    /*package*/ final GlobalPoint point;

    /*package*/ final Integer sublocationId;

    /*package*/ final float distance;

    /*package*/ final String title;

    /**
     * Default constructor for class RouteInstruction
     */
    public RouteInstruction(
            RouteAnnotationType type,
            GlobalPoint point,
            Integer sublocationId,
            float distance,
            String title) {
        this.type = type;
        this.point = point;
        this.sublocationId = sublocationId;
        this.distance = distance;
        this.title = title;
    }

    /**
     * Annotation kind (transition, maneuver, finish, …).
     * @return Annotation kind (transition, maneuver, finish, …).
     */
    public RouteAnnotationType getType() {
        return type;
    }

    /**
     * Instruction point in WGS84.
     * @return Instruction point in WGS84.
     */
    public GlobalPoint getPoint() {
        return point;
    }

    /**
     * Floor id, or null when the instruction is outdoor.
     * @return Floor id, or null when the instruction is outdoor.
     */
    public Integer getSublocationId() {
        return sublocationId;
    }

    /**
     * Meters along the route from the current progress to this point.
     * @return Meters along the route from the current progress to this point.
     */
    public float getDistance() {
        return distance;
    }

    /**
     * Short label, when the annotation has one.
     * @return Short label, when the annotation has one.
     */
    public String getTitle() {
        return title;
    }

    @Override
    public String toString() {
        return "RouteInstruction{" +
                "type=" + type +
                "," + "point=" + point +
                "," + "sublocationId=" + sublocationId +
                "," + "distance=" + distance +
                "," + "title=" + title +
        "}";
    }

}
