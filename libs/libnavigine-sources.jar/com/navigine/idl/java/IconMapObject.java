package com.navigine.idl.java;

/**
 * Represents an icon object on the location view.
 * Referenced from {@link com.navigine.idl.java.LocationWindow LocationWindow}.
 * <p><b>Note:</b> IconMapObject maintains orientation to the screen surface by default.</p>
 */
public abstract class IconMapObject extends MapObject {
    /**
     * Method is used to specify the center of the icon.
     * @param point WGS84 coordinates of the center {@link com.navigine.idl.java.GlobalPoint GlobalPoint}.
     * @param sublocationId Floor this object is attached to, or null for the outdoor map.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set icon position
     * GlobalPoint iconPoint = new GlobalPoint(200.0, 300.0);
     * boolean success = iconMapObject.setPosition(iconPoint, 7);
     * System.out.println("Set icon position to (" + iconPoint.getLatitude() + ", " + iconPoint.getLongitude() + "): " + success);
     * }
     * </pre>
     */
    public abstract boolean setPosition(GlobalPoint point, Integer sublocationId);

    /**
     * Method is used to move the center of the icon with the specified animation.
     * @param point WGS84 coordinates of the center {@link com.navigine.idl.java.GlobalPoint GlobalPoint}.
     * @param sublocationId Floor this object is attached to, or null for the outdoor map.
     * @param duration Animation duration in seconds.
     * @param type Animation type {@link com.navigine.idl.java.AnimationType AnimationType}.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set icon position with animation
     * GlobalPoint animatedIconPoint = new GlobalPoint(250.0, 350.0);
     * boolean animatedSuccess = iconMapObject.setPositionAnimated(animatedIconPoint, 7, 1.5, AnimationType.CUBIC);
     * System.out.println("Set icon position with animation to (" + animatedIconPoint.getLatitude() + ", " + animatedIconPoint.getLongitude() + "): " + animatedSuccess);
     * }
     * </pre>
     */
    public abstract boolean setPositionAnimated(GlobalPoint point, Integer sublocationId, float duration, AnimationType type);

    /**
     * Method is used to specify the decoded raster for the icon.
     * @param bitmap Image provider: Android com.navigine.image.ImageProvider; iOS UIImage via binding; Flutter navigine_sdk ImageProvider.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Icon pixels come from an ImageProvider (ARGB_8888 Bitmap on Android).
     * ImageProvider iconBitmap = ImageProvider.fromFile("/path/to/icon.png", true);
     * boolean bitmapSuccess = iconMapObject.setBitmap(iconBitmap);
     * System.out.println("Set icon from ImageProvider: " + bitmapSuccess);
     * }
     * </pre>
     */
    public abstract boolean setBitmap(com.navigine.image.ImageProvider bitmap);

    /**
     * Method is used to specify the size of the icon.
     * @param width Width of the icon in pixels.
     * @param height Height of the icon in pixels.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set icon size
     * boolean sizeSuccess = iconMapObject.setSize(32.0, 32.0);
     * System.out.println("Set icon size to 32x32 pixels: " + sizeSuccess);
     * }
     * </pre>
     */
    public abstract boolean setSize(float width, float height);

    /**
     * Method is used to enable or disable collision detection for the icon.
     * @param enabled Specifies whether collision detection is enabled (true) or disabled (false). Default: false.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Enable collision detection
     * boolean collisionSuccess = iconMapObject.setCollisionEnabled(true);
     * System.out.println("Enabled collision detection for icon: " + collisionSuccess);
     * }
     * </pre>
     */
    public abstract boolean setCollisionEnabled(boolean enabled);

    /**
     * Method is used to specify the rotation angle of the icon.
     * @param angle Rotation angle in radians. Default: 0.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set icon rotation angle (radians)
     * boolean angleSuccess = iconMapObject.setAngle((float) Math.toRadians(45.0));
     * System.out.println("Set icon rotation angle to π/4: " + angleSuccess);
     * }
     * </pre>
     */
    public abstract boolean setAngle(float angle);

    /**
     * Method is used to rotate the icon with the specified animation.
     * @param angle Rotation angle in radians.
     * @param duration Animation duration in seconds.
     * @param type Animation type {@link com.navigine.idl.java.AnimationType AnimationType}.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set icon rotation with animation (radians)
     * boolean angleAnimatedSuccess = iconMapObject.setAngleAnimated((float) Math.toRadians(90.0), 2.0, AnimationType.SINE);
     * System.out.println("Set icon rotation with animation to π/2: " + angleAnimatedSuccess);
     * }
     * </pre>
     */
    public abstract boolean setAngleAnimated(float angle, float duration, AnimationType type);

    /**
     * Method is used to specify the buffer size around the icon for collision detection.
     * @param width Width of the buffer in pixels. Default: 0.
     * @param height Height of the buffer in pixels. Default: 0.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set collision buffer
     * boolean bufferSuccess = iconMapObject.setBuffer(10.0, 10.0);
     * System.out.println("Set collision buffer to 10x10 pixels: " + bufferSuccess);
     * }
     * </pre>
     */
    public abstract boolean setBuffer(float width, float height);

    /**
     * Method is used to specify an offset for the icon’s anchor on screen.
     * @param width Horizontal offset in pixels.
     * @param height Vertical offset in pixels.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set position offset
     * boolean offsetSuccess = iconMapObject.setOffset(0.0, -16.0);
     * System.out.println("Set position offset to (0.0, -16.0) pixels: " + offsetSuccess);
     * }
     * </pre>
     */
    public abstract boolean setOffset(float width, float height);

    /**
     * Method is used to specify the priority of the icon.
     * @param priority The priority value for rendering or interaction. Default: max.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set rendering priority
     * boolean prioritySuccess = iconMapObject.setPriority(2);
     * System.out.println("Set rendering priority to 2: " + prioritySuccess);
     * }
     * </pre>
     */
    public abstract boolean setPriority(float priority);

    /**
     * Method is used to specify whether the icon is flat or billboarded.
     * @param flat If true, the icon aligns with the location view surface; if false, it maintains orientation to the screen surface. Default: false.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set icon flat mode
     * boolean flatSuccess = iconMapObject.setFlat(true);
     * System.out.println("Set icon flat mode to true: " + flatSuccess);
     * }
     * </pre>
     */
    public abstract boolean setFlat(boolean flat);

    /**
     * Tells if this {@link IconMapObject} is valid or not. Any other method
     * (except for this one) called on an invalid {@link IconMapObject} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
