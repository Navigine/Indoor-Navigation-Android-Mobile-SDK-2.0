package com.navigine.idl.java;

/**
 * Debug visualization flags for the map view {@link com.navigine.idl.java.LocationWindow LocationWindow}.
 *
 * <p><b>Example:</b></p>
 * <pre>
 * {@code
 * DebugFlag[] allFlags = new DebugFlag[] {
 *    DebugFlag.NONE,
 *    DebugFlag.INFOS,
 *    DebugFlag.STATS,
 *    DebugFlag.LABELS,
 *    DebugFlag.DRAW_ALL_LABELS,
 *    DebugFlag.SELECTION_BUFFER
 * };
 * System.out.println("Debug flag enum values: " + allFlags.length);
 * }
 * </pre>
 */
public enum DebugFlag {
    NONE,
    INFOS,
    STATS,
    LABELS,
    DRAW_ALL_LABELS,
    SELECTION_BUFFER,
    ;
}
