package com.navigine.idl.java;

/**
 * Enum described supported image types
 * Referenced from {@link com.navigine.idl.java.Image Image}.
 */
public enum ImageType {
    /**
     * PNG format
     */
    PNG,
    /**
     * SVG format
     */
    SVG,
    /**
     * JPG format
     */
    JPG,
    ;
}
