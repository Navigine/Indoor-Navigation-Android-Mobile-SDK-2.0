package com.navigine.idl.java;

import java.util.ArrayList;

/**
 * Class is used for storing sublocation parameters: identifier, name, width, height, etc.
 * The list of sublocations for the current location can be obtained from {@link com.navigine.idl.java.Location Location} class using public method getSublocations.
 * Referenced from {@link com.navigine.idl.java.Location Location}.
 */
public abstract class Sublocation {
    /**
     * Method is used to obtain origin sublocation image with specified maxTextureSize.
     * @param maxTextureSize maximum texture size to render.
     * @return platform image.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get sublocation image
     * ImageWrapper image = sublocation.getImage(1024); // max texture size 1024
     * if (image != null) {
     *    System.out.println("Sublocation image obtained with max texture size 1024");
     * }
     * }
     * </pre>
     */
    public abstract android.graphics.Bitmap getImage(Integer maxTextureSize);

    /**
     * Method is used for converting the global geographic coordinates (latitude and longitude) to the local sublocation coordinates (x and y)
     * using the geographic binding of the sublocation
     * @param globalPoint point in WGS84 coordinates {@link com.navigine.idl.java.GlobalPoint GlobalPoint}
     * @return point in metrics coordinates {@link com.navigine.idl.java.LocationPoint LocationPoint}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Convert global coordinates to local coordinates
     * GlobalPoint globalPoint = new GlobalPoint(55.7558, 37.6176); // Moscow coordinates
     * LocationPoint localPoint = sublocation.globalToLocal(globalPoint);
     * System.out.println("Global point " + globalPoint.getLat() + ", " + globalPoint.getLon() +
     *                  " converted to local: " + localPoint.getX() + ", " + localPoint.getY());
     * }
     * </pre>
     */
    public abstract LocationPoint globalToLocal(GlobalPoint globalPoint);

    /**
     * Method is used for converting the local sublocation coordinates to the global geographic coordinates (latitude and longitude)
     * using the geographic binding of the sublocation.
     * @param localPoint point in metrics coordinates {@link com.navigine.idl.java.LocationPoint LocationPoint}
     * @return point in WGS84 coordinates {@link com.navigine.idl.java.GlobalPoint GlobalPoint}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Convert local coordinates to global coordinates
     * LocationPoint localPoint2 = new LocationPoint(100.0, 200.0);
     * GlobalPoint globalPoint2 = sublocation.localToGlobal(localPoint2);
     * System.out.println("Local point " + localPoint2.getX() + ", " + localPoint2.getY() +
     *                  " converted to global: " + globalPoint2.getLat() + ", " + globalPoint2.getLon());
     * }
     * </pre>
     */
    public abstract GlobalPoint localToGlobal(LocationPoint localPoint);

    /**
     * Method is used to obtain graph (within the current sublocation)
     * with the specified identifier or {@code null} if no such graph.
     * @param tag graph tag.
     * @return found graph or {@code null} {@link com.navigine.idl.java.Graph Graph}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get graph
     * Graph graph = sublocation.getGraph();
     * if (graph != null) {
     *    demonstrateGraphUsage(graph);
     * }
     * }
     * </pre>
     */
    public abstract Graph getGraph(String tag);

    /**
     * Method returns the venue (within the current sublocation)
     * with the specified identifier or {@code null} if no such venue exists.
     * @param id venue unique identifier.
     * @return found venue object or {@code null} {@link com.navigine.idl.java.Venue Venue}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get venue by ID
     * if (!venues.isEmpty()) {
     *    Venue venueById = sublocation.getVenueById(venues.get(0).getId());
     *    if (venueById != null) {
     *        System.out.println("Found venue by ID: " + venueById.getId());
     *        demonstrateVenueUsage(venueById);
     *    }
     * }
     * }
     * </pre>
     */
    public abstract Venue getVenueById(int id);

    /**
     * Method returns the zone (within the current sublocation)
     * with the specified identifier or {@code null} if no such zone exists.
     * @param id zone unique identifier.
     * @return found zone object or {@code null} {@link com.navigine.idl.java.Zone Zone}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get zone by ID
     * if (!zones.isEmpty()) {
     *    Zone zoneById = sublocation.getZoneById(zones.get(0).getId());
     *    if (zoneById != null) {
     *        System.out.println("Found zone by ID: " + zoneById.getId());
     *        demonstrateZoneUsage(zoneById);
     *    }
     * }
     * }
     * </pre>
     */
    public abstract Zone getZoneById(int id);

    /**
     * sublocation's identifier.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get sublocation ID
     * int sublocationId = sublocation.getId();
     * System.out.println("Sublocation ID: " + sublocationId);
     * }
     * </pre>
     * @return sublocation's identifier.
     */
    public abstract int getId();

    /**
     * location's identifier to which the sublocation belongs.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get location ID
     * int locationId = sublocation.getLocation();
     * System.out.println("Sublocation location ID: " + locationId);
     * }
     * </pre>
     * @return location's identifier to which the sublocation belongs.
     */
    public abstract int getLocation();

    /**
     * sublocation's name.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get sublocation name
     * String sublocationName = sublocation.getName();
     * System.out.println("Sublocation name: " + sublocationName);
     * }
     * </pre>
     * @return sublocation's name.
     */
    public abstract String getName();

    /**
     * sublocation's width in meters.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get sublocation width in meters
     * double width = sublocation.getWidth();
     * System.out.println("Sublocation width: " + width + " meters");
     * }
     * </pre>
     * @return sublocation's width in meters.
     */
    public abstract float getWidth();

    /**
     * sublocation's height in meters.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get sublocation height in meters
     * double height = sublocation.getHeight();
     * System.out.println("Sublocation height: " + height + " meters");
     * }
     * </pre>
     * @return sublocation's height in meters.
     */
    public abstract float getHeight();

    /**
     * sublocation's altitude in meters if specified.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get sublocation altitude in meters
     * Double altitude = sublocation.getAltitude();
     * if (altitude != null) {
     *    System.out.println("Sublocation altitude: " + altitude + " meters");
     * }
     * }
     * </pre>
     * @return sublocation's altitude in meters if specified.
     */
    public abstract Float getAltitude();

    /**
     * sublocation's azimuth in degrees clockwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get sublocation azimuth in degrees
     * double azimuth = sublocation.getAzimuth();
     * System.out.println("Sublocation azimuth: " + azimuth + " degrees");
     * }
     * </pre>
     * @return sublocation's azimuth in degrees clockwise.
     */
    public abstract float getAzimuth();

    /**
     * sublocation's center point in WGS84 coordinates {@link com.navigine.idl.java.GlobalPoint GlobalPoint}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get sublocation origin point in WGS84 coordinates
     * GlobalPoint originPoint = sublocation.getOriginPoint();
     * System.out.println("Sublocation origin point: " + originPoint.getLat() + ", " + originPoint.getLon());
     * }
     * </pre>
     * @return sublocation's center point in WGS84 coordinates {@link GlobalPoint GlobalPoint}.
     */
    public abstract GlobalPoint getOriginPoint();

    /**
     * sublocation's levelId.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get sublocation level ID
     * String levelId = sublocation.getLevelId();
     * System.out.println("Sublocation level ID: " + levelId);
     * }
     * </pre>
     * @return sublocation's levelId.
     */
    public abstract String getLevelId();

    /**
     * sublocation's externalId.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get sublocation external ID
     * String externalId = sublocation.getExternalId();
     * System.out.println("Sublocation external ID: " + externalId);
     * }
     * </pre>
     * @return sublocation's externalId.
     */
    public abstract String getExternalId();

    /**
     * sublocation's building name (e.g. "Outdoor" for overview plan).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get sublocation building name
     * String buildingName = sublocation.getBuildingName();
     * System.out.println("Sublocation building name: " + buildingName);
     * }
     * </pre>
     * @return sublocation's building name (e.g. "Outdoor" for overview plan).
     */
    public abstract String getBuildingName();

    /**
     * List of beacons, attached to this sublocation {@link com.navigine.idl.java.Beacon Beacon}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get beacons
     * java.util.ArrayList<Beacon> beacons = sublocation.getBeacons();
     * System.out.println("Number of beacons: " + beacons.size());
     * }
     * </pre>
     * @return List of beacons, attached to this sublocation {@link Beacon Beacon}.
     */
    public abstract ArrayList<Beacon> getBeacons();

    /**
     * List of eddystones, attached to this sublocation {@link com.navigine.idl.java.Eddystone Eddystone}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get Eddystone beacons
     * java.util.ArrayList<Eddystone> eddystones = sublocation.getEddystones();
     * System.out.println("Number of Eddystone beacons: " + eddystones.size());
     * }
     * </pre>
     * @return List of eddystones, attached to this sublocation {@link Eddystone Eddystone}.
     */
    public abstract ArrayList<Eddystone> getEddystones();

    /**
     * List of wifis, attached to this sublocation {@link com.navigine.idl.java.Wifi Wifi}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get WiFi access points
     * java.util.ArrayList<Wifi> wifis = sublocation.getWifis();
     * System.out.println("Number of WiFi access points: " + wifis.size());
     * }
     * </pre>
     * @return List of wifis, attached to this sublocation {@link Wifi Wifi}.
     */
    public abstract ArrayList<Wifi> getWifis();

    public abstract ArrayList<ReferencePoint> getReferencePoints();

    /**
     * List of venues, attached to this sublocation {@link com.navigine.idl.java.Venue Venue}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get venues
     * java.util.ArrayList<Venue> venues = sublocation.getVenues();
     * System.out.println("Number of venues: " + venues.size());
     * }
     * </pre>
     * @return List of venues, attached to this sublocation {@link Venue Venue}.
     */
    public abstract ArrayList<Venue> getVenues();

    /**
     * List of zones, attached to this sublocation {@link com.navigine.idl.java.Zone Zone}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get zones
     * java.util.ArrayList<Zone> zones = sublocation.getZones();
     * System.out.println("Number of zones: " + zones.size());
     * }
     * </pre>
     * @return List of zones, attached to this sublocation {@link Zone Zone}.
     */
    public abstract ArrayList<Zone> getZones();

    /**
     * Tells if this {@link Sublocation} is valid or not. Any other method
     * (except for this one) called on an invalid {@link Sublocation} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
