package com.navigine.idl.java;

/**
 * Layer that automatically renders current user position (arrow and accuracy circle) on the map.
 * Provides visibility and anchoring controls.
 * Referenced from {@link com.navigine.view.LocationView LocationView}.
 */
public abstract class UserLocationLayer {
    /**
     * Shows or hides user location layer.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * userLocationLayer.setVisible(true);
     * System.out.println("User location layer set visible");
     * }
     * </pre>
     */
    public abstract void setVisible(boolean visible);

    /**
     * Returns true if user location layer is visible.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * boolean visible = userLocationLayer.isVisible();
     * System.out.println("User location layer is visible: " + visible);
     * }
     * </pre>
     */
    public abstract boolean isVisible();

    /**
     * Sets anchor point for user indicator in screen pixels.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * ScreenPoint anchor = new ScreenPoint(100.0f, 200.0f);
     * userLocationLayer.setAnchor(anchor);
     * System.out.println("Set user location anchor to: (" + anchor.getX() + ", " + anchor.getY() + ")");
     * }
     * </pre>
     */
    public abstract void setAnchor(android.graphics.PointF anchor);

    /**
     * Resets anchor to default (center).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * userLocationLayer.resetAnchor();
     * System.out.println("Anchor reset to default");
     * }
     * </pre>
     */
    public abstract void resetAnchor();

    /**
     * Returns true if custom anchor is enabled.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * boolean anchorEnabled = userLocationLayer.anchorEnabled();
     * System.out.println("Anchor enabled: " + anchorEnabled);
     * }
     * </pre>
     */
    public abstract boolean anchorEnabled();

    /**
     * Tells if this {@link UserLocationLayer} is valid or not. Any other method
     * (except for this one) called on an invalid {@link UserLocationLayer} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
