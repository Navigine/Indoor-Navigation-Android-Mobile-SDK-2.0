package com.navigine.idl.java;

/**
 * Layer that automatically renders current user position (arrow and accuracy circle) on the map.
 * Provides visibility and anchoring controls.
 * Referenced from {@link com.navigine.view.LocationView LocationView}.
 */
public abstract class UserLocationLayer {
    /**
     * Shows or hides user location layer.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * userLocationLayer.setVisible(true);
     * System.out.println("User location layer set visible");
     * }
     * </pre>
     */
    public abstract void setVisible(boolean visible);

    /**
     * Returns true if user location layer is visible.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * boolean visible = userLocationLayer.isVisible();
     * System.out.println("User location layer is visible: " + visible);
     * }
     * </pre>
     */
    public abstract boolean isVisible();

    /**
     * Sets anchor point for user indicator in screen pixels.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * ScreenPoint anchor = new ScreenPoint(100.0f, 200.0f);
     * userLocationLayer.setAnchor(anchor);
     * System.out.println("Set user location anchor to: (" + anchor.getX() + ", " + anchor.getY() + ")");
     * }
     * </pre>
     */
    public abstract void setAnchor(android.graphics.PointF anchor);

    /**
     * Resets anchor to default (center).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * userLocationLayer.resetAnchor();
     * System.out.println("Anchor reset to default");
     * }
     * </pre>
     */
    public abstract void resetAnchor();

    /**
     * Returns true if custom anchor is enabled.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * boolean anchorEnabled = userLocationLayer.anchorEnabled();
     * System.out.println("Anchor enabled: " + anchorEnabled);
     * }
     * </pre>
     */
    public abstract boolean anchorEnabled();

    /**
     * Enables or disables heading-up mode while the user location layer is anchored.
     * When enabled and a location heading is available, the map camera rotates to keep
     * the user's heading pointed toward the top of the screen. Without an anchor the
     * location icon keeps rotating independently.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * userLocationLayer.setHeadingModeActive(true);
     * System.out.println("Heading-up mode enabled");
     * }
     * </pre>
     */
    public abstract void setHeadingModeActive(boolean active);

    /**
     * Returns true if heading-up mode is enabled.
     * Same as followMode() == HEADING.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * boolean headingModeActive = userLocationLayer.headingModeActive();
     * System.out.println("Heading-up mode active: " + headingModeActive);
     * }
     * </pre>
     */
    public abstract boolean headingModeActive();

    /**
     * Sets how the camera follows the user.
     * NONE stops following and keeps a previously set anchor point.
     * POSITION, HEADING and COURSE follow even without setAnchor (screen center).
     * setAnchor() from NONE switches to POSITION. resetAnchor() switches to NONE.
     * setHeadingModeActive(true) switches to HEADING.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * userLocationLayer.setFollowMode(UserLocationFollowMode.HEADING);
     * System.out.println("Follow mode set to heading");
     * }
     * </pre>
     */
    public abstract void setFollowMode(UserLocationFollowMode mode);

    /**
     * Returns the current follow mode.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * UserLocationFollowMode followMode = userLocationLayer.followMode();
     * System.out.println("Follow mode: " + followMode);
     * }
     * </pre>
     */
    public abstract UserLocationFollowMode followMode();

    /**
     * Replaces the heading arrow bitmap.
     * Null restores the built-in heading fan.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * userLocationLayer.setArrowBitmap(ImageProvider.fromFile("/path/to/arrow.png", true));
     * userLocationLayer.setArrowBitmap(null);
     * System.out.println("Custom arrow bitmap cleared");
     * }
     * </pre>
     */
    public abstract void setArrowBitmap(com.navigine.image.ImageProvider bitmap);

    /**
     * Sets the accuracy-circle fill. Default is a translucent blue.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * userLocationLayer.setAccuracyColor(0x4230AAD9);
     * System.out.println("Accuracy circle color updated");
     * }
     * </pre>
     */
    public abstract void setAccuracyColor(int color);

    /**
     * Tells if this {@link UserLocationLayer} is valid or not. Any other method
     * (except for this one) called on an invalid {@link UserLocationLayer} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
