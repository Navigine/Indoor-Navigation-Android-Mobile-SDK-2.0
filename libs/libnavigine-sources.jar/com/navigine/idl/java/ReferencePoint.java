package com.navigine.idl.java;

import java.util.ArrayList;

public abstract class ReferencePoint {
    public abstract int getLocationId();

    public abstract int getSublocationId();

    public abstract String getName();

    public abstract String getUuid();

    public abstract Point getPoint();

    public abstract int getQuality();

    public abstract long getDuration();

    public abstract String getDeviceId();

    public abstract String getDeviceModel();

    public abstract String getTimeLabel();

    public abstract ArrayList<ReferenceEntry> getEntries();

    public abstract TransmitterStatus getStatus();

    /**
     * Tells if this {@link ReferencePoint} is valid or not. Any other method
     * (except for this one) called on an invalid {@link ReferencePoint} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
