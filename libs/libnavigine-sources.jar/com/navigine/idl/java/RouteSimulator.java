package com.navigine.idl.java;

import com.navigine.common.NativeObject;
import com.navigine.common.Subscription;
import java.util.ArrayList;

/**
 * Walks a polyline at a constant speed for demos and guidance QA.
 * Distinct from {@link com.navigine.idl.java.MeasurementManager MeasurementManager} signal generators.
 * Does not publish a navigation position and does not move the user-location layer.
 * Hosts apply {@code sample} to an icon or other preview.
 * Created with {@link com.navigine.idl.java.NavigineSdk NavigineSdk} {@code getRouteSimulator}.
 */
public abstract class RouteSimulator {
    /**
     * Geometry in walk order. A later polyline may be on another floor.
     * @return false when fewer than two distinct points were given.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * List<GlobalPoint> walkPoints = new ArrayList<>();
     * walkPoints.add(new GlobalPoint(55.751, 37.618));
     * walkPoints.add(new GlobalPoint(55.752, 37.618));
     * routeSimulator.setGeometry(Collections.singletonList(new LocationPolyline(walkPoints, null)));
     * }
     * </pre>
     */
    public abstract boolean setGeometry(ArrayList<LocationPolyline> polylines);

    /**
     * Walking speed in meters per second. Default is 1.4. Zero pauses motion.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * routeSimulator.setSpeed(1.4f);
     * }
     * </pre>
     */
    public abstract void setSpeed(float metersPerSecond);

    /**
     * Current speed in meters per second.
     */
    public abstract float speed();

    /**
     * Starts from the beginning, or continues when already active.
     * @return false when geometry is missing.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * boolean started = routeSimulator.start();
     * System.out.println("Route walk started: " + started);
     * }
     * </pre>
     */
    public abstract boolean start();

    /**
     * Stops and rewinds to the start. Does not emit `onFinished`.
     */
    public abstract void stop();

    /**
     * True while a walk is in progress.
     */
    public abstract boolean active();

    /**
     * Latest sample, or null before the first tick.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * RouteSimulatorSample sample = routeSimulator.sample();
     * if (sample != null) {
     *    System.out.println("Walk advance: " + sample.getAdvance() + " m");
     * }
     * }
     * </pre>
     */
    public abstract RouteSimulatorSample sample();

    public abstract void addListener(RouteSimulatorListener listener);

    public abstract void removeListener(RouteSimulatorListener listener);

    /**
     * Tells if this {@link RouteSimulator} is valid or not. Any other method
     * (except for this one) called on an invalid {@link RouteSimulator} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
