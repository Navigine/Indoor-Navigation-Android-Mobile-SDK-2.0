package com.navigine.idl.java;

import com.navigine.platform.NativeObject;
import com.navigine.platform.Subscription;
import java.util.HashMap;

/**
 * Class is used for downloading locations list from the server and providing it to the user.
 * Referenced from {@link com.navigine.idl.java.NavigineSdk NavigineSdk}.
 */
public abstract class LocationListManager {
    /**
     * Method is used to add {@link com.navigine.idl.java.LocationListListener LocationListListener} element
     * which will notify about newly downloaded list of available locations.
     * <p><b>Note:</b> Do not forget to remove listener if it is no longer needed!</p>
     * @param listener Corresponding {@link com.navigine.idl.java.LocationListListener LocationListListener} class.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Add location list listener
     * locationListManager.addLocationListListener(locationListListener);
     * System.out.println("Added location list listener");
     * }
     * </pre>
     */
    public abstract void addLocationListListener(LocationListListener listener);

    /**
     * Method is used for removing previously added {@link com.navigine.idl.java.LocationListListener LocationListListener} class element.
     * @param listener Corresponding {@link com.navigine.idl.java.LocationListListener LocationListListener} class to remove.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove location list listener
     * locationListManager.removeLocationListListener(locationListListener);
     * System.out.println("Removed location list listener");
     * }
     * </pre>
     */
    public abstract void removeLocationListListener(LocationListListener listener);

    /**
     * Method is used to force reload location list.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Force reload location list
     * locationListManager.updateLocationList();
     * System.out.println("Requested location list update");
     * }
     * </pre>
     */
    public abstract void updateLocationList();

    /**
     * Method is used to get current location list {@link com.navigine.idl.java.LocationInfo LocationInfo}.
     * @return dictionary {location_id -> location_info}
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get current location list
     * Map<Integer, LocationInfo> currentLocationList = locationListManager.getLocationList();
     * System.out.println("Current location list contains " + currentLocationList.size() + " locations");
     * demonstrateLocationList(currentLocationList);
     * }
     * </pre>
     */
    public abstract HashMap<Integer, LocationInfo> getLocationList();
}
