package com.navigine.idl.java;

/**
 * Base interface for handling objects on the location view.
 * Used to manage objects in {@link com.navigine.idl.java.LocationWindow LocationWindow}.
 * Can be handled in the {@code pickMapObjectAt} method {@link com.navigine.idl.java.LocationWindow LocationWindow}.
 * Referenced from {@link com.navigine.idl.java.CircleMapObject CircleMapObject}, {@link com.navigine.idl.java.IconMapObject IconMapObject}, {@link com.navigine.idl.java.ClusterMapObject ClusterMapObject}, {@link com.navigine.idl.java.PolylineMapObject PolylineMapObject}, {@link com.navigine.idl.java.PolygonMapObject PolygonMapObject}, {@link com.navigine.idl.java.DottedPolylineMapObject DottedPolylineMapObject}, {@link com.navigine.idl.java.ModelMapObject ModelMapObject}.
 */
public abstract class MapObject {
    /**
     * Gets the unique identifier of the map object.
     * @return The unique identifier of the map object.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get object ID
     * int objectId = circleMapObject.getId();
     * System.out.println("Circle object ID: " + objectId);
     * }
     * </pre>
     */
    public abstract int getId();

    /**
     * Gets the type of the map object.
     * @return The type of the map object {@link com.navigine.idl.java.MapObjectType MapObjectType}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get object type
     * String objectTypeString = circleMapObject.getType();
     * System.out.println("Circle object type: " + objectTypeString);
     * }
     * </pre>
     */
    public abstract MapObjectType getType();

    /**
     * Gets the user-defined data associated with the map object.
     * @return The data stored in the map object.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get custom data
     * Map<String, String> retrievedData = circleMapObject.getData();
     * System.out.println("Circle custom data: " + retrievedData);
     * }
     * </pre>
     */
    public abstract byte[] getData();

    /**
     * Method is used to specify the visibility of the map object.
     * @param visible Specifies whether the object is visible (true) or hidden (false). Default: true.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set visibility
     * boolean visibleSuccess = circleMapObject.setVisible(true);
     * System.out.println("Set circle visibility to true: " + visibleSuccess);
     * }
     * </pre>
     */
    public abstract boolean setVisible(boolean visible);

    /**
     * Method is used to specify whether the map object can be interacted with.
     * @param interactive Specifies whether the object can be picked in the {@code pickMapObjectAt} method (true) or not (false). Default: false.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set interactive mode
     * boolean interactiveSuccess = circleMapObject.setInteractive(true);
     * System.out.println("Set circle interactive to true: " + interactiveSuccess);
     * }
     * </pre>
     */
    public abstract boolean setInteractive(boolean interactive);

    /**
     * Method is used to set user-defined data for the map object.
     * @param data Data to store in the map object.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set custom data
     * Map<String, String> customData = new HashMap<>();
     * customData.put("key", "value");
     * customData.put("number", "42");
     * boolean dataSuccess = circleMapObject.setData(customData);
     * System.out.println("Set circle custom data: " + dataSuccess);
     * }
     * </pre>
     */
    public abstract void setData(byte[] data);

    /**
     * Method is used to set the title of the map object.
     * @param title The title to display on the location view.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set title
     * boolean titleSuccess = circleMapObject.setTitle("Circle Object");
     * System.out.println("Set circle title to 'Circle Object': " + titleSuccess);
     * }
     * </pre>
     */
    public abstract boolean setTitle(String title);

    /**
     * Method is used to set the title and its style for the map object.
     * @param title The title to display on the location view.
     * @param style Title style parameters {@link com.navigine.idl.java.TitleStyle TitleStyle}.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set title with style
     * boolean titleStyleSuccess = circleMapObject.setTitleWithStyle("Styled Circle", titleStyle);
     * System.out.println("Set circle title with style: " + titleStyleSuccess);
     * }
     * </pre>
     */
    public abstract boolean setTitleWithStyle(String title, TitleStyle style);

    /**
     * Method is used to set the opacity of the map object.
     * @param alpha Opacity multiplier. Values below 0 will be set to 0. Values above 1 will be set to 1. Default: 1.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set alpha transparency
     * boolean alphaSuccess = circleMapObject.setAlpha(0.7);
     * System.out.println("Set circle alpha to 0.7: " + alphaSuccess);
     * }
     * </pre>
     */
    public abstract boolean setAlpha(float alpha);

    /**
     * Tells if this {@link MapObject} is valid or not. Any other method
     * (except for this one) called on an invalid {@link MapObject} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
