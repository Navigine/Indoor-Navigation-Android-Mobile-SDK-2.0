package com.navigine.idl.java;

/**
 * Screen placement of the OSM attribution overlay.
 * Same shape as typical map logo alignment: horizontal × vertical.
 * Default: right + bottom (OSM Vector Tile Usage Policy).
 * Referenced from {@link com.navigine.idl.java.LocationWindow LocationWindow} {@code attributionAlignment}.
 */
public final class AttributionAlignment {


    /*package*/ final AttributionHorizontalAlignment horizontalAlignment;

    /*package*/ final AttributionVerticalAlignment verticalAlignment;

    /**
     * Default constructor for class AttributionAlignment
     */
    public AttributionAlignment(
            AttributionHorizontalAlignment horizontalAlignment,
            AttributionVerticalAlignment verticalAlignment) {
        this.horizontalAlignment = horizontalAlignment;
        this.verticalAlignment = verticalAlignment;
    }

    /**
     * Default constructor for class AttributionAlignment
     */
    public AttributionAlignment() {
        this(AttributionHorizontalAlignment.RIGHT, AttributionVerticalAlignment.BOTTOM);
    }

    /**
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * AttributionAlignment alignment = new AttributionAlignment(
     *    AttributionHorizontalAlignment.RIGHT,
     *    AttributionVerticalAlignment.BOTTOM);
     * }
     * </pre>
     * Horizontal edge or center {@link com.navigine.idl.java.AttributionHorizontalAlignment AttributionHorizontalAlignment}.
     * @return <java>
     */
    public AttributionHorizontalAlignment getHorizontalAlignment() {
        return horizontalAlignment;
    }

    /**
     * Vertical edge {@link com.navigine.idl.java.AttributionVerticalAlignment AttributionVerticalAlignment}.
     * @return Vertical edge {@link AttributionVerticalAlignment AttributionVerticalAlignment}.
     */
    public AttributionVerticalAlignment getVerticalAlignment() {
        return verticalAlignment;
    }

    @Override
    public String toString() {
        return "AttributionAlignment{" +
                "horizontalAlignment=" + horizontalAlignment +
                "," + "verticalAlignment=" + verticalAlignment +
        "}";
    }

}
