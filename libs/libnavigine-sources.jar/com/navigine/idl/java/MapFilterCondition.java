package com.navigine.idl.java;

import java.util.ArrayList;

/**
 * A single filter condition: property must match one of the given values.
 *
 * <p><b>Example:</b></p>
 * <pre>
 * {@code
 * // Create filter condition: show only venues with category "Toilet" or "Cafe"
 * MapFilterCondition condition = new MapFilterCondition("category", Arrays.asList("Toilet", "Cafe"));
 * }
 * </pre>
 */
public final class MapFilterCondition {


    /*package*/ final String property;

    /*package*/ final ArrayList<String> values;

    /**
     * Default constructor for class MapFilterCondition
     */
    public MapFilterCondition(
            String property,
            ArrayList<String> values) {
        this.property = property;
        this.values = values;
    }

    /**
     * The feature property to match (e.g. "category", "kind").
     * @return The feature property to match (e.g. "category", "kind").
     */
    public String getProperty() {
        return property;
    }

    /**
     * List of allowed values. Feature is visible if its property matches any of these.
     * @return List of allowed values. Feature is visible if its property matches any of these.
     */
    public ArrayList<String> getValues() {
        return values;
    }

    @Override
    public String toString() {
        return "MapFilterCondition{" +
                "property=" + property +
                "," + "values=" + values +
        "}";
    }

}
