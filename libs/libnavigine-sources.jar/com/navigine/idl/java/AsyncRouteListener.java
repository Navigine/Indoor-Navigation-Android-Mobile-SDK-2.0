package com.navigine.idl.java;

/**
 * Class provides a callback to be invoked when {@link com.navigine.idl.java.RouteSession RouteSession}
 * handle changed/advanced events.
 * Referenced from {@link com.navigine.idl.java.AsyncRouteManager AsyncRouteManager} {@link com.navigine.idl.java.RouteSession RouteSession}.
 * <p><b>Note:</b> The callback is invoked in the UI thread.</p>
 */
public abstract class AsyncRouteListener {
    /**
     * Called when new route was built or
     * old route was rebuilt after missing previous one.
     * @param status {@link com.navigine.idl.java.RouteStatus RouteStatus} indicating the current router state
     * @param currentPath {@link com.navigine.idl.java.RoutePath RoutePath} from current position to destination point (null if status is not new_route)
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * public void onRouteChanged(RouteStatus status, RoutePath currentPath) {
     *    System.out.println("Route changed with status: " + status);
     *    if (status == RouteStatus.NEW_ROUTE && currentPath != null) {
     *        demonstrateRoutePathUsage(currentPath);
     *    } else {
     *        System.out.println("Route not ready, status: " + status);
     *    }
     * }
     * }
     * </pre>
     */
    public abstract void onRouteChanged(RouteStatus status, RoutePath currentPath);

    /**
     * Called when user has progressed along the route
     * that was built in the method {@code onRouteChanged}
     * @param distance distance from the beginning or the route (unit meters)
     * @param point current location point on the route
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * public void onRouteAdvanced(float distance, LocationPoint point) {
     *    System.out.println("Route advanced: " + distance + " meters");
     *    demonstrateLocationPointUsage(point);
     * }
     * }
     * </pre>
     */
    public abstract void onRouteAdvanced(float distance, LocationPoint point);
}
