package com.navigine.idl.java;

/**
 * Class is used for storing location polygonal zones.
 * Referenced from {@link com.navigine.idl.java.Sublocation Sublocation}.
 */
public abstract class Zone {
    /**
     * zone's list of points composing the polygonal zone {@link com.navigine.idl.java.Polygon Polygon}
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get zone polygon
     * java.util.ArrayList<Point> polygon = zone.getPolygon();
     * System.out.println("Zone polygon points: " + polygon.size());
     * }
     * </pre>
     * @return zone's list of points composing the polygonal zone {@link Polygon Polygon}
     */
    public abstract Polygon getPolygon();

    /**
     * zone's location identifier.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get zone location ID
     * int locationId = zone.getLocationId();
     * System.out.println("Zone location ID: " + locationId);
     * }
     * </pre>
     * @return zone's location identifier.
     */
    public abstract int getLocationId();

    /**
     * zone's sublocationId identifier.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get zone sublocation ID
     * int sublocationId = zone.getSublocationId();
     * System.out.println("Zone sublocation ID: " + sublocationId);
     * }
     * </pre>
     * @return zone's sublocationId identifier.
     */
    public abstract int getSublocationId();

    /**
     * zone's identifier.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get zone ID
     * int zoneId = zone.getId();
     * System.out.println("Zone ID: " + zoneId);
     * }
     * </pre>
     * @return zone's identifier.
     */
    public abstract int getId();

    /**
     * zone's name.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get zone name
     * String zoneName = zone.getName();
     * System.out.println("Zone name: " + zoneName);
     * }
     * </pre>
     * @return zone's name.
     */
    public abstract String getName();

    /**
     * zone's color.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get zone color
     * String color = zone.getColor();
     * System.out.println("Zone color: " + color);
     * }
     * </pre>
     * @return zone's color.
     */
    public abstract String getColor();

    /**
     * zone's alias.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get zone alias
     * String alias = zone.getAlias();
     * System.out.println("Zone alias: " + alias);
     * }
     * </pre>
     * @return zone's alias.
     */
    public abstract String getAlias();

    /**
     * Tells if this {@link Zone} is valid or not. Any other method
     * (except for this one) called on an invalid {@link Zone} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
