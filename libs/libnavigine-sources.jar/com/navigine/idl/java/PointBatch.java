package com.navigine.idl.java;

import java.util.ArrayList;

/**
 * One object for a cloud of screen-space arrows.
 * {@code setPoints} replaces the whole set. The list order is the index returned by
 * {@code hitTest}. The host draws the tooltip. Points are not clustered.
 */
public abstract class PointBatch extends MapObject {
    /**
     * Replaces every arrow. `sublocationId` null draws on the outdoor map.
     * @return false when the object has been removed.
     */
    public abstract boolean setPoints(ArrayList<PointSprite> points, Integer sublocationId);

    /**
     * Index of the nearest arrow inside `radius` pixels, or null.
     */
    public abstract Integer hitTest(android.graphics.PointF point, float radius);

    /**
     * Tells if this {@link PointBatch} is valid or not. Any other method
     * (except for this one) called on an invalid {@link PointBatch} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
