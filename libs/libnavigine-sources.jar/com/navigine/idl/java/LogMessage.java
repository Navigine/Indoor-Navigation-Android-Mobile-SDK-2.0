package com.navigine.idl.java;

public final class LogMessage {


    /*package*/ final long time;

    /*package*/ final LogLevel level;

    /*package*/ final String scope;

    /*package*/ final String message;

    /*package*/ final String verboseInfo;

    /**
     * Default constructor for class LogMessage
     */
    public LogMessage(
            long time,
            LogLevel level,
            String scope,
            String message,
            String verboseInfo) {
        this.time = time;
        this.level = level;
        this.scope = scope;
        this.message = message;
        this.verboseInfo = verboseInfo;
    }

    public long getTime() {
        return time;
    }

    public LogLevel getLevel() {
        return level;
    }

    public String getScope() {
        return scope;
    }

    public String getMessage() {
        return message;
    }

    public String getVerboseInfo() {
        return verboseInfo;
    }

    @Override
    public String toString() {
        return "LogMessage{" +
                "time=" + time +
                "," + "level=" + level +
                "," + "scope=" + scope +
                "," + "message=" + message +
                "," + "verboseInfo=" + verboseInfo +
        "}";
    }

}
