package com.navigine.idl.java;

public abstract class LogListener {
    public abstract void onMessageRecieved(LogMessage message);
}
