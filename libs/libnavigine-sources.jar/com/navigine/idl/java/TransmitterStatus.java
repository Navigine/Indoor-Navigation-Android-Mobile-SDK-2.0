package com.navigine.idl.java;

/**
 * enum described possible transmitter state.
 * Referenced from {@link com.navigine.idl.java.Beacon Beacon}, {@link com.navigine.idl.java.Eddystone Eddystone}, {@link com.navigine.idl.java.Wifi Wifi}.
 *
 * <p><b>Example:</b></p>
 * <pre>
 * {@code
 * // Get all transmitter status values
 * TransmitterStatus[] statuses = TransmitterStatus.values();
 * System.out.println("Available transmitter statuses:");
 * for (TransmitterStatus status : statuses) {
 *    System.out.println("  - " + status);
 * }
 * }
 * </pre>
 */
public enum TransmitterStatus {
    /**
     * Synchronized with CMS.
     */
    NONE,
    /**
     * Added in SDK but not synchronized with CMS.
     */
    NEW,
    /**
     * Deleted in SDK but not synchronized with CMS.
     */
    DELETED,
    /**
     * Changed in SDK but not synchronized with CMS.
     */
    MODIFIED,
    ;
}
