package com.navigine.idl.java;

/**
 * class described image data in SDK
 * Referenced from {@link com.navigine.idl.java.Sublocation Sublocation}.
 */
public abstract class Image {
    /**
     * binary source data of the image
     * @return binary source data of the image
     */
    public abstract byte[] getData();

    /**
     * decoded image width
     * @return decoded image width
     */
    public abstract int getWidth();

    /**
     * decoded image height
     * @return decoded image height
     */
    public abstract int getHeight();

    /**
     * decoded image type
     * @return decoded image type
     */
    public abstract ImageType getType();

    /**
     * Tells if this {@link Image} is valid or not. Any other method
     * (except for this one) called on an invalid {@link Image} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
