package com.navigine.idl.java;

/**
 * Listener for outdoor scenario when camera focuses on a building or leaves it.
 */
public abstract class BuildingListener {
    /**
     * Called when camera enters a building's bounding box.
     * @param activeBuilding The building that is now focused.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * @Override
     * public void onActiveBuildingFocused(Building activeBuilding) {
     *    // [java_Building_getSublocations]
     *    List<Sublocation> floors = activeBuilding.getSublocations();
     *    System.out.println("Focused building, floor count: " + floors.size());
     *    // [java_Building_getSublocations]
     *    // [java_Building_getActiveSublocationId]
     *    int activeFloorId = activeBuilding.getActiveSublocationId();
     *    System.out.println("Active sublocation id: " + activeFloorId);
     *    // [java_Building_getActiveSublocationId]
     *    // [java_Building_setActiveSublocationId]
     *    activeBuilding.setActiveSublocationId(activeFloorId);
     *    // [java_Building_setActiveSublocationId]
     * }
     * }
     * </pre>
     */
    public abstract void onActiveBuildingFocused(Building activeBuilding);

    /**
     * Called when camera leaves all buildings (no building bbox contains the camera).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * @Override
     * public void onActiveBuildingLeft() {
     *    System.out.println("Camera left all building areas");
     * }
     * }
     * </pre>
     */
    public abstract void onActiveBuildingLeft();

    /**
     * Called when the active sublocation (floor) of the focused building changes.
     * @param activeSublocationId New active sublocation id.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * @Override
     * public void onActiveSublocationChanged(int activeSublocationId) {
     *    System.out.println("Active floor changed to sublocation id: " + activeSublocationId);
     * }
     * }
     * </pre>
     */
    public abstract void onActiveSublocationChanged(int activeSublocationId);
}
