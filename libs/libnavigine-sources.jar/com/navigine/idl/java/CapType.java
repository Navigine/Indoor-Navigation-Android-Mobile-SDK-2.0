package com.navigine.idl.java;

/**
 * Enum defining the type of cap for polyline ends.
 * Referenced from {@link com.navigine.idl.java.PolylineMapObject PolylineMapObject}.
 */
public enum CapType {
    /**
     * No points added to the end of the line.
     */
    BUTT,
    /**
     * Two points added to make a square extension.
     */
    SQUARE,
    /**
     * Six points added in a fan to make a round cap.
     */
    ROUND,
    ;
}
