package com.navigine.idl.java;

import java.util.ArrayList;

/**
 * Polygon on the location view in WGS84 coordinates.
 *
 * <p><b>Example:</b></p>
 * <pre>
 * {@code
 * List<GlobalPoint> ring = Arrays.asList(
 *    new GlobalPoint(55.751, 37.617),
 *    new GlobalPoint(55.752, 37.618),
 *    new GlobalPoint(55.751, 37.619)
 * );
 * LocationPolygon locationPolygon = new LocationPolygon(ring, 7);
 * int polygonSublocationId = locationPolygon.getSublocationId();
 * System.out.println("LocationPolygon: sublocation "
 *    + polygonSublocationId + ", vertices " + locationPolygon.getPoints().size());
 * }
 * </pre>
 */
public final class LocationPolygon {


    /*package*/ final ArrayList<GlobalPoint> points;

    /*package*/ final Integer sublocationId;

    /**
     * Default constructor for class LocationPolygon
     */
    public LocationPolygon(
            ArrayList<GlobalPoint> points,
            Integer sublocationId) {
        this.points = points;
        this.sublocationId = sublocationId;
    }

    /**
     * Ring vertices in WGS84 {@link com.navigine.idl.java.GlobalPoint GlobalPoint}.
     * @return Ring vertices in WGS84 {@link GlobalPoint GlobalPoint}.
     */
    public ArrayList<GlobalPoint> getPoints() {
        return points;
    }

    /**
     * Floor this polygon is attached to, or null for the outdoor map.
     * @return Floor this polygon is attached to, or null for the outdoor map.
     */
    public Integer getSublocationId() {
        return sublocationId;
    }

    @Override
    public String toString() {
        return "LocationPolygon{" +
                "points=" + points +
                "," + "sublocationId=" + sublocationId +
        "}";
    }

}
