package com.navigine.idl.java;

/**
 * Class is used for representing certain polygon within the location {@link com.navigine.idl.java.Polygon Polygon}
 *
 * <p><b>Example:</b></p>
 * <pre>
 * {@code
 * List<Point> ring = Arrays.asList(
 *    new Point(1.0, 2.0),
 *    new Point(3.0, 4.0),
 *    new Point(5.0, 2.0)
 * );
 * Polygon metricPolygon = new Polygon(ring);
 * LocationPolygon locationPolygon = new LocationPolygon(metricPolygon, 42, 7);
 * Polygon polygonBack = locationPolygon.getPolygon();
 * int polygonLocationId = locationPolygon.getLocationId();
 * int polygonSublocationId = locationPolygon.getSublocationId();
 * System.out.println("LocationPolygon: location " + polygonLocationId + ", sublocation "
 *    + polygonSublocationId + ", vertices " + polygonBack.getPoints().size());
 * }
 * </pre>
 */
public final class LocationPolygon {


    /*package*/ final Polygon polygon;

    /*package*/ final int locationId;

    /*package*/ final int sublocationId;

    /**
     * Default constructor for class LocationPolygon
     */
    public LocationPolygon(
            Polygon polygon,
            int locationId,
            int sublocationId) {
        this.polygon = polygon;
        this.locationId = locationId;
        this.sublocationId = sublocationId;
    }

    /**
     * Metrics polygon {@link com.navigine.idl.java.Polygon Polygon}.
     * @return Metrics polygon {@link Polygon Polygon}.
     */
    public Polygon getPolygon() {
        return polygon;
    }

    /**
     * location polygon location identifier.
     * @return location polygon location identifier.
     */
    public int getLocationId() {
        return locationId;
    }

    /**
     * location polygon sublocation identifier.
     * @return location polygon sublocation identifier.
     */
    public int getSublocationId() {
        return sublocationId;
    }

    @Override
    public String toString() {
        return "LocationPolygon{" +
                "polygon=" + polygon +
                "," + "locationId=" + locationId +
                "," + "sublocationId=" + sublocationId +
        "}";
    }

}
