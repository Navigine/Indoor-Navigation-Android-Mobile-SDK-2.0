package com.navigine.idl.java;

import java.util.ArrayList;

/**
 * Polygon on the location view in WGS84 coordinates.
 * {@code points} is the outer ring. {@code innerRings} are holes (as in GeoJSON: first ring
 * outer, the rest holes). An empty list is a solid polygon.
 *
 * <p><b>Example:</b></p>
 * <pre>
 * {@code
 * List<GlobalPoint> ring = Arrays.asList(
 *    new GlobalPoint(55.751, 37.617),
 *    new GlobalPoint(55.752, 37.618),
 *    new GlobalPoint(55.751, 37.619)
 * );
 * List<List<GlobalPoint>> holes = Arrays.asList(Arrays.asList(
 *    new GlobalPoint(55.7512, 37.6174),
 *    new GlobalPoint(55.7514, 37.6176),
 *    new GlobalPoint(55.7512, 37.6178)
 * ));
 * LocationPolygon locationPolygon = new LocationPolygon(ring, 7, holes);
 * int polygonSublocationId = locationPolygon.getSublocationId();
 * System.out.println("LocationPolygon: sublocation "
 *    + polygonSublocationId + ", vertices " + locationPolygon.getPoints().size()
 *    + ", holes " + locationPolygon.getInnerRings().size());
 * }
 * </pre>
 */
public final class LocationPolygon {


    /*package*/ final ArrayList<GlobalPoint> points;

    /*package*/ final Integer sublocationId;

    /*package*/ final ArrayList<ArrayList<GlobalPoint>> innerRings;

    /**
     * Default constructor for class LocationPolygon
     */
    public LocationPolygon(
            ArrayList<GlobalPoint> points,
            Integer sublocationId,
            ArrayList<ArrayList<GlobalPoint>> innerRings) {
        this.points = points;
        this.sublocationId = sublocationId;
        this.innerRings = innerRings;
    }

    /**
     * Outer ring vertices in WGS84 {@link com.navigine.idl.java.GlobalPoint GlobalPoint}.
     * @return Outer ring vertices in WGS84 {@link GlobalPoint GlobalPoint}.
     */
    public ArrayList<GlobalPoint> getPoints() {
        return points;
    }

    /**
     * Floor this polygon is attached to, or null for the outdoor map.
     * @return Floor this polygon is attached to, or null for the outdoor map.
     */
    public Integer getSublocationId() {
        return sublocationId;
    }

    /**
     * Holes. Each ring is WGS84 {@link com.navigine.idl.java.GlobalPoint GlobalPoint}.
     * Empty means a solid polygon.
     * @return Holes. Each ring is WGS84 {@link GlobalPoint GlobalPoint}.
     */
    public ArrayList<ArrayList<GlobalPoint>> getInnerRings() {
        return innerRings;
    }

    @Override
    public String toString() {
        return "LocationPolygon{" +
                "points=" + points +
                "," + "sublocationId=" + sublocationId +
                "," + "innerRings=" + innerRings +
        "}";
    }

}
