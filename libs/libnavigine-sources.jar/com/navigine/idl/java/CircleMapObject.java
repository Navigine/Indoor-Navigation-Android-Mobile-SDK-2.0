package com.navigine.idl.java;

/**
 * Represents a circle on the location view.
 * Referenced from {@link com.navigine.idl.java.LocationWindow LocationWindow}.
 */
public abstract class CircleMapObject extends MapObject {
    /**
     * Method is used to specify the center of the circle.
     * @param point WGS84 coordinates of the center {@link com.navigine.idl.java.GlobalPoint GlobalPoint}.
     * @param sublocationId Floor this object is attached to, or null for the outdoor map.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set circle position
     * GlobalPoint centerPoint = new GlobalPoint(55.7558, 37.6176);
     * boolean success = circleMapObject.setPosition(centerPoint, 7);
     * System.out.println("Set circle position to (" + centerPoint.getLatitude() + ", " + centerPoint.getLongitude() + "): " + success);
     * }
     * </pre>
     */
    public abstract boolean setPosition(GlobalPoint point, Integer sublocationId);

    /**
     * Method is used to move the center of the circle with the specified animation.
     * @param point WGS84 coordinates of the center {@link com.navigine.idl.java.GlobalPoint GlobalPoint}.
     * @param sublocationId Floor this object is attached to, or null for the outdoor map.
     * @param duration Animation duration in seconds.
     * @param type Animation type {@link com.navigine.idl.java.AnimationType AnimationType}. Default: CENTER.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set circle position with animation
     * GlobalPoint animatedPoint = new GlobalPoint(55.7560, 37.6180);
     * boolean animatedSuccess = circleMapObject.setPositionAnimated(animatedPoint, 7, 2.0f, AnimationType.LINEAR);
     * System.out.println("Set circle position with animation to (" + animatedPoint.getLatitude() + ", " + animatedPoint.getLongitude() + "): " + animatedSuccess);
     * }
     * </pre>
     */
    public abstract boolean setPositionAnimated(GlobalPoint point, Integer sublocationId, float duration, AnimationType type);

    /**
     * Method is used to specify the fill color of the circle.
     * @param color Fill color.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set circle color
     * boolean colorSuccess = circleMapObject.setColor(0xCCFF0000);
     * System.out.println("Set circle color to red with 80% opacity: " + colorSuccess);
     * }
     * </pre>
     */
    public abstract boolean setColor(int color);

    /**
     * Method is used to specify the size of the circle.
     * @param radius Radius of the circle in meters.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set circle radius
     * boolean radiusSuccess = circleMapObject.setRadius(10.0);
     * System.out.println("Set circle radius to 10.0 meters: " + radiusSuccess);
     * }
     * </pre>
     */
    public abstract boolean setRadius(float radius);

    /**
     * Method is used to enable or disable collision detection for the circle.
     * @param enabled Specifies whether collision detection is enabled (true) or disabled (false). Default: false.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Enable collision detection
     * boolean collisionSuccess = circleMapObject.setCollisionEnabled(true);
     * System.out.println("Enabled collision detection for circle: " + collisionSuccess);
     * }
     * </pre>
     */
    public abstract boolean setCollisionEnabled(boolean enabled);

    /**
     * Method is used to specify the buffer size around the circle for collision detection.
     * @param width Width of the buffer in pixels. Default: 0.
     * @param height Height of the buffer in pixels. Default: 0.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set collision buffer
     * boolean bufferSuccess = circleMapObject.setBuffer(5.0, 5.0);
     * System.out.println("Set collision buffer to 5x5 pixels: " + bufferSuccess);
     * }
     * </pre>
     */
    public abstract boolean setBuffer(float width, float height);

    /**
     * Method is used to specify an offset for the circle’s position.
     * @param width Horizontal offset in pixels.
     * @param height Vertical offset in pixels.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set position offset
     * boolean offsetSuccess = circleMapObject.setOffset(2.0, 3.0);
     * System.out.println("Set position offset to (2.0, 3.0) pixels: " + offsetSuccess);
     * }
     * </pre>
     */
    public abstract boolean setOffset(float width, float height);

    /**
     * Method is used to specify the priority of the circle.
     * @param priority The priority value for rendering or interaction. Default: 0.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set rendering priority
     * boolean prioritySuccess = circleMapObject.setPriority(1);
     * System.out.println("Set rendering priority to 1: " + prioritySuccess);
     * }
     * </pre>
     */
    public abstract boolean setPriority(float priority);

    /**
     * Method is used to specify the color of the circle’s outline.
     * @param color Outline color.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set outline color
     * boolean outlineColorSuccess = circleMapObject.setOutlineColor(0xFF0000FF);
     * System.out.println("Set circle outline color to blue: " + outlineColorSuccess);
     * }
     * </pre>
     */
    public abstract boolean setOutlineColor(int color);

    /**
     * Method is used to specify the thickness of the circle’s outline.
     * @param radius Thickness of the outline in pixels.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set outline radius
     * boolean outlineRadiusSuccess = circleMapObject.setOutlineRadius(2.0);
     * System.out.println("Set circle outline radius to 2.0: " + outlineRadiusSuccess);
     * }
     * </pre>
     */
    public abstract boolean setOutlineRadius(float radius);

    /**
     * Method is used to specify the opacity of the circle’s outline.
     * @param alpha Opacity multiplier (0 to 1). Values below 0 are set to 0. Default: 1.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set outline alpha
     * boolean outlineAlphaSuccess = circleMapObject.setOutlineAlpha(0.5);
     * System.out.println("Set circle outline alpha to 0.5: " + outlineAlphaSuccess);
     * }
     * </pre>
     */
    public abstract boolean setOutlineAlpha(float alpha);

    /**
     * Tells if this {@link CircleMapObject} is valid or not. Any other method
     * (except for this one) called on an invalid {@link CircleMapObject} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
