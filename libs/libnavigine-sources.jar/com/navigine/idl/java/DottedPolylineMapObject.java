package com.navigine.idl.java;

/**
 * Represents a polyline object with points placed along it on the location view.
 * Referenced from {@link com.navigine.idl.java.LocationWindow LocationWindow}.
 */
public abstract class DottedPolylineMapObject extends MapObject {
    /**
     * Method is used to specify the source polyline for the points.
     * @param polyline Metrics coordinates of the polyline {@link com.navigine.idl.java.LocationPolyline LocationPolyline}.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set dotted polyline geometry
     * List<GlobalPoint> dottedPoints = new ArrayList<>();
     * dottedPoints.add(new GlobalPoint(0.0, 100.0));
     * dottedPoints.add(new GlobalPoint(50.0, 150.0));
     * dottedPoints.add(new GlobalPoint(100.0, 100.0));
     * dottedPoints.add(new GlobalPoint(150.0, 150.0));
     *            LocationPolyline locationDottedPolyline = new LocationPolyline(dottedPoints, 0);
     * boolean success = dottedPolylineMapObject.setPolyLine(locationDottedPolyline);
     * System.out.println("Set dotted polyline geometry: " + success);
     * }
     * </pre>
     */
    public abstract boolean setPolyLine(LocationPolyline polyline);

    /**
     * Method is used to specify the color of the object.
     * @param color Fill color.
     * @return true if success, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set dotted polyline color
     * boolean colorSuccess = dottedPolylineMapObject.setColor(0xCC8000FF);
     * System.out.println("Set dotted polyline color to purple with 80% opacity: " + colorSuccess);
     * }
     * </pre>
     */
    public abstract boolean setColor(int color);

    /**
     * Method is used to specify the size of the points.
     * @param width Width of the points in pixels.
     * @param height Height of the points in pixels.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set size
     * Size dottedSize = new Size(16.0, 16.0);
     * boolean dottedSizeSuccess = dottedPolylineMapObject.setSize(dottedSize);
     * System.out.println("Set dotted polyline size to (" + dottedSize.getWidth() + ", " + dottedSize.getHeight() + "): " + dottedSizeSuccess);
     * }
     * </pre>
     */
    public abstract boolean setSize(float width, float height);

    /**
     * Method is used to enable or disable collision detection for the icon.
     * @param enabled Specifies whether collision detection is enabled (true) or disabled (false). Default: false.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Enable collision detection
     * boolean dottedCollisionSuccess = dottedPolylineMapObject.setCollisionEnabled(true);
     * System.out.println("Enabled collision detection for dotted polyline: " + dottedCollisionSuccess);
     * }
     * </pre>
     */
    public abstract boolean setCollisionEnabled(boolean enabled);

    /**
     * Method is used to specify the placement mode for points along the polyline.
     * @param placement The placement mode {@link com.navigine.idl.java.Placement Placement}. Default: VERTEX.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set placement type
     * boolean dottedPlacementSuccess = dottedPolylineMapObject.setPlacement(Placement.CENTER);
     * System.out.println("Set dotted polyline placement to CENTER: " + dottedPlacementSuccess);
     * }
     * </pre>
     */
    public abstract boolean setPlacement(Placement placement);

    /**
     * Method is used to specify the minimum ratio of the polyline length for point placement.
     * @param ratio The minimum ratio of the polyline length (typically between 0 and 1). Default: 1.0.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set placement min ratio
     * boolean dottedMinRatioSuccess = dottedPolylineMapObject.setPlacementMinRatio(0.5);
     * System.out.println("Set dotted polyline placement min ratio to 0.5: " + dottedMinRatioSuccess);
     * }
     * </pre>
     */
    public abstract boolean setPlacementMinRatio(float ratio);

    /**
     * Method is used to specify the spacing between points for spaced placement.
     * @param spacing The spacing distance in pixels. Default: 80.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set placement spacing
     * boolean dottedSpacingSuccess = dottedPolylineMapObject.setPlacementSpacing(10.0);
     * System.out.println("Set dotted polyline placement spacing to 10.0: " + dottedSpacingSuccess);
     * }
     * </pre>
     */
    public abstract boolean setPlacementSpacing(float spacing);

    /**
     * Method is used to specify the distance interval for repeating points along the polyline.
     * @param distance The repeat distance in pixels. Default: 0.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set repeat distance
     * boolean dottedRepeatDistanceSuccess = dottedPolylineMapObject.setRepeatDistance(20.0);
     * System.out.println("Set dotted polyline repeat distance to 20.0: " + dottedRepeatDistanceSuccess);
     * }
     * </pre>
     */
    public abstract boolean setRepeatDistance(float distance);

    /**
     * Method is used to specify the group identifier for repeating points.
     * @param group The group identifier for point repetition. Default: 0.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set repeat group
     * boolean dottedRepeatGroupSuccess = dottedPolylineMapObject.setRepeatGroup(1);
     * System.out.println("Set dotted polyline repeat group to 1: " + dottedRepeatGroupSuccess);
     * }
     * </pre>
     */
    public abstract boolean setRepeatGroup(int group);

    /**
     * Method is used to specify the priority of the icon.
     * @param priority The priority value for rendering or interaction. Default: max.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set rendering priority
     * boolean dottedPrioritySuccess = dottedPolylineMapObject.setPriority(1);
     * System.out.println("Set dotted polyline rendering priority to 1: " + dottedPrioritySuccess);
     * }
     * </pre>
     */
    public abstract boolean setPriority(float priority);

    /**
     * Tells if this {@link DottedPolylineMapObject} is valid or not. Any other method
     * (except for this one) called on an invalid {@link DottedPolylineMapObject} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
