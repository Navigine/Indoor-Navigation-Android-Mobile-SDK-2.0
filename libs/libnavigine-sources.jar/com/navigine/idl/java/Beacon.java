package com.navigine.idl.java;

/**
 * Class is used for storing <a href="https://en.wikipedia.org/wiki/IBeacon">iBeacon</a>.
 * Referenced from {@link com.navigine.idl.java.Sublocation Sublocation}.
 */
public abstract class Beacon {
    /**
     * beacon's X and Y coordinates in meters as {@link com.navigine.idl.java.Point Point} (within the sublocation).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get beacon point
     * Point point = beacon.getPoint();
     * if (point != null) {
     *    demonstratePointUsage(point);
     * }
     * }
     * </pre>
     * @return beacon's X and Y coordinates in meters as {@link Point Point} (within the sublocation).
     */
    public abstract Point getPoint();

    /**
     * beacon's location identifier.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get beacon location ID
     * int locationId = beacon.getLocationId();
     * System.out.println("Beacon location ID: " + locationId);
     * }
     * </pre>
     * @return beacon's location identifier.
     */
    public abstract int getLocationId();

    /**
     * beacon's sublocation identifier.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get beacon sublocation ID
     * int sublocationId = beacon.getSublocationId();
     * System.out.println("Beacon sublocation ID: " + sublocationId);
     * }
     * </pre>
     * @return beacon's sublocation identifier.
     */
    public abstract int getSublocationId();

    /**
     * beacon's name.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get beacon name
     * String beaconName = beacon.getName();
     * System.out.println("Beacon name: " + beaconName);
     * }
     * </pre>
     * @return beacon's name.
     */
    public abstract String getName();

    /**
     * beacon's major. Values [1-65535]
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get beacon major
     * int major = beacon.getMajor();
     * System.out.println("Beacon major: " + major);
     * }
     * </pre>
     * @return beacon's major. Values [1-65535]
     */
    public abstract int getMajor();

    /**
     * beacon's minor. Values [1-65535]
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get beacon minor
     * int minor = beacon.getMinor();
     * System.out.println("Beacon minor: " + minor);
     * }
     * </pre>
     * @return beacon's minor. Values [1-65535]
     */
    public abstract int getMinor();

    /**
     * beacon's uuid. Format [XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX]
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get beacon UUID
     * String uuid = beacon.getUuid();
     * System.out.println("Beacon UUID: " + uuid);
     * }
     * </pre>
     * @return beacon's uuid. Format [XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX]
     */
    public abstract String getUuid();

    /**
     * beacon's power.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get beacon power
     * Integer power = beacon.getPower();
     * if (power != null) {
     *    System.out.println("Beacon power: " + power);
     * }
     * }
     * </pre>
     * @return beacon's power.
     */
    public abstract Integer getPower();

    /**
     * iBeacon status. {@link com.navigine.idl.java.TransmitterStatus TransmitterStatus}
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get beacon status
     * TransmitterStatus status = beacon.getStatus();
     * System.out.println("Beacon status: " + status);
     * }
     * </pre>
     * @return iBeacon status. {@link TransmitterStatus TransmitterStatus}
     */
    public abstract TransmitterStatus getStatus();

    /**
     * Tells if this {@link Beacon} is valid or not. Any other method
     * (except for this one) called on an invalid {@link Beacon} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
