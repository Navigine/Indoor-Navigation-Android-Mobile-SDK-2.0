package com.navigine.idl.java;

public abstract class LocationEditListener {
    public abstract void onLocationEditSuccess(Location location);

    public abstract void onLocationEditError(java.lang.Error error);
}
