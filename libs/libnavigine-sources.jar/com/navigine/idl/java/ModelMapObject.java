package com.navigine.idl.java;

/**
 * A 3D model map object (Wavefront OBJ) placed on the location view.
 * Geometry and texture come from {@link com.navigine.idl.java.ModelProvider ModelProvider}. The mesh is loaded asynchronously in the render pipeline; blocking calls occur only inside provider callbacks.
 * Referenced from {@link com.navigine.idl.java.LocationWindow LocationWindow} (addModelMapObject).
 */
public abstract class ModelMapObject extends MapObject {
    /**
     * Sets the anchor position of the model in metric coordinates.
     * @param point Center / placement point {@link com.navigine.idl.java.LocationPoint LocationPoint}.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * LocationPoint modelPoint = new LocationPoint(12.0, 34.0);
     * boolean posOk = modelMapObject.setPosition(modelPoint);
     * System.out.println("Model setPosition: " + posOk);
     * }
     * </pre>
     */
    public abstract boolean setPosition(LocationPoint point);

    /**
     * Animates the model anchor to a new position.
     * @param point Target metrics coordinates {@link com.navigine.idl.java.LocationPoint LocationPoint}.
     * @param duration Animation duration in seconds.
     * @param type Animation easing {@link com.navigine.idl.java.AnimationType AnimationType}.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * boolean posAnimOk = modelMapObject.setPositionAnimated(
     *    new LocationPoint(15.0, 40.0), 0.5f, AnimationType.SINE);
     * System.out.println("Model setPositionAnimated: " + posAnimOk);
     * }
     * </pre>
     */
    public abstract boolean setPositionAnimated(LocationPoint point, float duration, AnimationType type);

    /**
     * Sets the 3D asset (OBJ source + texture ImageProvider).
     * @param model Model provider {@link com.navigine.idl.java.ModelProvider ModelProvider}.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * ImageProvider texture = ImageProvider.fromFile("/path/to/model_texture.png", true);
     * ModelProvider model = ModelProvider.fromFile("/path/to/model.obj", texture);
     * boolean modelOk = modelMapObject.setModel(model);
     * System.out.println("Model setModel: " + modelOk);
     * }
     * </pre>
     */
    public abstract boolean setModel(com.navigine.model.ModelProvider model);

    /**
     * Sets the on-screen size of the model in pixels (width and height).
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * boolean sizeOk = modelMapObject.setSize(64.0f, 64.0f);
     * System.out.println("Model setSize: " + sizeOk);
     * }
     * </pre>
     */
    public abstract boolean setSize(float width, float height);

    /**
     * Enables or disables collision tests for this object.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * boolean collOk = modelMapObject.setCollisionEnabled(true);
     * System.out.println("Model setCollisionEnabled: " + collOk);
     * }
     * </pre>
     */
    public abstract boolean setCollisionEnabled(boolean enabled);

    /**
     * Sets rotation angle in degrees (around the placement axis used by the engine).
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * boolean angleOk = modelMapObject.setAngle(45.0f);
     * System.out.println("Model setAngle: " + angleOk);
     * }
     * </pre>
     */
    public abstract boolean setAngle(float angle);

    /**
     * Animates rotation to the given angle.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * boolean angleAnimOk = modelMapObject.setAngleAnimated(90.0f, 0.5f, AnimationType.QUINT);
     * System.out.println("Model setAngleAnimated: " + angleAnimOk);
     * }
     * </pre>
     */
    public abstract boolean setAngleAnimated(float angle, float duration, AnimationType type);

    /**
     * Extra hit-test padding around the model in pixels.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * boolean bufOk = modelMapObject.setBuffer(4.0f, 4.0f);
     * System.out.println("Model setBuffer: " + bufOk);
     * }
     * </pre>
     */
    public abstract boolean setBuffer(float width, float height);

    /**
     * Render order priority (higher draws above).
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * boolean priOk = modelMapObject.setPriority(10.0f);
     * System.out.println("Model setPriority: " + priOk);
     * }
     * </pre>
     */
    public abstract boolean setPriority(float priority);

    /**
     * Tells if this {@link ModelMapObject} is valid or not. Any other method
     * (except for this one) called on an invalid {@link ModelMapObject} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
