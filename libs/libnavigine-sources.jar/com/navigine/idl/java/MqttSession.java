package com.navigine.idl.java;

import com.navigine.common.NativeObject;
import com.navigine.common.Subscription;

/**
 * Class is used for managing MQTT session and publishing position data to MQTT broker.
 * Referenced from {@link com.navigine.idl.java.NavigineSdk NavigineSdk}.
 */
public abstract class MqttSession {
    /**
     * Method is used to connect to MQTT broker and start publishing position data.
     * @param server MQTT broker server hostname or IP address.
     * @param port MQTT broker server port.
     * @param username MQTT broker username for authentication.
     * @param password MQTT broker password for authentication.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Connect to MQTT broker
     * // Server: MQTT broker hostname or IP address
     * // Port: MQTT broker port (typically 1883 for non-SSL, 8883 for SSL)
     * // Username: MQTT broker username for authentication
     * // Password: MQTT broker password for authentication
     * mqttSession.connect("mqtt.example.com", 1883, "username", "password");
     * }
     * </pre>
     */
    public abstract void connect(String server, int port, String username, String password);

    /**
     * Method is used to set MQTT sub-topic for publishing position data.
     * The final topic will be "navigine/mobile/positions/" + subTopic + "/" + deviceId.
     * @param subTopic MQTT sub-topic for publishing position data. Must match pattern [0-9a-zA-Z_-]+ and cannot be empty.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set MQTT sub-topic for publishing position data
     * // Final topic will be "navigine/mobile/positions/" + subTopic + "/" + deviceId
     * mqttSession.setSubTopic("location1");
     * }
     * </pre>
     */
    public abstract void setSubTopic(String subTopic);

    /**
     * Method is used to add {@link com.navigine.idl.java.MqttSessionListener MqttSessionListener} class element
     * which will notify about MQTT session connection state changes.
     * <p><b>Note:</b> Do not forget to remove listener if it is no longer needed!</p>
     * @param listener Corresponding {@link com.navigine.idl.java.MqttSessionListener MqttSessionListener} class.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Add MQTT session listener
     * mqttSession.addListener(mqttSessionListener);
     * }
     * </pre>
     */
    public abstract void addListener(MqttSessionListener listener);

    /**
     * Method is used for removing previously added {@link com.navigine.idl.java.MqttSessionListener MqttSessionListener} class element.
     * @param listener Corresponding {@link com.navigine.idl.java.MqttSessionListener MqttSessionListener} class to remove.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove first listener
     * mqttSession.removeListener(listener1);
     * }
     * </pre>
     */
    public abstract void removeListener(MqttSessionListener listener);

    /**
     * Method is used to disconnect from MQTT broker and stop publishing position data.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Disconnect from MQTT broker
     * mqttSession.disconnect();
     * }
     * </pre>
     */
    public abstract void disconnect();

    /**
     * Method is used to publish a custom message to a specified MQTT topic.
     * The message will be sent asynchronously and the result will be notified through
     * {@link com.navigine.idl.java.MqttSessionListener MqttSessionListener} callbacks (onMessagePublished for success, onError for failure).
     * <p><b>Note:</b> The MQTT session must be connected before calling this method. Use {@link com.navigine.idl.java.MqttSession#connect connect} method first.</p>
     * @param topic MQTT topic to publish the message to. Can be any valid MQTT topic string.
     * @param message Message content to publish. Can be any string (JSON, plain text, etc.).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Publish a custom message to a specific MQTT topic
     * // The message will be sent asynchronously and the result will be notified through listener callbacks
     * String customTopic = "custom/device/status";
     * String customMessage = "{\"status\": \"online\", \"timestamp\": " + System.currentTimeMillis() + "}";
     * mqttSession.publish(customTopic, customMessage);
     * }
     * </pre>
     */
    public abstract void publish(String topic, String message);
}
