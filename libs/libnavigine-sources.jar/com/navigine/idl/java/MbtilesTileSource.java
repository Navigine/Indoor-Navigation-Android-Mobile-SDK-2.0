package com.navigine.idl.java;

/**
 * Local MBTiles pack of outdoor vector tiles (`format=pbf` or `mvt`).
 * Tiles are read only from this file — no network. Default row numbering is
 * TMS; metadata {@code scheme=xyz} disables the Y flip.
 * Referenced from {@link com.navigine.idl.java.TileProvider TileProvider}.
 */
public final class MbtilesTileSource {


    /*package*/ final String path;

    /**
     * Default constructor for class MbtilesTileSource
     */
    public MbtilesTileSource(
            String path) {
        this.path = path;
    }

    /**
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * MbtilesTileSource offline = new MbtilesTileSource("/path/to/map.mbtiles");
     * }
     * </pre>
     * Absolute path to the `.mbtiles` file.
     * @return <java>
     */
    public String getPath() {
        return path;
    }

    @Override
    public String toString() {
        return "MbtilesTileSource{" +
                "path=" + path +
        "}";
    }

}
