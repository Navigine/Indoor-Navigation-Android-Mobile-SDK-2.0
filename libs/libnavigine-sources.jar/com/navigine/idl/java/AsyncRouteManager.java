package com.navigine.idl.java;

/**
 * Class is used for managing {@link com.navigine.idl.java.RouteSession RouteSession}s
 * Referenced from {@link com.navigine.idl.java.NavigineSdk NavigineSdk}.
 */
public abstract class AsyncRouteManager {
    /**
     * Method is used to create routing session with 'default' graph tag
     * @param wayPoint destination point.
     * @param routeOptions params of {@link com.navigine.idl.java.RouteSession RouteSession}.
     * @return {@link com.navigine.idl.java.RouteSession RouteSession} instance.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Create route session with default graph tag
     * RouteSession session = asyncRouteManager.createRouteSession(destinationLocationPoint, routeOptions);
     * System.out.println("Created route session with default graph tag");
     * }
     * </pre>
     */
    public abstract RouteSession createRouteSession(LocationPoint wayPoint, RouteOptions routeOptions);

    /**
     * Creates a routing session using a specific graph tag.
     * Initializes a {@link com.navigine.idl.java.RouteSession RouteSession} for building a route to the given waypoint using the specified routing options and graph tag.
     * If the specified tag is not present in the current location (i.e., the corresponding sublocation graph is not yet available),
     * the returned {@link com.navigine.idl.java.RouteSession RouteSession} will produce an empty route and will not trigger any listeners until the location data
     * for that tag becomes available (e.g., after a location update).
     * @param wayPoint Destination point for the route.
     * @param routeOptions Routing parameters {@link com.navigine.idl.java.RouteSession RouteSession} used to build the route.
     * @param tag Graph tag identifying which sublocation graph to use. {@link com.navigine.idl.java.Sublocation Sublocation}
     * @return A RouteSession instance, which may initially be empty if the tag is not available. {@link com.navigine.idl.java.RouteSession RouteSession}
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Create route session with specific graph tag
     * RouteSession sessionWithTag = asyncRouteManager.createRouteSessionWithTag(destinationLocationPoint, routeOptions, "main");
     * System.out.println("Created route session with 'main' graph tag");
     * }
     * </pre>
     */
    public abstract RouteSession createRouteSessionWithTag(LocationPoint wayPoint, RouteOptions routeOptions, String tag);

    /**
     * Method is used to cancel routing session
     * @param session {@link com.navigine.idl.java.RouteSession RouteSession} object to cancel.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Cancel route session
     * asyncRouteManager.cancelRouteSession(sessions.get(i));
     * System.out.println("Cancelled session " + (i + 1));
     * }
     * </pre>
     */
    public abstract void cancelRouteSession(RouteSession session);
}
