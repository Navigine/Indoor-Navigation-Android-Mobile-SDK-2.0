package com.navigine.idl.java;

public abstract class ReferenceEntry {
    public abstract ReferenceEntryType getType();

    public abstract String getBssid();

    public abstract String getValue();

    /**
     * Tells if this {@link ReferenceEntry} is valid or not. Any other method
     * (except for this one) called on an invalid {@link ReferenceEntry} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
