package com.navigine.idl.java;

/**
 * Walk progress. `onFinished` follows the last sample.
 */
public abstract class RouteSimulatorListener {
    public abstract void onSample(RouteSimulatorSample sample);

    public abstract void onFinished();
}
