package com.navigine.idl.java;

/**
 * Operating mode of the location view.
 * Controls whether the view shows indoor floors only, an outdoor vector basemap,
 * or outdoor basemap with indoor building overlays.
 */
public enum OperatingMode {
    /**
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * OperatingMode[] modes = {
     *    OperatingMode.INDOOR_ONLY,
     *    OperatingMode.OUTDOOR,
     *    OperatingMode.OUTDOOR_INDOOR
     * };
     * System.out.println("Operating modes: " + modes.length);
     * }
     * </pre>
     * Indoor floors only (no outdoor vector basemap).
     * Camera stick-to-border / centering apply to the active floor plan.
     */
    INDOOR_ONLY,
    /**
     * Outdoor vector basemap only (OSM MVT).
     */
    OUTDOOR,
    /**
     * Outdoor vector basemap plus indoor building floor overlays.
     */
    OUTDOOR_INDOOR,
    ;
}
