package com.navigine.idl.java;

import java.util.HashMap;

/**
 * Class is used to handle for picking objects on the location view
 * Referenced from {@link com.navigine.idl.java.LocationWindow LocationWindow}.
 */
public abstract class PickListener {
    /**
     * Receive the result from {@link com.navigine.idl.java.LocationWindow LocationWindow} `pickMapObjectAt` method
     * @param mapObjectPickResult {@link com.navigine.idl.java.MapObjectPickResult MapObjectPickResult} instance or {@code nil} if no objects was found.
     * @param screenPosition position where the object was picked in pixels.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * @Override
     * public void onMapObjectPickComplete(MapObjectPickResult mapObjectPickResult, Point screenPosition) {
     *    if (mapObjectPickResult != null) {
     *        // [java_MapObjectPickResult_getPoint]
     *        LocationPoint point = mapObjectPickResult.getPoint();
     *        System.out.println("Map object picked at screen position (" + screenPosition.x + ", " + screenPosition.y + ")");
     *        System.out.println("  Object location: (" + point.getX() + ", " + point.getY() + ")");
     *        // [java_MapObjectPickResult_getPoint]
     *        // [java_MapObjectPickResult_getMapObject]
     *        MapObject mapObject = mapObjectPickResult.getMapObject();
     *        System.out.println("  Object type: " + mapObject.getClass().getSimpleName());
     *        // [java_MapObjectPickResult_getMapObject]
     *    } else {
     *        System.out.println("No map object found at screen position (" + screenPosition.x + ", " + screenPosition.y + ")");
     *    }
     * }
     * }
     * </pre>
     */
    public abstract void onMapObjectPickComplete(MapObjectPickResult mapObjectPickResult, android.graphics.PointF screenPosition);

    /**
     * Receive the result from {@link com.navigine.idl.java.LocationWindow LocationWindow} `pickMapFeatureAt`
     * @param mapFeaturePickResult dictionary of properties of the picked feature or {@code nil} if no objects was found.
     * @param screenPosition position where the object was picked in pixels.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * @Override
     * public void onMapFeaturePickComplete(Map<String, String> mapFeaturePickResult, Point screenPosition) {
     *    if (mapFeaturePickResult != null) {
     *        System.out.println("Map feature picked at screen position (" + screenPosition.x + ", " + screenPosition.y + ")");
     *        System.out.println("  Feature properties: " + mapFeaturePickResult);
     *    } else {
     *        System.out.println("No map feature found at screen position (" + screenPosition.x + ", " + screenPosition.y + ")");
     *    }
     * }
     * }
     * </pre>
     */
    public abstract void onMapFeaturePickComplete(HashMap<String, String> mapFeaturePickResult, android.graphics.PointF screenPosition);
}
