package com.navigine.idl.java;

/**
 * Class is used for storing venue.
 * Referenced from {@link com.navigine.idl.java.Sublocation Sublocation}.
 */
public abstract class Venue {
    /**
     * venue's X and Y coordinates in meters as {@link com.navigine.idl.java.Point Point} (within the sublocation).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get venue point
     * Point point = venue.getPoint();
     * if (point != null) {
     *    demonstratePointUsage(point);
     * }
     * }
     * </pre>
     * @return venue's X and Y coordinates in meters as {@link Point Point} (within the sublocation).
     */
    public abstract Point getPoint();

    /**
     * venue's location identifier.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get venue location ID
     * int locationId = venue.getLocationId();
     * System.out.println("Venue location ID: " + locationId);
     * }
     * </pre>
     * @return venue's location identifier.
     */
    public abstract int getLocationId();

    /**
     * venue's sublocation identifier.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get venue sublocation ID
     * int sublocationId = venue.getSublocationId();
     * System.out.println("Venue sublocation ID: " + sublocationId);
     * }
     * </pre>
     * @return venue's sublocation identifier.
     */
    public abstract int getSublocationId();

    /**
     * venue's identifier.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get venue ID
     * int venueId = venue.getId();
     * System.out.println("Venue ID: " + venueId);
     * }
     * </pre>
     * @return venue's identifier.
     */
    public abstract int getId();

    /**
     * venue's name.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get venue name
     * String venueName = venue.getName();
     * System.out.println("Venue name: " + venueName);
     * }
     * </pre>
     * @return venue's name.
     */
    public abstract String getName();

    /**
     * venue's phone.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get venue phone
     * String phone = venue.getPhone();
     * System.out.println("Venue phone: " + phone);
     * }
     * </pre>
     * @return venue's phone.
     */
    public abstract String getPhone();

    /**
     * venue's description.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get venue description
     * String venueDescription = venue.getDescript();
     * System.out.println("Venue description: " + venueDescription);
     * }
     * </pre>
     * @return venue's description.
     */
    public abstract String getDescript();

    /**
     * venue's alias.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get venue alias
     * String alias = venue.getAlias();
     * System.out.println("Venue alias: " + alias);
     * }
     * </pre>
     * @return venue's alias.
     */
    public abstract String getAlias();

    /**
     * venue's category unique identifier {@link com.navigine.idl.java.Category Category}
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get category ID
     * int categoryId = venue.getCategoryId();
     * System.out.println("Venue category ID: " + categoryId);
     * }
     * </pre>
     * @return venue's category unique identifier {@link Category Category}
     */
    public abstract int getCategoryId();

    /**
     * venue's image url if specified.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get venue image URL
     * String imageUrl = venue.getImageUrl();
     * if (imageUrl != null) {
     *    System.out.println("Venue image URL: " + imageUrl);
     * }
     * }
     * </pre>
     * @return venue's image url if specified.
     */
    public abstract String getImageUrl();

    /**
     * Tells if this {@link Venue} is valid or not. Any other method
     * (except for this one) called on an invalid {@link Venue} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
