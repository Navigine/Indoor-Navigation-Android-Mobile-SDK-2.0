package com.navigine.idl.java;

/**
 * Vector tile schema of the outdoor basemap.
 * The renderer stylesheet is built for these schemas only. The MVT layers
 * and properties must match the chosen schema.
 */
public enum TileSchema {
    /**
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * TileSchema[] schemas = { TileSchema.SHORTBREAD, TileSchema.OPEN_MAP_TILES, TileSchema.MAPBOX_STREETS };
     * System.out.println("Tile schemas: " + schemas.length);
     * }
     * </pre>
     * OSM Shortbread (versatiles / vector.openstreetmap.org).
     */
    SHORTBREAD,
    /**
     * OpenMapTiles (MapTiler / Planetiler self-host).
     */
    OPEN_MAP_TILES,
    /**
     * Mapbox Streets v8 (`mapbox.mapbox-streets-v8`).
     */
    MAPBOX_STREETS,
    ;
}
