package com.navigine.idl.java;

/**
 * Class provides callbacks to be invoked when MQTT session connection state changes.
 * Referenced from {@link com.navigine.idl.java.MqttSession MqttSession}.
 * <p><b>Note:</b> The callbacks are invoked in the UI thread.</p>
 */
public abstract class MqttSessionListener {
    /**
     * Called when MQTT session has been successfully connected to the server.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * public void onConnected() {
     *    System.out.println("MQTT session connected successfully");
     * }
     * }
     * </pre>
     */
    public abstract void onConnected();

    /**
     * Called if MQTT session connection failed or was lost.
     * @param error handled error.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * public void onError(Error error) {
     *    System.err.println("MQTT session error: " + error.getMessage());
     * }
     * }
     * </pre>
     */
    public abstract void onError(java.lang.Error error);

    /**
     * Called when a message has been successfully published to MQTT broker.
     * This callback is invoked after a message (either position data or custom message)
     * has been successfully sent to the MQTT broker.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * public void onMessagePublished() {
     *    System.out.println("Message published successfully");
     * }
     * }
     * </pre>
     */
    public abstract void onMessagePublished();
}
