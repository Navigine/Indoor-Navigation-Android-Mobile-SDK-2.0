package com.navigine.idl.java;

/**
 * Class described user zone event.
 * Referenced from {@link com.navigine.idl.java.ZoneListener ZoneListener}.
 */
public final class ZoneEvent {


    /*package*/ final ZoneEventType type;

    /*package*/ final int locationId;

    /*package*/ final int sublocationId;

    /*package*/ final int id;

    /*package*/ final String name;

    /*package*/ final String alias;

    /**
     * Default constructor for class ZoneEvent
     */
    public ZoneEvent(
            ZoneEventType type,
            int locationId,
            int sublocationId,
            int id,
            String name,
            String alias) {
        this.type = type;
        this.locationId = locationId;
        this.sublocationId = sublocationId;
        this.id = id;
        this.name = name;
        this.alias = alias;
    }

    /**
     * Handled zone event type.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get event type
     * ZoneEventType type = zoneEvent.getType();
     * System.out.println("Zone event type: " + type);
     * }
     * </pre>
     * @return Handled zone event type.
     */
    public ZoneEventType getType() {
        return type;
    }

    /**
     * zone's location identifier.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get location ID
     * int locationId = zoneEvent.getLocationId();
     * System.out.println("Zone location ID: " + locationId);
     * }
     * </pre>
     * @return zone's location identifier.
     */
    public int getLocationId() {
        return locationId;
    }

    /**
     * zone's sublocationId identifier.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get sublocation ID
     * int sublocationId = zoneEvent.getSublocationId();
     * System.out.println("Zone sublocation ID: " + sublocationId);
     * }
     * </pre>
     * @return zone's sublocationId identifier.
     */
    public int getSublocationId() {
        return sublocationId;
    }

    /**
     * zone's identifier.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get zone ID
     * int id = zoneEvent.getId();
     * System.out.println("Zone ID: " + id);
     * }
     * </pre>
     * @return zone's identifier.
     */
    public int getId() {
        return id;
    }

    /**
     * zone's name.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get zone name
     * String name = zoneEvent.getName();
     * System.out.println("Zone name: " + name);
     * }
     * </pre>
     * @return zone's name.
     */
    public String getName() {
        return name;
    }

    /**
     * zone's alias.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get zone alias
     * String alias = zoneEvent.getAlias();
     * System.out.println("Zone alias: " + alias);
     * }
     * </pre>
     * @return zone's alias.
     */
    public String getAlias() {
        return alias;
    }

    @Override
    public String toString() {
        return "ZoneEvent{" +
                "type=" + type +
                "," + "locationId=" + locationId +
                "," + "sublocationId=" + sublocationId +
                "," + "id=" + id +
                "," + "name=" + name +
                "," + "alias=" + alias +
        "}";
    }

}
