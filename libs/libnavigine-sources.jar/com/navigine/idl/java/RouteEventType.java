package com.navigine.idl.java;

/**
 * Enum describing route event variants.
 * Referenced from {@link com.navigine.idl.java.RouteEvent RouteEvent}.
 *
 * <p><b>Example:</b></p>
 * <pre>
 * {@code
 * // Get all route event type values
 * RouteEventType[] types = RouteEventType.values();
 * System.out.println("Available route event types:");
 * for (RouteEventType type : types) {
 *    System.out.println("  - " + type);
 * }
 * }
 * </pre>
 */
public enum RouteEventType {
    TURN_EVENT,
    TRANSITION_ENTRY_EVENT,
    TRANSITION_EXIT_EVENT,
    TARGET_REACHED_EVENT,
    ;
}
