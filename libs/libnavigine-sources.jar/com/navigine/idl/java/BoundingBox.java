package com.navigine.idl.java;

/**
 * Axis-aligned bounding box defined by two WGS84 corners.
 *
 * <p><b>Example:</b></p>
 * <pre>
 * {@code
 * BoundingBox boundingBox = new BoundingBox(bottomLeft, topRight);
 * System.out.printf("Created bounding box: bottomLeft(%.4f, %.4f), topRight(%.4f, %.4f)%n",
 *        boundingBox.getBottomLeft().getLatitude(), boundingBox.getBottomLeft().getLongitude(),
 *        boundingBox.getTopRight().getLatitude(), boundingBox.getTopRight().getLongitude());
 * }
 * </pre>
 */
public final class BoundingBox {


    /*package*/ final GlobalPoint bottomLeft;

    /*package*/ final GlobalPoint topRight;

    /**
     * Default constructor for class BoundingBox
     */
    public BoundingBox(
            GlobalPoint bottomLeft,
            GlobalPoint topRight) {
        this.bottomLeft = bottomLeft;
        this.topRight = topRight;
    }

    /**
     * Lower-left corner of the bounding box {@link com.navigine.idl.java.GlobalPoint GlobalPoint}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * GlobalPoint leftCorner = boundingBox.getBottomLeft();
     * System.out.printf("Bottom-left corner: (%.4f, %.4f)%n", leftCorner.getLatitude(), leftCorner.getLongitude());
     * }
     * </pre>
     * @return Lower-left corner of the bounding box {@link GlobalPoint GlobalPoint}.
     */
    public GlobalPoint getBottomLeft() {
        return bottomLeft;
    }

    /**
     * Upper-right corner of the bounding box {@link com.navigine.idl.java.GlobalPoint GlobalPoint}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * GlobalPoint rightCorner = boundingBox.getTopRight();
     * System.out.printf("Top-right corner: (%.4f, %.4f)%n", rightCorner.getLatitude(), rightCorner.getLongitude());
     * }
     * </pre>
     * @return Upper-right corner of the bounding box {@link GlobalPoint GlobalPoint}.
     */
    public GlobalPoint getTopRight() {
        return topRight;
    }

    @Override
    public String toString() {
        return "BoundingBox{" +
                "bottomLeft=" + bottomLeft +
                "," + "topRight=" + topRight +
        "}";
    }

}
