package com.navigine.idl.java;

/**
 * Axis-aligned bounding box defined by two corner points.
 *
 * <p><b>Example:</b></p>
 * <pre>
 * {@code
 * BoundingBox boundingBox = new BoundingBox(bottomLeft, topRight);
 * System.out.printf("Created bounding box: bottomLeft(%.1f, %.1f), topRight(%.1f, %.1f)%n",
 *        boundingBox.getBottomLeft().getX(), boundingBox.getBottomLeft().getY(),
 *        boundingBox.getTopRight().getX(), boundingBox.getTopRight().getY());
 * }
 * </pre>
 */
public final class BoundingBox {


    /*package*/ final Point bottomLeft;

    /*package*/ final Point topRight;

    /**
     * Default constructor for class BoundingBox
     */
    public BoundingBox(
            Point bottomLeft,
            Point topRight) {
        this.bottomLeft = bottomLeft;
        this.topRight = topRight;
    }

    /**
     * Lower-left corner of the bounding box.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * Point leftCorner = boundingBox.getBottomLeft();
     * System.out.printf("Bottom-left corner: (%.1f, %.1f)%n", leftCorner.getX(), leftCorner.getY());
     * }
     * </pre>
     * @return Lower-left corner of the bounding box.
     */
    public Point getBottomLeft() {
        return bottomLeft;
    }

    /**
     * Upper-right corner of the bounding box.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * Point rightCorner = boundingBox.getTopRight();
     * System.out.printf("Top-right corner: (%.1f, %.1f)%n", rightCorner.getX(), rightCorner.getY());
     * }
     * </pre>
     * @return Upper-right corner of the bounding box.
     */
    public Point getTopRight() {
        return topRight;
    }

    @Override
    public String toString() {
        return "BoundingBox{" +
                "bottomLeft=" + bottomLeft +
                "," + "topRight=" + topRight +
        "}";
    }

}
