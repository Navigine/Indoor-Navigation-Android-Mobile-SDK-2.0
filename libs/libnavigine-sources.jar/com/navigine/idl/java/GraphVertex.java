package com.navigine.idl.java;

/**
 * Class is used for storing graph vertex.
 */
public abstract class GraphVertex {
    /**
     * graph vertex unique identifier.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get vertex ID
     * int vertexId = vertex.getId();
     * System.out.println("Vertex ID: " + vertexId);
     * }
     * </pre>
     * @return graph vertex unique identifier.
     */
    public abstract int getId();

    /**
     * graph vertex position in meters {@link com.navigine.idl.java.Point Point}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get vertex point
     * Point point = vertex.getPoint();
     * if (point != null) {
     *    demonstratePointUsage(point);
     * }
     * }
     * </pre>
     * @return graph vertex position in meters {@link Point Point}.
     */
    public abstract Point getPoint();

    /**
     * graph vertex name.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get vertex name
     * String name = vertex.getName();
     * System.out.println("Vertex name: " + name);
     * }
     * </pre>
     * @return graph vertex name.
     */
    public abstract String getName();

    /**
     * graph vertex can be used to communicate with external graphs or not.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get vertex external flag
     * boolean isExternal = vertex.getIsExternal();
     * System.out.println("Vertex is external: " + isExternal);
     * }
     * </pre>
     * @return graph vertex can be used to communicate with external graphs or not.
     */
    public abstract boolean getIsExternal();

    /**
     * graph vertex used in elevation graph {@link com.navigine.idl.java.ElevationGraph ElevationGraph} or not.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get vertex elevation flag
     * boolean isElevation = vertex.getIsElevation();
     * System.out.println("Vertex is elevation: " + isElevation);
     * }
     * </pre>
     * @return graph vertex used in elevation graph {@link ElevationGraph ElevationGraph} or not.
     */
    public abstract boolean getIsElevation();

    /**
     * Tells if this {@link GraphVertex} is valid or not. Any other method
     * (except for this one) called on an invalid {@link GraphVertex} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
