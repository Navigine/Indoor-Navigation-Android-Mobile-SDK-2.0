package com.navigine.idl.java;

/**
 * Class is used for working with the notifications and storing its data.
 * Referenced from: {@link com.navigine.idl.java.NotificationListener NotificationListener}.
 */
public abstract class Notification {
    /**
     * notification's unique identifier.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get notification ID
     * int id = notification.getId();
     * System.out.println("Notification ID: " + id);
     * }
     * </pre>
     * @return notification's unique identifier.
     */
    public abstract int getId();

    /**
     * notification's title.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get notification title
     * String title = notification.getTitle();
     * System.out.println("Notification title: " + title);
     * }
     * </pre>
     * @return notification's title.
     */
    public abstract String getTitle();

    /**
     * notification's content.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get notification content
     * String content = notification.getContent();
     * System.out.println("Notification content: " + content);
     * }
     * </pre>
     * @return notification's content.
     */
    public abstract String getContent();

    /**
     * notification's image url if specified.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get notification image URL
     * String imageUrl = notification.getImageUrl();
     * if (imageUrl != null && !imageUrl.isEmpty()) {
     *    System.out.println("Notification image URL: " + imageUrl);
     * } else {
     *    System.out.println("Notification has no image URL");
     * }
     * }
     * </pre>
     * @return notification's image url if specified.
     */
    public abstract String getImageUrl();

    /**
     * Tells if this {@link Notification} is valid or not. Any other method
     * (except for this one) called on an invalid {@link Notification} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
