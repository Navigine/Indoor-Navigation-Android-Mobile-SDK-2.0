package com.navigine.idl.java;

import java.util.HashMap;

/**
 * Class provides callbacks to be invoked when {@link com.navigine.idl.java.MeasurementManager MeasurementManager}
 * detects new sensor or signal measurements.
 * Referenced from {@link com.navigine.idl.java.MeasurementManager MeasurementManager}.
 * <p><b>Note:</b> The callbacks are invoked in the UI thread.</p>
 */
public abstract class MeasurementListener {
    /**
     * Called when new sensor measurements are detected.
     * @param sensors A map of sensor types to their corresponding {@link com.navigine.idl.java.SensorMeasurement SensorMeasurement} values.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * public void onSensorMeasurementDetected(Map<SensorType, SensorMeasurement> sensors) {
     *    System.out.println("Sensor measurements detected");
     *    demonstrateSensorMeasurements(sensors);
     * }
     * }
     * </pre>
     */
    public abstract void onSensorMeasurementDetected(HashMap<SensorType, SensorMeasurement> sensors);

    /**
     * Called when new signal measurements are detected.
     * @param signals A map of signal identifiers to their corresponding {@link com.navigine.idl.java.SignalMeasurement SignalMeasurement} values.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * public void onSignalMeasurementDetected(Map<String, SignalMeasurement> signals) {
     *    System.out.println("Signal measurements detected");
     *    demonstrateSignalMeasurements(signals);
     * }
     * }
     * </pre>
     */
    public abstract void onSignalMeasurementDetected(HashMap<String, SignalMeasurement> signals);
}
