package com.navigine.idl.java;

/**
 * Provides access to all services in the SDK.
 * Class contains a list of static functions for initializing library
 * and list of functions for getting access to the managers,
 * each of which will provide different opportunities for working with SDK
 * <p><b>Note:</b> SDK holds objects by weak references. You need</p>
 * to have strong references to them somewhere in the client code.
 */
public abstract class NavigineSdk {
    /**
     * Method is used to set `USER_HASH` from the user's profile in CMS
     * @param userHash auth token in format XXXX-XXXX-XXXX-XXXX
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set user hash (authorization token)
     * sdk.setUserHash("XXXX-XXXX-XXXX-XXXX");
     * }
     * </pre>
     */
    public abstract void setUserHash(String userHash);

    /**
     * Method is used to set server url
     * @param server custom server url in format: {@code http[s]://example.com}
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set server URL (optional)
     * sdk.setServer("https://custom.navigine.com");
     * }
     * </pre>
     */
    public abstract void setServer(String server);

    /**
     * Resets SDK to the initial connection state: default production server URL, empty user hash, and a new session propagated to managers (same effect on session-aware managers as changing server or user hash). Call from the UI thread.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * sdk.reset();
     * System.out.println("SDK reset to initial state");
     * }
     * </pre>
     */
    public abstract void reset();

    /**
     * {@link com.navigine.idl.java.LocationManager LocationManager} instance, which could be used for working with the {@link com.navigine.idl.java.Location Location}.
     * @return {@link com.navigine.idl.java.LocationManager LocationManager} instance
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get LocationManager for working with locations
     * locationManager = sdk.getLocationManager();
     * if (locationManager != null) {
     *    System.out.println("LocationManager successfully initialized");
     * }
     * }
     * </pre>
     */
    public abstract LocationManager getLocationManager();

    /**
     * {@link com.navigine.idl.java.NavigationManager NavigationManager} instance, which could be used for working with the @see Position.
     * @param locationManager {@link com.navigine.idl.java.LocationManager LocationManager} instance
     * @return {@link com.navigine.idl.java.NavigationManager NavigationManager} instance
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get NavigationManager for navigation
     * if (locationManager != null) {
     *    navigationManager = sdk.getNavigationManager(locationManager);
     *    if (navigationManager != null) {
     *        System.out.println("NavigationManager successfully initialized");
     *    }
     * }
     * }
     * </pre>
     */
    public abstract NavigationManager getNavigationManager(LocationManager locationManager);

    /**
     * {@link com.navigine.idl.java.ZoneManager ZoneManager} instance, which could be used for working with zones and detecting enter and leave events. {@link com.navigine.idl.java.Zone Zone}
     * @param navigationManager {@link com.navigine.idl.java.NavigationManager NavigationManager} instance
     * @return {@link com.navigine.idl.java.ZoneManager ZoneManager} instance
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get ZoneManager for working with zones
     * if (navigationManager != null) {
     *    zoneManager = sdk.getZoneManager(navigationManager);
     *    if (zoneManager != null) {
     *        System.out.println("ZoneManager successfully initialized");
     *    }
     * }
     * }
     * </pre>
     */
    public abstract ZoneManager getZoneManager(NavigationManager navigationManager);

    /**
     * {@link com.navigine.idl.java.AsyncRouteManager AsyncRouteManager} instance, which could be used for working with routing sessions. {@link com.navigine.idl.java.RouteSession RouteSession}
     * @param locationManager {@link com.navigine.idl.java.LocationManager LocationManager} instance
     * @param navigationManager {@link com.navigine.idl.java.NavigationManager NavigationManager} instance
     * @return {@link com.navigine.idl.java.AsyncRouteManager AsyncRouteManager} instance
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get AsyncRouteManager for async route operations
     * if (locationManager != null && navigationManager != null) {
     *    asyncRouteManager = sdk.getAsyncRouteManager(locationManager, navigationManager);
     *    if (asyncRouteManager != null) {
     *        System.out.println("AsyncRouteManager successfully initialized");
     *    }
     * }
     * }
     * </pre>
     */
    public abstract AsyncRouteManager getAsyncRouteManager(LocationManager locationManager, NavigationManager navigationManager);

    /**
     * {@link com.navigine.idl.java.NotificationManager NotificationManager} instance, which could be used for working with notifications when detecting beacons. {@link com.navigine.idl.java.Notification Notification}
     * @param locationManager {@link com.navigine.idl.java.LocationManager LocationManager} instance
     * @return {@link com.navigine.idl.java.NotificationManager NotificationManager} instance
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get NotificationManager for notifications
     * if (locationManager != null) {
     *    notificationManager = sdk.getNotificationManager(locationManager);
     *    if (notificationManager != null) {
     *        System.out.println("NotificationManager successfully initialized");
     *    }
     * }
     * }
     * </pre>
     */
    public abstract NotificationManager getNotificationManager(LocationManager locationManager);

    public abstract String getErrorDescription(int errorCode);

    public abstract LocationWindow createLocationWindow(com.navigine.view.PlatformView platformView);

    /**
     * Returns a manager that allows to manage user storages
     * @return Storage manager instance {@link com.navigine.idl.java.StorageManager StorageManager}
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get StorageManager for working with storages
     * storageManager = sdk.getStorageManager();
     * if (storageManager != null) {
     *    System.out.println("StorageManager successfully initialized");
     * }
     * }
     * </pre>
     */
    public abstract StorageManager getStorageManager();

    /**
     * Create layer with the user location icon.
     */
    public abstract UserLocationLayer getUserLocationLayer(LocationWindow locationWindow);

    /**
     * {@link com.navigine.idl.java.RouteManager RouteManager} instance, which could be used for working making routes, setting target points. {@link com.navigine.idl.java.RoutePath RoutePath}
     * @param locationManager {@link com.navigine.idl.java.LocationManager LocationManager} instance
     * @param navigationManager {@link com.navigine.idl.java.NavigationManager NavigationManager} instance
     * @return {@link com.navigine.idl.java.RouteManager RouteManager} instance
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get RouteManager for building routes
     * if (locationManager != null && navigationManager != null) {
     *    routeManager = sdk.getRouteManager(locationManager, navigationManager);
     *    if (routeManager != null) {
     *        System.out.println("RouteManager successfully initialized");
     *    }
     * }
     * }
     * </pre>
     */
    public abstract RouteManager getRouteManager(LocationManager locationManager, NavigationManager navigationManager);

    /**
     * {@link com.navigine.idl.java.MeasurementManager MeasurementManager} instance, which could be used for managing measurement generators and handling sensor and signal measurements.
     * @param locationManager {@link com.navigine.idl.java.LocationManager LocationManager} instance
     * @return {@link com.navigine.idl.java.MeasurementManager MeasurementManager} instance
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get MeasurementManager for measurements
     * if (locationManager != null) {
     *    measurementManager = sdk.getMeasurementManager(locationManager);
     *    if (measurementManager != null) {
     *        System.out.println("MeasurementManager successfully initialized");
     *    }
     * }
     * }
     * </pre>
     */
    public abstract MeasurementManager getMeasurementManager(LocationManager locationManager);

    /**
     * Returns a manager that allows to manage resources
     * 1 - download and decode images
     * 2 - managing logs
     * @param locationManager {@link com.navigine.idl.java.LocationManager LocationManager} instance
     * @return Resource manager instance
     */
    public abstract ResourceManager getResourceManager(LocationManager locationManager);

    public abstract LocationEditManager getLocationEditManager(LocationManager locationManager);

    public abstract BeaconProximityEstimator getBeaconProximityEstimator(LocationManager locationManager);

    /**
     * {@link com.navigine.idl.java.MqttSession MqttSession} instance, which could be used for working with MQTT sessions.
     * @param navigationManager {@link com.navigine.idl.java.NavigationManager NavigationManager} instance
     * @return {@link com.navigine.idl.java.MqttSession MqttSession} instance
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get MqttSession for publishing position data via MQTT
     * if (navigationManager != null) {
     *    mqttSession = sdk.getMqttSession(navigationManager);
     *    if (mqttSession != null) {
     *        System.out.println("MqttSession successfully initialized");
     *    }
     * }
     * }
     * </pre>
     */
    public abstract MqttSession getMqttSession(NavigationManager navigationManager);

    /**
     * Returns a manager that allows to manage locations list
     * @return Location list manager instance {@link com.navigine.idl.java.LocationListManager LocationListManager}
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get LocationListManager for location list operations
     * locationListManager = sdk.getLocationListManager();
     * if (locationListManager != null) {
     *    System.out.println("LocationListManager successfully initialized");
     * }
     * }
     * </pre>
     */
    public abstract LocationListManager getLocationListManager();

    /**
     * Tells if this {@link NavigineSdk} is valid or not. Any other method
     * (except for this one) called on an invalid {@link NavigineSdk} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();

    /**
     * Method initializes Navigation library and returns NavigineSdk instance.
     * @return instance of SDK
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get SDK instance
     * sdk = NavigineSdk.getInstance();
     * }
     * </pre>
     */
    public static NavigineSdk getInstance()
    {
        return com.navigine.idl.java.internal.NavigineSdkBinding.getInstance();
    }

    /**
     * Method returns NavigineSdk SDK Version.
     * @return version of SDK
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get SDK version
     * System.out.println("Navigine SDK Version: " + NavigineSdk.getVersion());
     * }
     * </pre>
     */
    public static String getVersion()
    {
        return com.navigine.idl.java.internal.NavigineSdkBinding.getVersion();
    }

    /**
     * Method returns persistent device id.
     * @return persistent device id
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get device ID
     * System.out.println("Device ID: " + NavigineSdk.getDeviceId());
     * }
     * </pre>
     */
    public static String getDeviceId()
    {
        return com.navigine.idl.java.internal.NavigineSdkBinding.getDeviceId();
    }

    /**
     * Method returns current User-Agent string.
     * @return User-Agent string
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * System.out.println("User-Agent: " + NavigineSdk.getUserAgent());
     * }
     * </pre>
     */
    public static String getUserAgent()
    {
        return com.navigine.idl.java.internal.NavigineSdkBinding.getUserAgent();
    }

    /**
     * Method returns current timestamp.
     * @return internal timestamp
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get relative time
     * System.out.println("Relative Time: " + NavigineSdk.getRelativeTime());
     * }
     * </pre>
     */
    public static long getRelativeTime()
    {
        return com.navigine.idl.java.internal.NavigineSdkBinding.getRelativeTime();
    }
}
