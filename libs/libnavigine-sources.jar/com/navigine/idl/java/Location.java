package com.navigine.idl.java;

import java.util.ArrayList;

/**
 * Class is used for storing location parameters: identifier, version, name, a list of sublocations, etc.
 * Location instance can be obtained from {@link com.navigine.idl.java.LocationManager LocationManager} using {@link com.navigine.idl.java.LocationListener LocationListener} callback,
 * when the location is loaded.
 * Referenced from {@link com.navigine.idl.java.LocationManager LocationManager} {@link com.navigine.idl.java.LocationListener LocationListener}.
 */
public abstract class Location {
    /**
     * Method returns location elevation graph {@link com.navigine.idl.java.ElevationGraph ElevationGraph}
     * for specified tag
     * @param tag Graph tag in CMS
     * @return Elevation graph instance or {@code null}.
     * @return {@link com.navigine.idl.java.ElevationGraph ElevationGraph} of the current location with the specified tag, if it exists. If elevation graph with the specified tag doesn't exist, function returns null.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get elevation graph by tag
     * if (!graphTags.isEmpty()) {
     *    ElevationGraph elevationGraph = location.getElevationGraph(graphTags.get(0));
     *    if (elevationGraph != null) {
     *        demonstrateElevationGraphUsage(elevationGraph);
     *    }
     * }
     * }
     * </pre>
     */
    public abstract ElevationGraph getElevationGraph(String tag);

    /**
     * Method returns list of available graph tags.
     * @return Array of existing tags
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get available graph tags
     * java.util.ArrayList<String> graphTags = location.getGraphTags();
     * System.out.println("Available graph tags: " + graphTags);
     * }
     * </pre>
     */
    public abstract ArrayList<String> getGraphTags();

    /**
     * Method is used for obtaining a sublocation with the specified identifier from the current location.
     * @param id sublocation identifier.
     * @return The {@link com.navigine.idl.java.Sublocation Sublocation} of the current location with the specified identifier, if it exists. If sublocation with the specified identifier doesn't exist, function returns null.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get sublocation by ID
     * if (!sublocations.isEmpty()) {
     *    Sublocation sublocation = location.getSublocationById(sublocations.get(0).getId());
     *    if (sublocation != null) {
     *        demonstrateSublocationUsage(sublocation);
     *    }
     * }
     * }
     * </pre>
     */
    public abstract Sublocation getSublocationById(int id);

    /**
     * Method is used for obtaining a category with the specified identifier from the current location.
     * @param id category identifier.
     * @return {@link com.navigine.idl.java.Category Category} of the current location with the specified identifier, if it exists. If category with the specified identifier doesn't exist, function returns null.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get category by ID
     * if (!categories.isEmpty()) {
     *    Category category = location.getCategoryById(categories.get(0).getId());
     *    if (category != null) {
     *        demonstrateCategoryUsage(category);
     *    }
     * }
     * }
     * </pre>
     */
    public abstract Category getCategoryById(int id);

    /**
     * location's identifier.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get location ID
     * int locationId = location.getId();
     * System.out.println("Location ID: " + locationId);
     * }
     * </pre>
     * @return location's identifier.
     */
    public abstract int getId();

    /**
     * location's version.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get location version
     * int version = location.getVersion();
     * System.out.println("Location version: " + version);
     * }
     * </pre>
     * @return location's version.
     */
    public abstract int getVersion();

    /**
     * location name.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get location name
     * String name = location.getName();
     * System.out.println("Location name: " + name);
     * }
     * </pre>
     * @return location name.
     */
    public abstract String getName();

    /**
     * location's description.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get location description
     * String description = location.getDescript();
     * System.out.println("Location description: " + description);
     * }
     * </pre>
     * @return location's description.
     */
    public abstract String getDescript();

    /**
     * List of venue categories defined for the location {@link com.navigine.idl.java.Category Category}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get all categories
     * java.util.ArrayList<Category> categories = location.getCategories();
     * System.out.println("Number of categories: " + categories.size());
     * }
     * </pre>
     * @return List of venue categories defined for the location {@link Category Category}.
     */
    public abstract ArrayList<Category> getCategories();

    /**
     * List of sublocations {@link com.navigine.idl.java.Sublocation Sublocation}
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get all sublocations
     * java.util.ArrayList<Sublocation> sublocations = location.getSublocations();
     * System.out.println("Number of sublocations: " + sublocations.size());
     * }
     * </pre>
     * @return List of sublocations {@link Sublocation Sublocation}
     */
    public abstract ArrayList<Sublocation> getSublocations();

    /**
     * Flag indicates if location has been modified by user or not
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Check if location is modified
     * boolean isModified = location.getModified();
     * System.out.println("Location modified: " + isModified);
     * }
     * </pre>
     * @return Flag indicates if location has been modified by user or not
     */
    public abstract boolean getModified();

    /**
     * Tells if this {@link Location} is valid or not. Any other method
     * (except for this one) called on an invalid {@link Location} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
