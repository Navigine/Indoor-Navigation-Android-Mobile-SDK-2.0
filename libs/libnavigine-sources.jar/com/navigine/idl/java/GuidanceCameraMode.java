package com.navigine.idl.java;

/**
 * Camera behavior while a route is shown.
 * {@code FREE} leaves the camera alone (also entered when the user pans or pinches).
 * {@code FOLLOWING} looks along the route at the current progress.
 * {@code OVERVIEW} fits the whole route into {@code LocationWindow.focusRect} (or the full
 * view when focus rect is null).
 * Modes: Free / Following / Overview. A user gesture drops tracking.
 */
public enum GuidanceCameraMode {
    FREE,
    FOLLOWING,
    OVERVIEW,
    ;
}
