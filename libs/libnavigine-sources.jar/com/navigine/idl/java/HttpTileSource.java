package com.navigine.idl.java;

import java.util.HashMap;

/**
 * HTTP XYZ source for outdoor vector tiles.
 * {@code urlTemplate} must contain {@code {z}}, {@code {x}}, {@code {y}}. Optional query parameters
 * (API keys such as {@code key}, {@code access_token}, {@code apikey}) are appended to each
 * request. Optional headers cover {@code Authorization}, {@code Referer}, or a custom
 * {@code User-Agent}. The SDK always sends an identifying User-Agent unless the
 * headers map already has one. Keys may also be baked into {@code urlTemplate}.
 * Referenced from {@link com.navigine.idl.java.TileProvider TileProvider}.
 */
public final class HttpTileSource {


    /*package*/ final String urlTemplate;

    /*package*/ final HashMap<String, String> headers;

    /*package*/ final HashMap<String, String> queryParameters;

    /**
     * Default constructor for class HttpTileSource
     */
    public HttpTileSource(
            String urlTemplate,
            HashMap<String, String> headers,
            HashMap<String, String> queryParameters) {
        this.urlTemplate = urlTemplate;
        this.headers = headers;
        this.queryParameters = queryParameters;
    }

    /**
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * Map<String, String> query = new HashMap<String, String>();
     * query.put("key", "YOUR_MAPTILER_KEY");
     * HttpTileSource http = new HttpTileSource(
     *    "https://api.maptiler.com/tiles/v3-openmaptiles/{z}/{x}/{y}.pbf",
     *    null,
     *    query);
     * }
     * </pre>
     * HTTPS XYZ template with `{z}`, `{x}`, `{y}`.
     * @return <java>
     */
    public String getUrlTemplate() {
        return urlTemplate;
    }

    /**
     * Extra request headers. Null or empty: none. Overrides the default
     * User-Agent when that header is set.
     * @return Extra request headers. Null or empty: none. Overrides the default
     */
    public HashMap<String, String> getHeaders() {
        return headers;
    }

    /**
     * Extra query parameters appended to each tile URL. Null or empty: none.
     * @return Extra query parameters appended to each tile URL. Null or empty: none.
     */
    public HashMap<String, String> getQueryParameters() {
        return queryParameters;
    }

    @Override
    public String toString() {
        return "HttpTileSource{" +
                "urlTemplate=" + urlTemplate +
                "," + "headers=" + headers +
                "," + "queryParameters=" + queryParameters +
        "}";
    }

}
