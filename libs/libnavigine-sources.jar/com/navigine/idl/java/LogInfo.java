package com.navigine.idl.java;

/**
 * Represents metadata for a log file.
 * Referenced from {@link com.navigine.idl.java.ResourceManager ResourceManager}.
 */
public final class LogInfo {


    /*package*/ final String name;

    /*package*/ final String absolutePath;

    /*package*/ final int size;

    /*package*/ final int duration;

    /*package*/ final String date;

    /*package*/ final int numberOfCheckpoints;

    /**
     * Default constructor for class LogInfo
     */
    public LogInfo(
            String name,
            String absolutePath,
            int size,
            int duration,
            String date,
            int numberOfCheckpoints) {
        this.name = name;
        this.absolutePath = absolutePath;
        this.size = size;
        this.duration = duration;
        this.date = date;
        this.numberOfCheckpoints = numberOfCheckpoints;
    }

    /**
     * The name of the log file.
     * @return The name of the log file.
     */
    public String getName() {
        return name;
    }

    /**
     * The absolute file path of the log file.
     * @return The absolute file path of the log file.
     */
    public String getAbsolutePath() {
        return absolutePath;
    }

    /**
     * The size of the log file in bytes.
     * @return The size of the log file in bytes.
     */
    public int getSize() {
        return size;
    }

    /**
     * The duration of the logged activity in seconds.
     * @return The duration of the logged activity in seconds.
     */
    public int getDuration() {
        return duration;
    }

    /**
     * The date the log file was created or last modified, in string format.
     * @return The date the log file was created or last modified, in string format.
     */
    public String getDate() {
        return date;
    }

    /**
     * The number of checkpoints recorded in the log file.
     * @return The number of checkpoints recorded in the log file.
     */
    public int getNumberOfCheckpoints() {
        return numberOfCheckpoints;
    }

    @Override
    public String toString() {
        return "LogInfo{" +
                "name=" + name +
                "," + "absolutePath=" + absolutePath +
                "," + "size=" + size +
                "," + "duration=" + duration +
                "," + "date=" + date +
                "," + "numberOfCheckpoints=" + numberOfCheckpoints +
        "}";
    }

}
