package com.navigine.idl.java;

/**
 * enum described zone event types
 * Referenced from {@link com.navigine.idl.java.ZoneEvent ZoneEvent}.
 *
 * <p><b>Example:</b></p>
 * <pre>
 * {@code
 * // Get all zone event type values
 * ZoneEventType[] types = ZoneEventType.values();
 * System.out.println("Available zone event types:");
 * for (ZoneEventType type : types) {
 *    System.out.println("  - " + type);
 * }
 * }
 * </pre>
 */
public enum ZoneEventType {
    /**
     * Happens when user enters particular zone;
     */
    ENTER,
    /**
     * Happens when user leaves particular zone, sublocation has been changed or zone has been removed;
     */
    EXIT,
    ;
}
