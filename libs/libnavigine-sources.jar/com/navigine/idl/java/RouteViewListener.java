package com.navigine.idl.java;

public abstract class RouteViewListener {
    public abstract void onRouteViewsChanged();

    public abstract void onSelectedRouteChanged(RouteView route);

    public abstract void onRouteViewTap(RouteView route);
}
