package com.navigine.idl.java;

/**
 * A set of functions for working with geometries.
 */
public abstract class GeometryUtils {

    /**
     * Tells if this {@link GeometryUtils} is valid or not. Any other method
     * (except for this one) called on an invalid {@link GeometryUtils} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
    /**
     * Get distance between GPS points
     * @param from start point of calculation {@link com.navigine.idl.java.GlobalPoint GlobalPoint}
     * @param to end point of calculation {@link com.navigine.idl.java.GlobalPoint GlobalPoint}
     * @return distance in meters
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Calculate distance between global points
     * double globalDistance = GeometryUtils.distanceBetweenGlobalPoints(globalPoint1, globalPoint2);
     * System.out.printf("Distance between Moscow and St. Petersburg: %.2f meters%n", globalDistance);
     * }
     * </pre>
     */
    public static float distanceBetweenGlobalPoints(GlobalPoint from, GlobalPoint to)
    {
        return com.navigine.idl.java.internal.GeometryUtilsBinding.distanceBetweenGlobalPoints(from,
                                                                                               to);
    }

    /**
     * Get distance between points
     * @param from start point of calculation {@link com.navigine.idl.java.Point Point}
     * @param to end point of calculation {@link com.navigine.idl.java.Point Point}
     * @return distance in meters
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Calculate distance between points
     * double distance = GeometryUtils.distanceBetweenPoints(point1, point2);
     * System.out.printf("Distance between P1 and P2: %.2f meters%n", distance);
     * }
     * </pre>
     */
    public static float distanceBetweenPoints(Point from, Point to)
    {
        return com.navigine.idl.java.internal.GeometryUtilsBinding.distanceBetweenPoints(from,
                                                                                         to);
    }

    /**
     * Get length of segment
     * @param segment segment object for calculation {@link com.navigine.idl.java.Segment Segment}
     * @return length in meters
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Calculate segment length
     * double length1 = GeometryUtils.segmentLength(segment1);
     * double length2 = GeometryUtils.segmentLength(segment2);
     * System.out.printf("Segment1 length: %.2f meters%n", length1);
     * System.out.printf("Segment2 length: %.2f meters%n", length2);
     * }
     * </pre>
     */
    public static float segmentLength(Segment segment)
    {
        return com.navigine.idl.java.internal.GeometryUtilsBinding.segmentLength(segment);
    }

    /**
     * Get polygon area
     * @param polygon polygon object for calculation {@link com.navigine.idl.java.Polygon Polygon}
     * @return area in meters
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Calculate polygon area
     * double area = GeometryUtils.polygonArea(polygon);
     * System.out.printf("Polygon area: %.2f square meters%n", area);
     * }
     * </pre>
     */
    public static float polygonArea(Polygon polygon)
    {
        return com.navigine.idl.java.internal.GeometryUtilsBinding.polygonArea(polygon);
    }

    /**
     * Get polygon geometric center
     * @param polygon polygon object for calculation {@link com.navigine.idl.java.Polygon Polygon}
     * @return center point {@link com.navigine.idl.java.Point Point}
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Calculate polygon center
     * Point center = GeometryUtils.polygonCenter(polygon);
     * System.out.printf("Polygon center: (%.2f, %.2f)%n", center.getX(), center.getY());
     * }
     * </pre>
     */
    public static Point polygonCenter(Polygon polygon)
    {
        return com.navigine.idl.java.internal.GeometryUtilsBinding.polygonCenter(polygon);
    }

    /**
     * Checks that polygon contains point
     * @param polygon polygon object in which looking for contents {@link com.navigine.idl.java.Polygon Polygon}
     * @param point checking point object {@link com.navigine.idl.java.Point Point}
     * @return contains or not
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Check if polygon contains point
     * Point insidePoint = new Point(5.0, 5.0);
     * Point outsidePoint = new Point(15.0, 15.0);
     * boolean containsInside = GeometryUtils.polygonContainsPoint(polygon, insidePoint);
     * boolean containsOutside = GeometryUtils.polygonContainsPoint(polygon, outsidePoint);
     * System.out.println("Polygon contains inside point: " + containsInside);
     * System.out.println("Polygon contains outside point: " + containsOutside);
     * }
     * </pre>
     */
    public static boolean polygonContainsPoint(Polygon polygon, Point point)
    {
        return com.navigine.idl.java.internal.GeometryUtilsBinding.polygonContainsPoint(polygon,
                                                                                        point);
    }

    /**
     * Get distance from segment to point
     * @param segment start segment of calculation {@link com.navigine.idl.java.Segment Segment}
     * @param point end point of calculation {@link com.navigine.idl.java.Point Point}
     * @return distance in meters
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Calculate distance from segment to point
     * double distanceToPoint = GeometryUtils.segmentPointDistance(segment1, testPoint);
     * System.out.printf("Distance from segment1 to test point: %.2f meters%n", distanceToPoint);
     * }
     * </pre>
     */
    public static float segmentPointDistance(Segment segment, Point point)
    {
        return com.navigine.idl.java.internal.GeometryUtilsBinding.segmentPointDistance(segment,
                                                                                        point);
    }

    /**
     * Checks the intersection of two segments
     * @param segment1 first segment of calculation {@link com.navigine.idl.java.Segment Segment}
     * @param segment2 second segment of calculation {@link com.navigine.idl.java.Segment Segment}
     * @return intersects or not
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Check if segments intersect
     * boolean intersects = GeometryUtils.segmentIntersectsSegment(segment1, segment2);
     * System.out.println("Segments intersect: " + intersects);
     * }
     * </pre>
     */
    public static boolean segmentIntersectsSegment(Segment segment1, Segment segment2)
    {
        return com.navigine.idl.java.internal.GeometryUtilsBinding.segmentIntersectsSegment(segment1,
                                                                                            segment2);
    }

    /**
     * Calculate the intersection point of two segments
     * @param segment1 first segment of calculation {@link com.navigine.idl.java.Segment Segment}
     * @param segment2 second segment of calculation {@link com.navigine.idl.java.Segment Segment}
     * @return intersection point {@link com.navigine.idl.java.Point Point}
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Calculate intersection point
     * Point intersection = GeometryUtils.segmentIntersectionSegment(segment1, segment2);
     * System.out.printf("Intersection point: (%.2f, %.2f)%n", intersection.getX(), intersection.getY());
     * }
     * </pre>
     */
    public static Point segmentIntersectionSegment(Segment segment1, Segment segment2)
    {
        return com.navigine.idl.java.internal.GeometryUtilsBinding.segmentIntersectionSegment(segment1,
                                                                                              segment2);
    }

    /**
     * Calculate the division ratio of a segment by a given segment(if intersects)
     * @param segment1 first segment of calculation {@link com.navigine.idl.java.Segment Segment}
     * @param segment2 second segment of calculation {@link com.navigine.idl.java.Segment Segment}
     * @return division ratio
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Calculate division ratio
     * double divisionRatio = GeometryUtils.divisionRatioBySegment(segment1, segment2);
     * System.out.printf("Division ratio: %.2f%n", divisionRatio);
     * }
     * </pre>
     */
    public static float divisionRatioBySegment(Segment segment1, Segment segment2)
    {
        return com.navigine.idl.java.internal.GeometryUtilsBinding.divisionRatioBySegment(segment1,
                                                                                          segment2);
    }

    /**
     * Calculate projection point on a segment
     * @param segment segment of calculation {@link com.navigine.idl.java.Segment Segment}
     * @param r division ratio
     * @return ratio point {@link com.navigine.idl.java.Point Point}
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get point at specific ratio
     * double ratio = 0.5;
     * Point ratioPoint = GeometryUtils.getRatioPoint(segment1, ratio);
     * System.out.printf("Point at ratio %.1f: (%.2f, %.2f)%n", ratio, ratioPoint.getX(), ratioPoint.getY());
     * }
     * </pre>
     */
    public static Point getRatioPoint(Segment segment, double r)
    {
        return com.navigine.idl.java.internal.GeometryUtilsBinding.getRatioPoint(segment,
                                                                                 r);
    }

    /**
     * Calculate the division ratio of a segment by a given point
     * Calculate projection point on a segment
     * @param segment segment of calculation {@link com.navigine.idl.java.Segment Segment}
     * @param point point of calculation {@link com.navigine.idl.java.Point Point}
     * @return division ratio
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Calculate projection ratio
     * double projectionRatio = GeometryUtils.getProjectionRatio(segment1, testPoint);
     * System.out.printf("Projection ratio: %.2f%n", projectionRatio);
     * }
     * </pre>
     */
    public static double getProjectionRatio(Segment segment, Point point)
    {
        return com.navigine.idl.java.internal.GeometryUtilsBinding.getProjectionRatio(segment,
                                                                                      point);
    }
}
