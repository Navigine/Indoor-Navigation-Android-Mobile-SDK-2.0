package com.navigine.idl.java;

/**
 * Class provides a callback to be invoked when {@link com.navigine.idl.java.LocationManager LocationManager}
 * class downloads the location from server or load it from the storage.
 * Referenced from {@link com.navigine.idl.java.LocationManager LocationManager}.
 * <p><b>Note:</b> The callback is invoked in the UI thread.</p>
 */
public abstract class LocationListener {
    /**
     * Called when new location version has been downloaded from server or load it from the storage
     * @param location {@link com.navigine.idl.java.Location Location} instance or nil if server url or {@code USER_HASH} was changed.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * public void onLocationLoaded(Location location) {
     *    System.out.println("Location loaded successfully");
     *    currentLocation = location;
     *    if (location != null) {
     *        demonstrateLocationUsage(location);
     *    }
     * }
     * }
     * </pre>
     */
    public abstract void onLocationLoaded(Location location);

    public abstract void onLocationUploaded(int locationId);

    /**
     * Called if unable to download location version from CMS
     * @param locationId location unique identifier in SMC.
     * @param error handled error.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * public void onLocationFailed(int locationId, Error error) {
     *    System.err.println("Failed to load location " + locationId + ": " + error.getMessage());
     * }
     * }
     * </pre>
     */
    public abstract void onLocationFailed(int locationId, java.lang.Error error);
}
