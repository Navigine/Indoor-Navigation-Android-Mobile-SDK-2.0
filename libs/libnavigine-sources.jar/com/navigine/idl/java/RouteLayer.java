package com.navigine.idl.java;

import com.navigine.common.NativeObject;
import com.navigine.common.Subscription;
import java.util.ArrayList;

/**
 * Layer that renders a route on the map as traveled and remaining polylines.
 * Independent from {@link com.navigine.idl.java.UserLocationLayer UserLocationLayer}: a route can be shown
 * without a user marker, and a user marker can be shown without a route.
 * Location and position are taken from the SDK automatically (same pattern as
 * {@link com.navigine.idl.java.UserLocationLayer UserLocationLayer}).
 * Referenced from {@link com.navigine.idl.java.NavigineSdk NavigineSdk}.
 */
public abstract class RouteLayer {
    /**
     * Shows or hides the route layer.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * routeLayer.setVisible(true);
     * System.out.println("Route layer set visible");
     * }
     * </pre>
     */
    public abstract void setVisible(boolean visible);

    /**
     * Returns true if the route layer is visible.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * boolean visible = routeLayer.isVisible();
     * System.out.println("Route layer is visible: " + visible);
     * }
     * </pre>
     */
    public abstract boolean isVisible();

    /**
     * Starts turn-by-turn guidance to the target from the current position.
     * @param target Destination endpoint. Route and progress are updated automatically.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * routeLayer.setTarget(to);
     * System.out.println("Guidance target applied");
     * }
     * </pre>
     */
    public abstract void setTarget(RouteEndpoint target);

    /**
     * Builds and shows a static route between two points (no live guidance).
     * @param from Route start endpoint.
     * @param to Route finish endpoint.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * routeLayer.setRoute(from, to);
     * System.out.println("Static route applied");
     * }
     * </pre>
     */
    public abstract void setRoute(RouteEndpoint from, RouteEndpoint to);

    /**
     * Cancels guidance / static route and removes polylines from the map.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * routeLayer.clear();
     * System.out.println("Route layer cleared");
     * }
     * </pre>
     */
    public abstract void clear();

    /**
     * Returns currently rendered routes. V1 exposes a single active route.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * List<RouteView> routes = routeLayer.routes();
     * System.out.println("Visible routes: " + routes.size());
     * }
     * </pre>
     */
    public abstract ArrayList<RouteView> routes();

    /**
     * Returns selected route view, or null when no route is selected.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * RouteView selectedRoute = routeLayer.selectedRoute();
     * if (selectedRoute != null) {
     *    System.out.println("Selected route length: " + selectedRoute.length());
     * }
     * }
     * </pre>
     */
    public abstract RouteView selectedRoute();

    /**
     * Selects the provided route view. Pass null to clear selection.
     * @param route Route view from {@link com.navigine.idl.java.RouteLayer routes}, or null.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * if (!routes.isEmpty()) {
     *    routeLayer.selectRoute(routes.get(0));
     * }
     * }
     * </pre>
     */
    public abstract void selectRoute(RouteView route);

    /**
     * Adds listener for route lifecycle, progress and target reach events.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * routeLayerListener = new RouteLayerListener() {
     *    @Override
     *    public void onRouteChanged(RouteLayerStatus status, RouteView route) {
     *        System.out.println("Route status: " + status);
     *    }
     *    @Override
     *    public void onRouteAdvanced(RouteProgress progress) {
     *        System.out.println("Remaining distance: " + progress.remainingDistance
     *            + ", time: " + progress.remainingTime + "s");
     *    }
     *    @Override
     *    public void onRouteTargetReached() {
     *        System.out.println("Route target reached");
     *    }
     * };
     * routeLayer.addRouteLayerListener(routeLayerListener);
     * }
     * </pre>
     */
    public abstract void addRouteLayerListener(RouteLayerListener listener);

    /**
     * Removes previously added route layer listener.
     */
    public abstract void removeRouteLayerListener(RouteLayerListener listener);

    /**
     * Adds listener for route view list, selection and tap events.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * routeViewListener = new RouteViewListener() {
     *    @Override
     *    public void onRouteViewsChanged() {
     *        System.out.println("Route views changed");
     *    }
     *    @Override
     *    public void onSelectedRouteChanged(RouteView route) {
     *        System.out.println("Selected route changed");
     *    }
     *    @Override
     *    public void onRouteViewTap(RouteView route) {
     *        routeLayer.selectRoute(route);
     *    }
     * };
     * routeLayer.addRouteViewListener(routeViewListener);
     * }
     * </pre>
     */
    public abstract void addRouteViewListener(RouteViewListener listener);

    /**
     * Removes previously added route view listener.
     */
    public abstract void removeRouteViewListener(RouteViewListener listener);

    /**
     * Sets traveled (passed) route polyline color.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * routeLayer.setTraveledColor(0xB4787878);
     * System.out.println("Traveled color updated");
     * }
     * </pre>
     */
    public abstract void setTraveledColor(int color);

    /**
     * Sets remaining route polyline color.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * routeLayer.setRemainingColor(0xFF30AAD9);
     * System.out.println("Remaining color updated");
     * }
     * </pre>
     */
    public abstract void setRemainingColor(int color);

    /**
     * Sets route polyline width in pixels (also used as default dotted point size).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * routeLayer.setWidth(8.0f);
     * System.out.println("Route width updated");
     * }
     * </pre>
     */
    public abstract void setWidth(float width);

    /**
     * Sets rendering style for the remaining route.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * routeLayer.setRemainingStyle(RouteRemainingStyle.DOTTED);
     * System.out.println("Remaining style set to DOTTED");
     * }
     * </pre>
     */
    public abstract void setRemainingStyle(RouteRemainingStyle style);

    /**
     * Returns the remaining route rendering style.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * RouteRemainingStyle remainingStyle = routeLayer.remainingStyle();
     * System.out.println("Remaining style: " + remainingStyle);
     * }
     * </pre>
     */
    public abstract RouteRemainingStyle remainingStyle();

    /**
     * Sets dash length for DASHED remaining style. Use 0 to disable dashing.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * routeLayer.setRemainingDashLength(0.5f);
     * System.out.println("Remaining dash length updated");
     * }
     * </pre>
     */
    public abstract void setRemainingDashLength(float dashLength);

    /**
     * Sets gap length for DASHED remaining style. Use 0 to disable dashing.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * routeLayer.setRemainingGapLength(0.4f);
     * System.out.println("Remaining gap length updated");
     * }
     * </pre>
     */
    public abstract void setRemainingGapLength(float gapLength);

    /**
     * Sets point size for DOTTED remaining style.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * routeLayer.setRemainingPointSize(8.0f, 8.0f);
     * System.out.println("Remaining point size updated");
     * }
     * </pre>
     */
    public abstract void setRemainingPointSize(float width, float height);

    /**
     * Sets point placement mode for DOTTED remaining style.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * routeLayer.setRemainingPlacement(Placement.SPACED);
     * System.out.println("Remaining placement updated");
     * }
     * </pre>
     */
    public abstract void setRemainingPlacement(Placement placement);

    /**
     * Sets spacing between points for DOTTED + SPACED placement (pixels).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * routeLayer.setRemainingPlacementSpacing(8.0f);
     * System.out.println("Remaining placement spacing updated");
     * }
     * </pre>
     */
    public abstract void setRemainingPlacementSpacing(float spacing);

    /**
     * Sets minimum polyline length ratio for DOTTED placement.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * routeLayer.setRemainingPlacementMinRatio(0.0f);
     * System.out.println("Remaining placement min ratio updated");
     * }
     * </pre>
     */
    public abstract void setRemainingPlacementMinRatio(float ratio);

    /**
     * Enables or disables collision for DOTTED remaining points.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * routeLayer.setRemainingCollisionEnabled(false);
     * System.out.println("Remaining collision disabled");
     * }
     * </pre>
     */
    public abstract void setRemainingCollisionEnabled(boolean enabled);

    /**
     * Tells if this {@link RouteLayer} is valid or not. Any other method
     * (except for this one) called on an invalid {@link RouteLayer} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
