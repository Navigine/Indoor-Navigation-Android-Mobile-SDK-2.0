package com.navigine.idl.java;

/**
 * Class describing turn guidance event.
 * Referenced from {@link com.navigine.idl.java.RouteEvent RouteEvent}.
 */
public final class TurnEvent {


    /*package*/ final TurnType type;

    /*package*/ final int angle;

    /**
     * Default constructor for class TurnEvent
     */
    public TurnEvent(
            TurnType type,
            int angle) {
        this.type = type;
        this.angle = angle;
    }

    /**
     * Turn direction/severity type.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * TurnType turnType = turnEvent.getType();
     * System.out.println("Turn type: " + turnType);
     * }
     * </pre>
     * @return Turn direction/severity type.
     */
    public TurnType getType() {
        return type;
    }

    /**
     * Signed turn angle in degrees.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * int angle = turnEvent.getAngle();
     * System.out.println("Turn angle: " + angle);
     * }
     * </pre>
     * @return Signed turn angle in degrees.
     */
    public int getAngle() {
        return angle;
    }

    @Override
    public String toString() {
        return "TurnEvent{" +
                "type=" + type +
                "," + "angle=" + angle +
        "}";
    }

}
