package com.navigine.idl.java;

/**
 * Trapezoid of the current viewport on the ground, in WGS84.
 * With tilt the shape is not a rectangle: near edge is closer to the camera.
 * Corners are ray-cast onto the ground plane, same as
 * {@link com.navigine.idl.java.LocationWindow LocationWindow} {@code screenPositionToGlobal}.
 * Referenced from {@link com.navigine.idl.java.LocationWindow LocationWindow} {@code visibleRegion}.
 */
public final class VisibleRegion {


    /*package*/ final GlobalPoint topLeft;

    /*package*/ final GlobalPoint topRight;

    /*package*/ final GlobalPoint bottomLeft;

    /*package*/ final GlobalPoint bottomRight;

    /**
     * Default constructor for class VisibleRegion
     */
    public VisibleRegion(
            GlobalPoint topLeft,
            GlobalPoint topRight,
            GlobalPoint bottomLeft,
            GlobalPoint bottomRight) {
        this.topLeft = topLeft;
        this.topRight = topRight;
        this.bottomLeft = bottomLeft;
        this.bottomRight = bottomRight;
    }

    /**
     * Top-left screen corner {@link com.navigine.idl.java.GlobalPoint GlobalPoint}.
     * @return Top-left screen corner {@link GlobalPoint GlobalPoint}.
     */
    public GlobalPoint getTopLeft() {
        return topLeft;
    }

    /**
     * Top-right screen corner {@link com.navigine.idl.java.GlobalPoint GlobalPoint}.
     * @return Top-right screen corner {@link GlobalPoint GlobalPoint}.
     */
    public GlobalPoint getTopRight() {
        return topRight;
    }

    /**
     * Bottom-left screen corner {@link com.navigine.idl.java.GlobalPoint GlobalPoint}.
     * @return Bottom-left screen corner {@link GlobalPoint GlobalPoint}.
     */
    public GlobalPoint getBottomLeft() {
        return bottomLeft;
    }

    /**
     * Bottom-right screen corner {@link com.navigine.idl.java.GlobalPoint GlobalPoint}.
     * @return Bottom-right screen corner {@link GlobalPoint GlobalPoint}.
     */
    public GlobalPoint getBottomRight() {
        return bottomRight;
    }

    @Override
    public String toString() {
        return "VisibleRegion{" +
                "topLeft=" + topLeft +
                "," + "topRight=" + topRight +
                "," + "bottomLeft=" + bottomLeft +
                "," + "bottomRight=" + bottomRight +
        "}";
    }

}
