package com.navigine.idl.java;

/**
 * Class provides a callback to be invoked when {@link com.navigine.idl.java.NotificationManager NotificationManager}
 * detects local notification events.
 * Referenced from {@link com.navigine.idl.java.NotificationManager NotificationManager}.
 * <p><b>Note:</b> The callback is invoked in the UI thread.</p>
 */
public abstract class NotificationListener {
    /**
     * Called when iBeacon signal matched all parameters in notification
     * @param notification notification instance created in CMS {@link com.navigine.idl.java.Notification Notification}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * public void onNotificationLoaded(Notification notification) {
     *    System.out.println("Notification loaded");
     *    demonstrateNotificationUsage(notification);
     * }
     * }
     * </pre>
     */
    public abstract void onNotificationLoaded(Notification notification);

    /**
     * Called if unable to calculate notification or network errors.
     * @param error handled error.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * public void onNotificationFailed(java.lang.Error error) {
     *    System.out.println("Notification failed: " + error.getMessage());
     *    demonstrateErrorHandling(error);
     * }
     * }
     * </pre>
     */
    public abstract void onNotificationFailed(java.lang.Error error);
}
