package com.navigine.idl.java;

import com.navigine.common.NativeObject;
import com.navigine.common.Subscription;

public abstract class BeaconProximityEstimator {
    public abstract void start();

    public abstract void stop();

    public abstract void pause();

    public abstract void resume();

    public abstract void addListener(BeaconProximityEstimatorListener listener);

    public abstract void removeListener(BeaconProximityEstimatorListener listener);
}
