package com.navigine.idl.java;

/**
 * Listener for updates of a single {@link com.navigine.idl.java.ClusterMapObject ClusterMapObject}.
 * {@code onClusterChanged} is called when the cluster member count changes while it remains a cluster (at least two icons).
 * It is not called when the cluster is created or destroyed.
 */
public abstract class ClusterMapObjectListener {
    /**
     * Cluster marker needs an app-side update (bitmap, label, etc.).
     * @param cluster Cluster with at least two member icons. Use {@code getCount()} for the badge value.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * @Override
     * public void onClusterChanged(ClusterMapObject cluster) {
     *    int memberCount = cluster.getCount();
     *    System.out.println("Cluster changed, member count: " + memberCount);
     * }
     * }
     * </pre>
     */
    public abstract void onClusterChanged(ClusterMapObject cluster);
}
