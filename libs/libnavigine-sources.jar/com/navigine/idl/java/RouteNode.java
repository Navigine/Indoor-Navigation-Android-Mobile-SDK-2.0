package com.navigine.idl.java;

import java.util.ArrayList;

/**
 * Class describing one node of the evaluated route.
 * Referenced from {@link com.navigine.idl.java.RoutePath RoutePath}.
 */
public final class RouteNode {


    /*package*/ final LocationPoint point;

    /*package*/ final float weight;

    /*package*/ final float distance;

    /*package*/ final ArrayList<RouteEvent> events;

    /**
     * Default constructor for class RouteNode
     */
    public RouteNode(
            LocationPoint point,
            float weight,
            float distance,
            ArrayList<RouteEvent> events) {
        this.point = point;
        this.weight = weight;
        this.distance = distance;
        this.events = events;
    }

    /**
     * Location point of this node.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * LocationPoint point = node.getPoint();
     * if (point != null) {
     *    demonstrateLocationPointUsage(point);
     * }
     * }
     * </pre>
     * @return Location point of this node.
     */
    public LocationPoint getPoint() {
        return point;
    }

    /**
     * Route cost/weight value at this node.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * float weight = node.getWeight();
     * System.out.println("Node weight: " + weight);
     * }
     * </pre>
     * @return Route cost/weight value at this node.
     */
    public float getWeight() {
        return weight;
    }

    /**
     * Distance from route start to this node (meters).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * float distance = node.getDistance();
     * System.out.println("Node distance: " + distance + " meters");
     * }
     * </pre>
     * @return Distance from route start to this node (meters).
     */
    public float getDistance() {
        return distance;
    }

    /**
     * Events associated with this node.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * List<RouteEvent> events = node.getEvents();
     * System.out.println("Node has " + events.size() + " events");
     * for (RouteEvent event : events) {
     *    demonstrateRouteEventUsage(event);
     * }
     * }
     * </pre>
     * @return Events associated with this node.
     */
    public ArrayList<RouteEvent> getEvents() {
        return events;
    }

    @Override
    public String toString() {
        return "RouteNode{" +
                "point=" + point +
                "," + "weight=" + weight +
                "," + "distance=" + distance +
                "," + "events=" + events +
        "}";
    }

}
