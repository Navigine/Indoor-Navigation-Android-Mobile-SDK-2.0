package com.navigine.idl.java;

import com.navigine.common.NativeObject;
import com.navigine.common.Subscription;

/**
 * Class is used for evaluating navigation and calculating users' {@link com.navigine.idl.java.Position Position}
 * Referenced from {@link com.navigine.idl.java.NavigineSdk NavigineSdk}.
 */
public abstract class NavigationManager {
    /**
     * Method is used to add {@link com.navigine.idl.java.PositionListener PositionListener} class element
     * which will notify about new user position.
     * <p><b>Note:</b> Do not forget to remove listener if it is no longer needed!</p>
     * @param listener Corresponding {@link com.navigine.idl.java.PositionListener PositionListener} class.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Add position listener
     * navigationManager.addPositionListener(positionListener);
     * }
     * </pre>
     */
    public abstract void addPositionListener(PositionListener listener);

    public abstract void startLogRecording();

    public abstract void addCheckPoint(LocationPoint point);

    public abstract void stopLogRecording();

    public abstract void addLocationMeasurement(GlobalPoint point, float accuracy, String provider);

    /**
     * Method is used for removing previously added {@link com.navigine.idl.java.PositionListener PositionListener} class element.
     * @param listener Corresponding {@link com.navigine.idl.java.PositionListener PositionListener} class to remove.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove position listener
     * navigationManager.removePositionListener(positionListener);
     * }
     * </pre>
     */
    public abstract void removePositionListener(PositionListener listener);
}
