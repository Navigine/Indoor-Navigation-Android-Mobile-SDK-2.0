package com.navigine.idl.java;

/**
 * Represents a polyline object on the location view.
 * Referenced from {@link com.navigine.idl.java.LocationWindow LocationWindow}.
 */
public abstract class PolylineMapObject extends MapObject {
    /**
     * Method is used to specify the source polyline of the object.
     * @param polyline Metrics coordinates of the polyline {@link com.navigine.idl.java.LocationPolyline LocationPolyline}.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set polyline geometry
     * List<GlobalPoint> polylinePoints = new ArrayList<>();
     * polylinePoints.add(new GlobalPoint(0.0, 0.0));
     * polylinePoints.add(new GlobalPoint(50.0, 50.0));
     * polylinePoints.add(new GlobalPoint(100.0, 0.0));
     * polylinePoints.add(new GlobalPoint(150.0, 50.0));
     *            LocationPolyline locationPolyline = new LocationPolyline(polylinePoints, 0);
     * boolean success = polylineMapObject.setPolyLine(locationPolyline);
     * System.out.println("Set polyline geometry: " + success);
     * }
     * </pre>
     */
    public abstract boolean setPolyLine(LocationPolyline polyline);

    /**
     * Method is used to specify the width of the polyline.
     * @param width Width of the polyline in pixels.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set polyline width
     * boolean widthSuccess = polylineMapObject.setWidth(3.0);
     * System.out.println("Set polyline width to 3.0 pixels: " + widthSuccess);
     * }
     * </pre>
     */
    public abstract boolean setWidth(float width);

    /**
     * Method is used to specify the fill color of the polyline.
     * @param color Fill color.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set polyline color
     * boolean colorSuccess = polylineMapObject.setColor(0xE6FF8000);
     * System.out.println("Set polyline color to orange with 90% opacity: " + colorSuccess);
     * }
     * </pre>
     */
    public abstract boolean setColor(int color);

    /**
     * Method is used to specify the rendering order of the polyline.
     * @param order The rendering order value. Default: 0.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set rendering order
     * boolean orderSuccess = polylineMapObject.setOrder(2);
     * System.out.println("Set rendering order to 2: " + orderSuccess);
     * }
     * </pre>
     */
    public abstract boolean setOrder(int order);

    /**
     * Method is used to specify the cap style for the polyline ends.
     * @param cap The cap type {@link com.navigine.idl.java.CapType CapType}. Default: BUTT.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set cap type
     * boolean capSuccess = polylineMapObject.setCapType(CapType.ROUND);
     * System.out.println("Set cap type to ROUND: " + capSuccess);
     * }
     * </pre>
     */
    public abstract boolean setCapType(CapType cap);

    /**
     * Method is used to specify the join style for polyline segments.
     * @param join The join type {@link com.navigine.idl.java.JoinType JoinType}. Default: MITER.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set join type
     * boolean joinSuccess = polylineMapObject.setJoinType(JoinType.ROUND);
     * System.out.println("Set join type to ROUND: " + joinSuccess);
     * }
     * </pre>
     */
    public abstract boolean setJoinType(JoinType join);

    /**
     * Method is used to specify the miter limit for miter joins.
     * @param miterLimit The miter limit value for miter joins. Default: 3.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set miter limit
     * boolean miterSuccess = polylineMapObject.setMiterLimit(5.0);
     * System.out.println("Set miter limit to 5.0: " + miterSuccess);
     * }
     * </pre>
     */
    public abstract boolean setMiterLimit(float miterLimit);

    /**
     * Method is used to specify the color of the polyline’s outline.
     * @param color Outline color.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set polyline outline color
     * boolean outlineColorSuccess2 = polylineMapObject.setOutlineColor(0xFF000000);
     * System.out.println("Set polyline outline color to black: " + outlineColorSuccess2);
     * }
     * </pre>
     */
    public abstract boolean setOutlineColor(int color);

    /**
     * Method is used to specify the width of the polyline’s outline.
     * @param radius Width of the outline in pixels.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set polyline outline width
     * boolean outlineWidthSuccess2 = polylineMapObject.setOutlineWidth(1.0);
     * System.out.println("Set polyline outline width to 1.0 pixels: " + outlineWidthSuccess2);
     * }
     * </pre>
     */
    public abstract boolean setOutlineWidth(float radius);

    /**
     * Method is used to specify the opacity of the polyline’s outline.
     * @param alpha Opacity multiplier (0 to 1). Values below 0 are set to 0. Default: 1.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set polyline outline alpha
     * boolean outlineAlphaSuccess2 = polylineMapObject.setOutlineAlpha(0.5);
     * System.out.println("Set polyline outline alpha to 0.5: " + outlineAlphaSuccess2);
     * }
     * </pre>
     */
    public abstract boolean setOutlineAlpha(float alpha);

    /**
     * Method is used to specify the cap style for the polyline’s outline ends.
     * @param cap The cap type {@link com.navigine.idl.java.CapType CapType}. Default: BUTT.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set polyline outline cap type
     * boolean outlineCapTypeSuccess2 = polylineMapObject.setOutlineCapType(CapType.SQUARE);
     * System.out.println("Set polyline outline cap type to SQUARE: " + outlineCapTypeSuccess2);
     * }
     * </pre>
     */
    public abstract boolean setOutlineCapType(CapType cap);

    /**
     * Method is used to specify the join style for the polyline’s outline segments.
     * @param join The join type {@link com.navigine.idl.java.JoinType JoinType}. Default: MITER.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set polyline outline join type
     * boolean outlineJoinTypeSuccess2 = polylineMapObject.setOutlineJoinType(JoinType.MITER);
     * System.out.println("Set polyline outline join type to MITER: " + outlineJoinTypeSuccess2);
     * }
     * </pre>
     */
    public abstract boolean setOutlineJoinType(JoinType join);

    /**
     * Method is used to specify the miter limit for the polyline’s outline miter joins.
     * @param miterLimit The miter limit value for outline miter joins. Default: 3.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set polyline outline miter limit
     * boolean outlineMiterLimitSuccess2 = polylineMapObject.setOutlineMiterLimit(3.0);
     * System.out.println("Set polyline outline miter limit to 3.0: " + outlineMiterLimitSuccess2);
     * }
     * </pre>
     */
    public abstract boolean setOutlineMiterLimit(float miterLimit);

    /**
     * Method is used to specify the rendering order of the polyline’s outline.
     * @param order The rendering order value for the outline. Default: 0.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set polyline outline rendering order
     * boolean outlineOrderSuccess2 = polylineMapObject.setOutlineOrder(0);
     * System.out.println("Set polyline outline rendering order to 0: " + outlineOrderSuccess2);
     * }
     * </pre>
     */
    public abstract boolean setOutlineOrder(int order);

    /**
     * Tells if this {@link PolylineMapObject} is valid or not. Any other method
     * (except for this one) called on an invalid {@link PolylineMapObject} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
