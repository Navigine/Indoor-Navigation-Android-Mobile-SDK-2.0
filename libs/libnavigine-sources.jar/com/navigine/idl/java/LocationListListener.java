package com.navigine.idl.java;

import java.util.HashMap;

/**
 * Class provides a callback to be invoked when {@link com.navigine.idl.java.LocationListManager LocationListManager}
 * class downloads list of available locations from server.
 * Referenced from {@link com.navigine.idl.java.LocationListManager LocationListManager}.
 * <p><b>Note:</b> The callback is invoked in the UI thread.</p>
 */
public abstract class LocationListListener {
    /**
     * Called when new list of available locations has been downloaded from server
     * @param locationInfos dictionary of {@link com.navigine.idl.java.LocationInfo LocationInfo}s which represents location id to location general info.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * public void onLocationListLoaded(Map<Integer, LocationInfo> locationInfos) {
     *    System.out.println("Location list loaded");
     *    demonstrateLocationList(locationInfos);
     * }
     * }
     * </pre>
     */
    public abstract void onLocationListLoaded(HashMap<Integer, LocationInfo> locationInfos);

    /**
     * Called if unable to download list of available locations
     * @param error handled error.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * public void onLocationListFailed(java.lang.Error error) {
     *    System.out.println("Location list failed: " + error.getMessage());
     *    demonstrateErrorHandling(error);
     * }
     * }
     * </pre>
     */
    public abstract void onLocationListFailed(java.lang.Error error);
}
