package com.navigine.idl.java;

import com.navigine.common.NativeObject;
import com.navigine.common.Subscription;
import java.util.ArrayList;

public abstract class ResourceManager {
    public abstract void loadImage(String imageUrl, ResourceListener listener);

    /**
     * working with logs
     */
    public abstract ArrayList<LogInfo> getLogsList();

    public abstract void removeLogFile(String fileName);

    public abstract void uploadLogFile(String fileName, ResourceUploadListener listener);
}
