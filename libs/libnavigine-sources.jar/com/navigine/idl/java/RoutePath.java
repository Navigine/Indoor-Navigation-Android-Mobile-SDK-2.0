package com.navigine.idl.java;

import java.util.ArrayList;

/**
 * Class is used for storing the route path between two points in location.
 * Referenced from: {@link com.navigine.idl.java.AsyncRouteListener AsyncRouteListener}, {@link com.navigine.idl.java.AsyncRouteManager AsyncRouteManager}, {@link com.navigine.idl.java.Location Location},
 * {@link com.navigine.idl.java.RouteListener RouteListener}, {@link com.navigine.idl.java.RouteManager RouteManager}
 */
public abstract class RoutePath {
    /**
     * Returns the leading segment of the route up to advance meters.
     * @param advance distance along route (meters).
     * @return route head segment.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get head of route (first 10 meters)
     * RoutePath headPath = path.head(10.0);
     * if (headPath != null) {
     *    System.out.println("Head path length: " + headPath.getLength() + " meters");
     * }
     * }
     * </pre>
     */
    public abstract RoutePath head(float advance);

    /**
     * Returns the route segment after advance meters.
     * @param advance distance along route (meters).
     * @return route tail segment.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get tail of route (remaining after 10 meters)
     * RoutePath tailPath = path.tail(10.0);
     * if (tailPath != null) {
     *    System.out.println("Tail path length: " + tailPath.getLength() + " meters");
     * }
     * }
     * </pre>
     */
    public abstract RoutePath tail(float advance);

    /**
     * Returns route nodes with points and events.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get route nodes
     * List<RouteNode> nodes = path.getNodes();
     * System.out.println("Route has " + nodes.size() + " nodes");
     * for (RouteNode node : nodes) {
     *    demonstrateRouteNodeUsage(node);
     * }
     * }
     * </pre>
     */
    public abstract ArrayList<RouteNode> nodes();

    /**
     * Total route length in meters.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get route length
     * double length = path.getLength();
     * System.out.println("Route length: " + length + " meters");
     * }
     * </pre>
     * @return Total route length in meters.
     */
    public abstract float getLength();

    /**
     * Total route weight/cost.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get total route weight
     * double weight = path.getWeight();
     * System.out.println("Route weight: " + weight);
     * }
     * </pre>
     * @return Total route weight/cost.
     */
    public abstract float getWeight();
}
