package com.navigine.idl.java;

import java.util.ArrayList;

/**
 * Interface for a building with multiple floors (Sublocations).
 * Allows selecting the active floor directly via setActiveSublocationId.
 */
public abstract class Building {
    /**
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * List<Sublocation> floors = activeBuilding.getSublocations();
     * System.out.println("Focused building, floor count: " + floors.size());
     * }
     * </pre>
     */
    public abstract ArrayList<Sublocation> getSublocations();

    /**
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * int activeFloorId = activeBuilding.getActiveSublocationId();
     * System.out.println("Active sublocation id: " + activeFloorId);
     * }
     * </pre>
     */
    public abstract int getActiveSublocationId();

    /**
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * activeBuilding.setActiveSublocationId(activeFloorId);
     * }
     * </pre>
     */
    public abstract void setActiveSublocationId(int activeSublocationId);

    /**
     * Tells if this {@link Building} is valid or not. Any other method
     * (except for this one) called on an invalid {@link Building} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
