package com.navigine.idl.java;

/**
 * Class is used for describing routing options of {@link com.navigine.idl.java.AsyncRouteManager AsyncRouteManager}.
 * Referenced from: {@link com.navigine.idl.java.AsyncRouteManager AsyncRouteManager}.
 *
 * <p><b>Example:</b></p>
 * <pre>
 * {@code
 * // Empty ctor uses IDL defaults (0 / 5 / 2); full ctor for custom values.
 * RouteOptions routeOptions = new RouteOptions(3.0, 7.0, 2.5);
 * System.out.println("Created route options with smoothRadius: " + routeOptions.getSmoothRadius() +
 *                  ", maxProjectionDistance: " + routeOptions.getMaxProjectionDistance() +
 *                  ", maxAdvance: " + routeOptions.getMaxAdvance());
 * }
 * </pre>
 */
public final class RouteOptions {


    /*package*/ final double smoothRadius;

    /*package*/ final double maxProjectionDistance;

    /*package*/ final double maxAdvance;

    /**
     * Default constructor for class RouteOptions
     */
    public RouteOptions(
            double smoothRadius,
            double maxProjectionDistance,
            double maxAdvance) {
        this.smoothRadius = smoothRadius;
        this.maxProjectionDistance = maxProjectionDistance;
        this.maxAdvance = maxAdvance;
    }

    /**
     * Default constructor for class RouteOptions
     */
    public RouteOptions() {
        this(0, 5, 2);
    }

    /**
     * This parameter controls if the resulting route should be smoothed for better
     * user experience. It can be considered as the maximum distance (in meters)
     * by which the smoothed route can deviate from the original route. The original
     * route follows exactly the edges of the route graph. If you don't want the route
     * to be smoothed, use value 0.
     * @return This parameter controls if the resulting route should be smoothed for better
     */
    public double getSmoothRadius() {
        return smoothRadius;
    }

    /**
     * This parameter controls the router behaviour in case if the position essentially
     * deviates from the proposed route. If the position deviates more than the specified
     * distance (in meters), then the route will be rebuilt. You should not set the
     * maxProjectionDistance value too low. The reasonable interval of values is [3, 10].
     * @return This parameter controls the router behaviour in case if the position essentially
     */
    public double getMaxProjectionDistance() {
        return maxProjectionDistance;
    }

    /**
     * This parameter controls the maximum distance (in meters) that a position can advance
     * along the route between the two consecutive navigation solutions separated in time
     * by 1 second. If this constraint is broken, the route will be completely rebuilt.
     * The reasonable interval of values is [1, 3].
     * @return This parameter controls the maximum distance (in meters) that a position can advance
     */
    public double getMaxAdvance() {
        return maxAdvance;
    }

    @Override
    public String toString() {
        return "RouteOptions{" +
                "smoothRadius=" + smoothRadius +
                "," + "maxProjectionDistance=" + maxProjectionDistance +
                "," + "maxAdvance=" + maxAdvance +
        "}";
    }

}
