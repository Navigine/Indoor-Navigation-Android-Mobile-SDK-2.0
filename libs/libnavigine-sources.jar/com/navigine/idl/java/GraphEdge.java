package com.navigine.idl.java;

/**
 * Class is used for storing graph edge.
 */
public abstract class GraphEdge {
    /**
     * Edge weight.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get edge weight
     * float weight = edge.getWeight();
     * System.out.println("Edge weight: " + weight);
     * }
     * </pre>
     * @return Edge weight.
     */
    public abstract Float getWeight();

    /**
     * Destination vertex id {@link com.navigine.idl.java.GraphVertex GraphVertex}
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get destination vertex ID
     * int dst = edge.getDst();
     * System.out.println("Edge destination ID: " + dst);
     * }
     * </pre>
     * @return Destination vertex id {@link GraphVertex GraphVertex}
     */
    public abstract int getDst();

    /**
     * Source vertex id {@link com.navigine.idl.java.GraphVertex GraphVertex}
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get source vertex ID
     * int src = edge.getSrc();
     * System.out.println("Edge source ID: " + src);
     * }
     * </pre>
     * @return Source vertex id {@link GraphVertex GraphVertex}
     */
    public abstract int getSrc();

    /**
     * Edge weight coefficient.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get edge weight coefficient
     * int weightCoef = edge.getWeightCoef();
     * System.out.println("Edge weight coefficient: " + weightCoef);
     * }
     * </pre>
     * @return Edge weight coefficient.
     */
    public abstract Float getWeightCoef();

    /**
     * Tells if this {@link GraphEdge} is valid or not. Any other method
     * (except for this one) called on an invalid {@link GraphEdge} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
