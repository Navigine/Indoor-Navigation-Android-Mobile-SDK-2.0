package com.navigine.idl.java;

/**
 * Event indicating the route target has been reached.
 * Referenced from {@link com.navigine.idl.java.RouteEvent RouteEvent}.
 */
public final class TargetReachedEvent {


    /*package*/ final long index;

    /*package*/ final LocationPoint point;

    /**
     * Default constructor for class TargetReachedEvent
     */
    public TargetReachedEvent(
            long index,
            LocationPoint point) {
        this.index = index;
        this.point = point;
    }

    /**
     * Index of reached target in target list.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * long index = event.getIndex();
     * System.out.println("Reached target index: " + index);
     * }
     * </pre>
     * @return Index of reached target in target list.
     */
    public long getIndex() {
        return index;
    }

    /**
     * Location point where target was reached.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * LocationPoint point = event.getPoint();
     * if (point != null) {
     *    demonstrateLocationPointUsage(point);
     * }
     * }
     * </pre>
     * @return Location point where target was reached.
     */
    public LocationPoint getPoint() {
        return point;
    }

    @Override
    public String toString() {
        return "TargetReachedEvent{" +
                "index=" + index +
                "," + "point=" + point +
        "}";
    }

}
