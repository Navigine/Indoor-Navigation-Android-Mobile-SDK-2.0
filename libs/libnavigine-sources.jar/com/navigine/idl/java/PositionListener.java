package com.navigine.idl.java;

/**
 * Class provides a callback to be invoked when {@link com.navigine.idl.java.NavigationManager NavigationManager}
 * updates the position of the device.
 * Referenced from {@link com.navigine.idl.java.NavigationManager NavigationManager} {@link com.navigine.idl.java.RouteManager RouteManager}.
 * <p><b>Note:</b> The callback is invoked in the UI thread.</p>
 */
public abstract class PositionListener {
    /**
     * Called when new position has been calculated
     * @param position current user {@link com.navigine.idl.java.Position Position}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * public void onPositionUpdated(Position position) {
     *    System.out.println("Position updated successfully");
     *    demonstratePositionUsage(position);
     * }
     * }
     * </pre>
     */
    public abstract void onPositionUpdated(Position position);

    /**
     * Called if unable to calculate user's position
     * @param error handled error.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * public void onPositionError(Error error) {
     *    System.err.println("Position error: " + error.getMessage());
     * }
     * }
     * </pre>
     */
    public abstract void onPositionError(java.lang.Error error);
}
