package com.navigine.idl.java;

/**
 * Color theme of the outdoor vector basemap.
 * Indoor floor rasters, venue icons, and user map objects are unchanged.
 */
public enum MapTheme {
    /**
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * MapTheme[] themes = { MapTheme.LIGHT, MapTheme.DARK };
     * System.out.println("Map themes: " + themes.length);
     * }
     * </pre>
     * Light outdoor basemap (default).
     */
    LIGHT,
    /**
     * Dark outdoor basemap (versatiles-shadow palette).
     */
    DARK,
    ;
}
