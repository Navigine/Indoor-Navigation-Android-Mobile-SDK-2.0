package com.navigine.idl.java;

/**
 * Class is used for storing <a href="https://en.wikipedia.org/wiki/Eddystone_(Google)">Eddystone</a>.
 * Referenced from {@link com.navigine.idl.java.Sublocation Sublocation}.
 */
public abstract class Eddystone {
    /**
     * eddystone's X and Y coordinates in meters as {@link com.navigine.idl.java.Point Point} (within the sublocation).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get Eddystone point
     * Point point = eddystone.getPoint();
     * if (point != null) {
     *    demonstratePointUsage(point);
     * }
     * }
     * </pre>
     * @return eddystone's X and Y coordinates in meters as {@link Point Point} (within the sublocation).
     */
    public abstract Point getPoint();

    /**
     * eddystone's location identifier.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get Eddystone location ID
     * int locationId = eddystone.getLocationId();
     * System.out.println("Eddystone location ID: " + locationId);
     * }
     * </pre>
     * @return eddystone's location identifier.
     */
    public abstract int getLocationId();

    /**
     * eddystone's sublocation identifier.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get Eddystone sublocation ID
     * int sublocationId = eddystone.getSublocationId();
     * System.out.println("Eddystone sublocation ID: " + sublocationId);
     * }
     * </pre>
     * @return eddystone's sublocation identifier.
     */
    public abstract int getSublocationId();

    /**
     * eddystone's name.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get Eddystone name
     * String eddystoneName = eddystone.getName();
     * System.out.println("Eddystone name: " + eddystoneName);
     * }
     * </pre>
     * @return eddystone's name.
     */
    public abstract String getName();

    /**
     * eddystone's namespaceId.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get Eddystone namespace ID
     * String namespaceId = eddystone.getNamespaceId();
     * System.out.println("Eddystone namespace ID: " + namespaceId);
     * }
     * </pre>
     * @return eddystone's namespaceId.
     */
    public abstract String getNamespaceId();

    /**
     * eddystone's instanceId.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get Eddystone instance ID
     * String instanceId = eddystone.getInstanceId();
     * System.out.println("Eddystone instance ID: " + instanceId);
     * }
     * </pre>
     * @return eddystone's instanceId.
     */
    public abstract String getInstanceId();

    /**
     * eddystone's power.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get Eddystone power
     * Integer power = eddystone.getPower();
     * if (power != null) {
     *    System.out.println("Eddystone power: " + power);
     * }
     * }
     * </pre>
     * @return eddystone's power.
     */
    public abstract Integer getPower();

    /**
     * eddystone status. {@link com.navigine.idl.java.TransmitterStatus TransmitterStatus}
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get Eddystone status
     * TransmitterStatus status = eddystone.getStatus();
     * System.out.println("Eddystone status: " + status);
     * }
     * </pre>
     * @return eddystone status. {@link TransmitterStatus TransmitterStatus}
     */
    public abstract TransmitterStatus getStatus();

    /**
     * Tells if this {@link Eddystone} is valid or not. Any other method
     * (except for this one) called on an invalid {@link Eddystone} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
