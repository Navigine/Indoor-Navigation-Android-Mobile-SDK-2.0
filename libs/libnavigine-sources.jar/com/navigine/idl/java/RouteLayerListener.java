package com.navigine.idl.java;

public abstract class RouteLayerListener {
    public abstract void onRouteChanged(RouteLayerStatus status, RouteView route);

    public abstract void onRouteAdvanced(RouteProgress progress);

    public abstract void onRouteTargetReached();
}
