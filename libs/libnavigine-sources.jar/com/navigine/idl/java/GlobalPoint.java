package com.navigine.idl.java;

/**
 * A point at the specified WGS84 coordinates.
 * Referenced from {@link com.navigine.idl.java.GeometryUtils GeometryUtils}, {@link com.navigine.idl.java.NavigationManager NavigationManager}, {@link com.navigine.idl.java.Position Position}, {@link com.navigine.idl.java.Sublocation Sublocation}.
 *
 * <p><b>Example:</b></p>
 * <pre>
 * {@code
 * // Create global points with latitude, longitude
 * GlobalPoint globalPoint1 = new GlobalPoint(55.7558, 37.6176); // Moscow
 * GlobalPoint globalPoint2 = new GlobalPoint(59.9311, 30.3609); // St. Petersburg
 * GlobalPoint globalPoint3 = new GlobalPoint(55.7522, 37.6156); // Moscow center
 * System.out.println("Created global points: GP1(" + globalPoint1.getLatitude() + ", " + globalPoint1.getLongitude() +
 *                  "), GP2(" + globalPoint2.getLatitude() + ", " + globalPoint2.getLongitude() + ")");
 * }
 * </pre>
 */
public final class GlobalPoint {


    /*package*/ final double latitude;

    /*package*/ final double longitude;

    /**
     * Default constructor for class GlobalPoint
     */
    public GlobalPoint(
            double latitude,
            double longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }

    /**
     * point's latitude.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get latitude
     * double lat1 = globalPoint1.getLatitude();
     * System.out.println("GlobalPoint1 latitude: " + lat1);
     * }
     * </pre>
     * @return point's latitude.
     */
    public double getLatitude() {
        return latitude;
    }

    /**
     * point's longitude.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get longitude
     * double lon1 = globalPoint1.getLongitude();
     * System.out.println("GlobalPoint1 longitude: " + lon1);
     * }
     * </pre>
     * @return point's longitude.
     */
    public double getLongitude() {
        return longitude;
    }

    @Override
    public String toString() {
        return "GlobalPoint{" +
                "latitude=" + latitude +
                "," + "longitude=" + longitude +
        "}";
    }

}
