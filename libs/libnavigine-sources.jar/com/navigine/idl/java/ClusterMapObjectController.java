package com.navigine.idl.java;

import com.navigine.platform.NativeObject;
import com.navigine.platform.Subscription;
import java.util.ArrayList;

/**
 * Groups {@link com.navigine.idl.java.IconMapObject IconMapObject} instances into clusters depending on zoom and proximity.
 * Referenced from {@link com.navigine.idl.java.LocationWindow LocationWindow}.
 * Register icons with {@code addIconMapObject}, then optionally customize cluster appearance in
 * {@link com.navigine.idl.java.ClusterMapObjectControllerListener ClusterMapObjectControllerListener} ({@code onClusterCreated}) and
 * {@link com.navigine.idl.java.ClusterMapObjectListener ClusterMapObjectListener} ({@code onClusterChanged}).
 */
public abstract class ClusterMapObjectController {
    /**
     * Adds an icon map object to the cluster controller.
     * @param iconMapObject Icon to cluster {@link com.navigine.idl.java.IconMapObject IconMapObject}. Must be added to the same {@link com.navigine.idl.java.LocationWindow LocationWindow} via {@code addIconMapObject}.
     * @return true if the icon was added, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * boolean added1 = clusterMapObjectController.addIconMapObject(clusterIcon1);
     * boolean added2 = clusterMapObjectController.addIconMapObject(clusterIcon2);
     * System.out.println("Registered icons for clustering: " + added1 + ", " + added2);
     * }
     * </pre>
     */
    public abstract boolean addIconMapObject(IconMapObject iconMapObject);

    /**
     * Removes an icon map object from the cluster controller.
     * @param iconMapObject Icon to remove.
     * @return true if the icon was removed, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * boolean removed = clusterMapObjectController.removeIconMapObject(clusterIcon1);
     * System.out.println("Removed icon from cluster controller: " + removed);
     * }
     * </pre>
     */
    public abstract boolean removeIconMapObject(IconMapObject iconMapObject);

    /**
     * Removes all icon map objects from the controller and destroys visible cluster markers.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * clusterMapObjectController.clear();
     * System.out.println("Cleared cluster controller");
     * }
     * </pre>
     */
    public abstract void clear();

    /**
     * Enables or disables clustering. Default: true.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * clusterMapObjectController.setEnabled(true);
     * System.out.println("Clustering enabled");
     * }
     * </pre>
     */
    public abstract void setEnabled(boolean enabled);

    /**
     * Returns whether clustering is enabled.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * boolean clusteringEnabled = clusterMapObjectController.isEnabled();
     * System.out.println("Clustering is enabled: " + clusteringEnabled);
     * }
     * </pre>
     */
    public abstract boolean isEnabled();

    /**
     * Cluster radius in density-independent pixels. Default: 40.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * clusterMapObjectController.setRadius(40.0f);
     * System.out.println("Set cluster radius to 40 px");
     * }
     * </pre>
     */
    public abstract void setRadius(float radius);

    /**
     * Returns cluster radius in density-independent pixels.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * float clusterRadius = clusterMapObjectController.getRadius();
     * System.out.println("Cluster radius: " + clusterRadius);
     * }
     * </pre>
     */
    public abstract float getRadius();

    /**
     * Specifies whether cluster markers can be picked. Default: true.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * boolean interactiveSuccess = clusterMapObjectController.setInteractive(true);
     * System.out.println("Set cluster markers interactive: " + interactiveSuccess);
     * }
     * </pre>
     */
    public abstract boolean setInteractive(boolean interactive);

    /**
     * Specifies the size of the default cluster icon in pixels.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * boolean sizeSuccess = clusterMapObjectController.setClusterSize(32.0f, 32.0f);
     * System.out.println("Set default cluster icon size: " + sizeSuccess);
     * }
     * </pre>
     */
    public abstract boolean setClusterSize(float width, float height);

    /**
     * Adds a listener for cluster lifecycle events {@link com.navigine.idl.java.ClusterMapObjectControllerListener ClusterMapObjectControllerListener}.
     * @param listener Listener instance.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * clusterMapObjectController.addListener(clusterMapObjectControllerListener);
     * System.out.println("Added cluster map object controller listener");
     * }
     * </pre>
     */
    public abstract void addListener(ClusterMapObjectControllerListener listener);

    /**
     * Removes a previously added listener.
     * @param listener Listener instance to remove.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * clusterMapObjectController.removeListener(clusterMapObjectControllerListener);
     * System.out.println("Removed cluster map object controller listener");
     * }
     * </pre>
     */
    public abstract void removeListener(ClusterMapObjectControllerListener listener);

    /**
     * Returns a snapshot of currently visible clusters.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * List<ClusterMapObject> clusters = clusterMapObjectController.getClusters();
     * System.out.println("Visible clusters: " + clusters.size());
     * }
     * </pre>
     */
    public abstract ArrayList<ClusterMapObject> getClusters();

    /**
     * Tells if this {@link ClusterMapObjectController} is valid or not. Any other method
     * (except for this one) called on an invalid {@link ClusterMapObjectController} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
