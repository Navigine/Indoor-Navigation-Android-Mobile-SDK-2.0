package com.navigine.idl.java;

/**
 * Enum describing turn direction/severity for {@link com.navigine.idl.java.TurnEvent TurnEvent}.
 * Referenced from {@link com.navigine.idl.java.TurnEvent TurnEvent}.
 *
 * <p><b>Example:</b></p>
 * <pre>
 * {@code
 * TurnType[] turnTypes = TurnType.values();
 * System.out.println("Available turn types:");
 * for (TurnType turnType : turnTypes) {
 *    System.out.println("  - " + turnType);
 * }
 * }
 * </pre>
 */
public enum TurnType {
    /**
     * Minor left adjustment (approx. 10°–40°).
     */
    LEFT_SLIGHT,
    /**
     * Standard left turn (approx. 40°–100°).
     */
    LEFT_NORMAL,
    /**
     * Sharp left turn (approx. 100°–160°).
     */
    LEFT_SHARP,
    /**
     * Minor right adjustment (approx. 10°–40°).
     */
    RIGHT_SLIGHT,
    /**
     * Standard right turn (approx. 40°–100°).
     */
    RIGHT_NORMAL,
    /**
     * Sharp right turn (approx. 100°–160°).
     */
    RIGHT_SHARP,
    /**
     * Near U-turn / reversal (approx. 160°–180°).
     */
    COMPLETE,
    ;
}
