package com.navigine.idl.java;

import com.navigine.platform.NativeObject;
import com.navigine.platform.Subscription;

/**
 * Class is used for managing measurement generators and notifying about sensor and signal measurements.
 * Referenced from {@link com.navigine.idl.java.NavigineSdk NavigineSdk}.
 */
public abstract class MeasurementManager {
    /**
     * Method is used to add {@link com.navigine.idl.java.MeasurementListener MeasurementListener} class element
     * which will notify about new sensor or signal measurements.
     * <p><b>Note:</b> Do not forget to remove listener if it is no longer needed!</p>
     * @param listener Corresponding {@link com.navigine.idl.java.MeasurementListener MeasurementListener} class.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Add measurement listener
     * measurementManager.addMeasurementListener(measurementListener);
     * System.out.println("Added measurement listener");
     * }
     * </pre>
     */
    public abstract void addMeasurementListener(MeasurementListener listener);

    /**
     * Method is used for removing previously added {@link com.navigine.idl.java.MeasurementListener MeasurementListener} class element.
     * @param listener Corresponding {@link com.navigine.idl.java.MeasurementListener MeasurementListener} class to remove.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove measurement listener
     * measurementManager.removeMeasurementListener(measurementListener);
     * System.out.println("Removed measurement listener");
     * }
     * </pre>
     */
    public abstract void removeMeasurementListener(MeasurementListener listener);

    /**
     * Sets the interval in milliseconds between measurement batches delivered to {@link com.navigine.idl.java.MeasurementListener MeasurementListener}. Default is 1000 ms. Values less than or equal to zero are treated as the default.
     * @param intervalMs wait time in milliseconds before the next publish cycle
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Optional: interval between measurement batches sent to listeners (ms)
     * measurementManager.setPublishIntervalMs(1000);
     * }
     * </pre>
     */
    public abstract void setPublishIntervalMs(int intervalMs);

    /**
     * Method adds a beacon generator for simulating BLE beacon signals.
     * @param uuid UUID of the beacon.
     * @param major Major value of the beacon.
     * @param minor Minor value of the beacon.
     * @param power Transmission power of the beacon (dBm).
     * @param timeout Duration of the generator in milliseconds.
     * @param rssiMin Minimum RSSI value for the simulated signal.
     * @param rssiMax Maximum RSSI value for the simulated signal.
     * @return Unique identifier of the created beacon generator.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Add beacon generator
     * String beaconId = measurementManager.addBeaconGenerator(
     *    "12345678-1234-1234-1234-123456789012", // UUID
     *    100, // major
     *    200, // minor
     *    -60, // power (dBm)
     *    5000, // timeout (ms)
     *    -80, // rssiMin
     *    -40  // rssiMax
     * );
     * System.out.println("Added beacon generator with ID: " + beaconId);
     * }
     * </pre>
     */
    public abstract String addBeaconGenerator(String uuid, int major, int minor, int power, int timeout, int rssiMin, int rssiMax);

    /**
     * Method adds an Eddystone generator for simulating Eddystone beacon signals.
     * @param namespaceId Namespace ID of the Eddystone beacon.
     * @param instanceId Instance ID of the Eddystone beacon.
     * @param power Transmission power of the beacon (dBm).
     * @param timeout Duration of the generator in milliseconds.
     * @param rssiMin Minimum RSSI value for the simulated signal.
     * @param rssiMax Maximum RSSI value for the simulated signal.
     * @return Unique identifier of the created Eddystone generator.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Add Eddystone generator
     * String eddystoneId = measurementManager.addEddystoneGenerator(
     *    "12345678901234567890", // namespaceId
     *    "1234567890123456", // instanceId
     *    -65, // power (dBm)
     *    3000, // timeout (ms)
     *    -85, // rssiMin
     *    -45  // rssiMax
     * );
     * System.out.println("Added Eddystone generator with ID: " + eddystoneId);
     * }
     * </pre>
     */
    public abstract String addEddystoneGenerator(String namespaceId, String instanceId, int power, int timeout, int rssiMin, int rssiMax);

    /**
     * Method removes all BLE beacon generators.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove all BLE generators
     * measurementManager.removeBleGenerators();
     * System.out.println("Removed all BLE generators");
     * }
     * </pre>
     */
    public abstract void removeBleGenerators();

    /**
     * Method removes a specific BLE beacon generator by its identifier.
     * @param id Unique identifier of the BLE generator to remove.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove specific BLE generator
     * measurementManager.removeBleGenerator(beaconId);
     * System.out.println("Removed BLE generator: " + beaconId);
     * }
     * </pre>
     */
    public abstract void removeBleGenerator(String id);

    /**
     * Method adds a Wi-Fi generator for simulating Wi-Fi signals.
     * @param mac MAC address of the Wi-Fi access point.
     * @param timeout Duration of the generator in milliseconds.
     * @param rssiMin Minimum RSSI value for the simulated signal.
     * @param rssiMax Maximum RSSI value for the simulated signal.
     * @return Unique identifier of the created Wi-Fi generator.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Add Wi-Fi generator
     * String wifiId = measurementManager.addWifiGenerator(
     *    "AA:BB:CC:DD:EE:FF", // MAC address
     *    4000, // timeout (ms)
     *    -90, // rssiMin
     *    -50  // rssiMax
     * );
     * System.out.println("Added Wi-Fi generator with ID: " + wifiId);
     * }
     * </pre>
     */
    public abstract String addWifiGenerator(String mac, int timeout, int rssiMin, int rssiMax);

    /**
     * Method removes a specific Wi-Fi generator by its identifier.
     * @param id Unique identifier of the Wi-Fi generator to remove.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove specific Wi-Fi generator
     * measurementManager.removeWifiGenerator(wifiId);
     * System.out.println("Removed Wi-Fi generator: " + wifiId);
     * }
     * </pre>
     */
    public abstract void removeWifiGenerator(String id);

    /**
     * Method removes all Wi-Fi generators.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove all Wi-Fi generators
     * measurementManager.removeWifiGenerators();
     * System.out.println("Removed all Wi-Fi generators");
     * }
     * </pre>
     */
    public abstract void removeWifiGenerators();

    /**
     * Method adds a Wi-Fi RTT generator for simulating Wi-Fi Round-Trip Time signals.
     * @param mac MAC address of the Wi-Fi access point.
     * @param timeout Duration of the generator in milliseconds.
     * @param distMin Minimum distance for the simulated signal (in meters).
     * @param distMax Maximum distance for the simulated signal (in meters).
     * @param stdDevMin Minimum standard deviation for the simulated signal.
     * @param stdDevMax Maximum standard deviation for the simulated signal.
     * @param rssiMin Minimum RSSI value for the simulated signal.
     * @param rssiMax Maximum RSSI value for the simulated signal.
     * @return Unique identifier of the created Wi-Fi RTT generator.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Add Wi-Fi RTT generator
     * String wifiRttId = measurementManager.addWifiRttGenerator(
     *    "11:22:33:44:55:66", // MAC address
     *    6000, // timeout (ms)
     *    1, // distMin (meters)
     *    10, // distMax (meters)
     *    0, // stdDevMin
     *    2, // stdDevMax
     *    -70, // rssiMin
     *    -30  // rssiMax
     * );
     * System.out.println("Added Wi-Fi RTT generator with ID: " + wifiRttId);
     * }
     * </pre>
     */
    public abstract String addWifiRttGenerator(String mac, int timeout, int distMin, int distMax, int stdDevMin, int stdDevMax, int rssiMin, int rssiMax);

    /**
     * Method removes a specific Wi-Fi RTT generator by its identifier.
     * @param hash Unique identifier of the Wi-Fi RTT generator to remove.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove specific Wi-Fi RTT generator
     * measurementManager.removeWifiRttGenerator(wifiRttId);
     * System.out.println("Removed Wi-Fi RTT generator: " + wifiRttId);
     * }
     * </pre>
     */
    public abstract void removeWifiRttGenerator(String hash);

    /**
     * Method removes all Wi-Fi RTT generators.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove all Wi-Fi RTT generators
     * measurementManager.removeWifiRttGenerators();
     * System.out.println("Removed all Wi-Fi RTT generators");
     * }
     * </pre>
     */
    public abstract void removeWifiRttGenerators();

    /**
     * Method adds a location generator for simulating location measurements.
     * @param latMin Minimum latitude for the simulated location.
     * @param latMax Maximum latitude for the simulated location.
     * @param lonMin Minimum longitude for the simulated location.
     * @param lonMax Maximum longitude for the simulated location.
     * @param accMin Minimum accuracy for the simulated location (in meters).
     * @param accMax Maximum accuracy for the simulated location (in meters).
     * @param timeout Duration of the generator in milliseconds.
     * @return Unique identifier of the created location generator.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Add location generator
     * String locationId = measurementManager.addLocationGenerator(
     *    55.7558, // latMin
     *    55.7559, // latMax
     *    37.6176, // lonMin
     *    37.6177, // lonMax
     *    1.0, // accMin (meters)
     *    5.0, // accMax (meters)
     *    7000  // timeout (ms)
     * );
     * System.out.println("Added location generator with ID: " + locationId);
     * }
     * </pre>
     */
    public abstract String addLocationGenerator(double latMin, double latMax, double lonMin, double lonMax, float accMin, float accMax, int timeout);

    /**
     * Method removes a specific location generator by its identifier.
     * @param id Unique identifier of the location generator to remove.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove specific location generator
     * measurementManager.removeLocationGenerator(locationId);
     * System.out.println("Removed location generator: " + locationId);
     * }
     * </pre>
     */
    public abstract void removeLocationGenerator(String id);

    /**
     * Method removes all location generators.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove all location generators
     * measurementManager.removeLocationGenerators();
     * System.out.println("Removed all location generators");
     * }
     * </pre>
     */
    public abstract void removeLocationGenerators();
}
