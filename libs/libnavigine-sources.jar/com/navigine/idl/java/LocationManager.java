package com.navigine.idl.java;

import com.navigine.common.NativeObject;
import com.navigine.common.Subscription;

/**
 * Class is used for downloading and working with {@link com.navigine.idl.java.Location Location}.
 * Referenced from {@link com.navigine.idl.java.NavigineSdk NavigineSdk}.
 */
public abstract class LocationManager {
    /**
     * Method is used to add {@link com.navigine.idl.java.LocationListener LocationListener} element
     * which will notify about newly downloaded and set location.
     * <p><b>Note:</b> Do not forget to remove listener if it is no longer needed!</p>
     * @param listener Corresponding {@link com.navigine.idl.java.LocationListener LocationListener} class.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Add location listener
     * locationManager.addLocationListener(locationListener);
     * }
     * </pre>
     */
    public abstract void addLocationListener(LocationListener listener);

    /**
     * Method is used for removing previously added {@link com.navigine.idl.java.LocationListener LocationListener} class element.
     * @param listener Corresponding {@link com.navigine.idl.java.LocationListener LocationListener} class to remove.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove location listener
     * locationManager.removeLocationListener(locationListener);
     * }
     * </pre>
     */
    public abstract void removeLocationListener(LocationListener listener);

    /**
     * Method is used for setting current location, which will be downloaded from server or from storage, if it was downloaded before.
     * Result will be handled by {@link com.navigine.idl.java.LocationListener LocationListener}
     * @param locationId location id from CMS
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set location ID to load
     * locationManager.setLocationId(12345);
     * }
     * </pre>
     */
    public abstract void setLocationId(int locationId);

    /**
     * Method returns current location unique identifier
     * @return current location unique identifier
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get current location ID
     * int currentLocationId = locationManager.getLocationId();
     * System.out.println("Current location ID: " + currentLocationId);
     * }
     * </pre>
     */
    public abstract int getLocationId();

    public abstract void commitChanges();

    public abstract void revertChanges();

    /**
     * Method is used to change interval in seconds check for new version from server
     * Default: 300s
     * @param interval update interval in seconds
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set location update interval (in seconds)
     * locationManager.setLocationUpdateInterval(600); // 10 minutes
     * }
     * </pre>
     */
    public abstract void setLocationUpdateInterval(int interval);
}
