package com.navigine.idl.java;

/**
 * Enum describing possible router states.
 * Referenced from {@link com.navigine.idl.java.AsyncRouteListener AsyncRouteListener}.
 *
 * <p><b>Example:</b></p>
 * <pre>
 * {@code
 * // Demonstrate all RouteStatus values
 * System.out.println("Available RouteStatus values:");
 * for (RouteStatus status : RouteStatus.values()) {
 *    System.out.println("  - " + status.name() + ": " + status.toString());
 * }
 * // Demonstrate status checking
 * RouteStatus testStatus = RouteStatus.NEW_ROUTE;
 * if (testStatus == RouteStatus.NEW_ROUTE) {
 *    System.out.println("Router is ready for navigation");
 * } else if (testStatus == RouteStatus.MISSING_GRAPH) {
 *    System.out.println("Router is missing the route graph");
 * } else if (testStatus == RouteStatus.MISSING_POSITION) {
 *    System.out.println("Router is missing the current position");
 * } else if (testStatus == RouteStatus.MISSING_PROJECTION) {
 *    System.out.println("Current position is off the route graph");
 * } else if (testStatus == RouteStatus.MISSING_ROUTE) {
 *    System.out.println("Router unable to find the route to the destination point");
 * }
 * }
 * </pre>
 */
public enum RouteStatus {
    /**
     * Router is missing the route graph.
     */
    MISSING_GRAPH,
    /**
     * Router is missing the current position.
     */
    MISSING_POSITION,
    /**
     * Router unable to find the route to the destination point.
     */
    MISSING_ROUTE,
    /**
     * Current position is off the route graph.
     */
    MISSING_PROJECTION,
    /**
     * Router is ready and has a valid route.
     */
    NEW_ROUTE,
    ;
}
