package com.navigine.idl.java;

/**
 * Class storing one route event payload.
 * Referenced from {@link com.navigine.idl.java.RoutePath RoutePath}, {@link com.navigine.idl.java.RouteNode RouteNode}.
 */
public final class RouteEvent {


    /*package*/ final RouteEventType type;

    /*package*/ final TurnEvent turnEvent;

    /*package*/ final TransitionEntryEvent transitionEntryEvent;

    /*package*/ final TransitionExitEvent transitionExitEvent;

    /*package*/ final TargetReachedEvent targetReachedEvent;

    /**
     * Default constructor for class RouteEvent
     */
    public RouteEvent(
            RouteEventType type,
            TurnEvent turnEvent,
            TransitionEntryEvent transitionEntryEvent,
            TransitionExitEvent transitionExitEvent,
            TargetReachedEvent targetReachedEvent) {
        this.type = type;
        this.turnEvent = turnEvent;
        this.transitionEntryEvent = transitionEntryEvent;
        this.transitionExitEvent = transitionExitEvent;
        this.targetReachedEvent = targetReachedEvent;
    }

    /**
     * Active event variant discriminator.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get event type
     * RouteEventType type = event.getType();
     * System.out.println("Event type: " + type);
     * }
     * </pre>
     * @return Active event variant discriminator.
     */
    public RouteEventType getType() {
        return type;
    }

    /**
     * Payload for turn events, set when type is TURN_EVENT.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * TurnEvent turnEvent = event.getTurnEvent();
     * if (turnEvent != null) {
     *    demonstrateTurnEventUsage(turnEvent);
     * }
     * }
     * </pre>
     * @return Payload for turn events, set when type is TURN_EVENT.
     */
    public TurnEvent getTurnEvent() {
        return turnEvent;
    }

    /**
     * Payload for transition entry events.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * TransitionEntryEvent entryEvent = event.getTransitionEntryEvent();
     * if (entryEvent != null) {
     *    demonstrateTransitionEntryEventUsage(entryEvent);
     * }
     * }
     * </pre>
     * @return Payload for transition entry events.
     */
    public TransitionEntryEvent getTransitionEntryEvent() {
        return transitionEntryEvent;
    }

    /**
     * Payload for transition exit events.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * TransitionExitEvent exitEvent = event.getTransitionExitEvent();
     * if (exitEvent != null) {
     *    demonstrateTransitionExitEventUsage(exitEvent);
     * }
     * }
     * </pre>
     * @return Payload for transition exit events.
     */
    public TransitionExitEvent getTransitionExitEvent() {
        return transitionExitEvent;
    }

    /**
     * Payload for target reached events.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * TargetReachedEvent reachedEvent = event.getTargetReachedEvent();
     * if (reachedEvent != null) {
     *    demonstrateTargetReachedEventUsage(reachedEvent);
     * }
     * }
     * </pre>
     * @return Payload for target reached events.
     */
    public TargetReachedEvent getTargetReachedEvent() {
        return targetReachedEvent;
    }

    @Override
    public String toString() {
        return "RouteEvent{" +
                "type=" + type +
                "," + "turnEvent=" + turnEvent +
                "," + "transitionEntryEvent=" + transitionEntryEvent +
                "," + "transitionExitEvent=" + transitionExitEvent +
                "," + "targetReachedEvent=" + targetReachedEvent +
        "}";
    }

}
