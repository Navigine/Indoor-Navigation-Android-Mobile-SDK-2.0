package com.navigine.idl.java;

public abstract class ResourceUploadListener {
    public abstract void onUploaded(String fileName);

    public abstract void onFailed(java.lang.Error error);
}
