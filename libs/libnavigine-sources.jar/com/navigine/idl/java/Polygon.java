package com.navigine.idl.java;

import java.util.ArrayList;

/**
 * A polygon with specified list of points.
 *
 * <p><b>Example:</b></p>
 * <pre>
 * {@code
 * // Create polygon
 * Polygon polygon = new Polygon(polygonPoints);
 * System.out.println("Created polygon with " + polygon.getPoints().size() + " points");
 * }
 * </pre>
 */
public final class Polygon {


    /*package*/ final ArrayList<Point> points;

    /**
     * Default constructor for class Polygon
     */
    public Polygon(
            ArrayList<Point> points) {
        this.points = points;
    }

    /**
     * Ring specifying the area.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get polygon points
     * List<Point> points = polygon.getPoints();
     * System.out.println("Polygon points: " + points.stream()
     *    .map(p -> "(" + p.getX() + ", " + p.getY() + ")")
     *    .reduce("", (a, b) -> a + (a.isEmpty() ? "" : ", ") + b));
     * }
     * </pre>
     * @return Ring specifying the area.
     */
    public ArrayList<Point> getPoints() {
        return points;
    }

    @Override
    public String toString() {
        return "Polygon{" +
                "points=" + points +
        "}";
    }

}
