package com.navigine.idl.java;

/**
 * Reason of the camera update.
 * Referenced from {@link com.navigine.idl.java.CameraListener CameraListener}.
 */
public enum CameraUpdateReason {
    /**
     * user manipulation.
     * For example: zoom, scroll, rotate, fling.
     */
    GESTURES,
    /**
     * Application.
     * By calling the LocationView::move methods.
     */
    APPLICATION,
    ;
}
