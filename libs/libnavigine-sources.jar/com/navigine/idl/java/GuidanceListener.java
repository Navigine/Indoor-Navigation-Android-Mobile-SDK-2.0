package com.navigine.idl.java;

/**
 * Guidance camera and next-instruction updates.
 */
public abstract class GuidanceListener {
    /**
     * Mode changed, including an automatic drop to `FREE` after a gesture.
     */
    public abstract void onCameraModeChanged(GuidanceCameraMode mode);

    /**
     * Next instruction changed, or null when the route is gone / finished.
     */
    public abstract void onInstructionChanged(RouteInstruction instruction);
}
