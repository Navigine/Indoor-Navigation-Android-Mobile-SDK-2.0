package com.navigine.idl.java;

/**
 * Rectangle on the device screen, in screen pixels (same units as ScreenPoint).
 * Used as {@code LocationWindow.focusRect} and with {@code getEnclosingCameraWithFocus}
 * so chrome (floor selector, follow-me, POI card) does not cover the fitted
 * geometry. Null / unset means the full viewport.
 * Origin is the top-left of the map view; +x right, +y down.
 */
public final class ScreenRect {


    /*package*/ final android.graphics.PointF topLeft;

    /*package*/ final android.graphics.PointF bottomRight;

    /**
     * Default constructor for class ScreenRect
     */
    public ScreenRect(
            android.graphics.PointF topLeft,
            android.graphics.PointF bottomRight) {
        this.topLeft = topLeft;
        this.bottomRight = bottomRight;
    }

    /**
     * Top-left corner {@link com.navigine.idl.java.ScreenPoint ScreenPoint}.
     * @return Top-left corner {@link ScreenPoint ScreenPoint}.
     */
    public android.graphics.PointF getTopLeft() {
        return topLeft;
    }

    /**
     * Bottom-right corner {@link com.navigine.idl.java.ScreenPoint ScreenPoint}.
     * @return Bottom-right corner {@link ScreenPoint ScreenPoint}.
     */
    public android.graphics.PointF getBottomRight() {
        return bottomRight;
    }

    @Override
    public String toString() {
        return "ScreenRect{" +
                "topLeft=" + topLeft +
                "," + "bottomRight=" + bottomRight +
        "}";
    }

}
