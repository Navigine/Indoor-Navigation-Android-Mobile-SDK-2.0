package com.navigine.idl.java;

/**
 * Class describing position of the camera.
 * Referenced from {@link com.navigine.idl.java.LocationWindow LocationWindow}.
 *
 * <p><b>Example:</b></p>
 * <pre>
 * {@code
 * // Create camera with constructor
 * Point newPoint = new Point(100.0, 200.0);
 * Camera newCamera = new Camera(newPoint, 50.0, 0.0, 0.0);
 * System.out.println("Created camera with point (" + newPoint.x + ", " + newPoint.y + "), zoom 50.0, rotation 0°, tilt 0°");
 * }
 * </pre>
 */
public final class Camera {


    /*package*/ final Point point;

    /*package*/ final float zoom;

    /*package*/ final float rotation;

    /*package*/ final float tilt;

    /**
     * Default constructor for class Camera
     */
    public Camera(
            Point point,
            float zoom,
            float rotation,
            float tilt) {
        this.point = point;
        this.zoom = zoom;
        this.rotation = rotation;
        this.tilt = tilt;
    }

    /**
     * point the camera is looking at {@link com.navigine.idl.java.Point Point}
     * @return point the camera is looking at {@link Point Point}
     */
    public Point getPoint() {
        return point;
    }

    /**
     * zoom level.
     * @return zoom level.
     */
    public float getZoom() {
        return zoom;
    }

    /**
     * Map azimuth in degrees: angle between `Location North` (top of the image) and the direction of interest
     * on the view plane, in the range [0, 360).
     * @return Map azimuth in degrees: angle between {@code Location North} (top of the image) and the direction of interest
     */
    public float getRotation() {
        return rotation;
    }

    /**
     * Camera tilt in degrees. 0 means vertical downward (map seen from above).
     * Positive values tilt the eye toward the horizon; the renderer clamps tilt to device limits when applying.
     * @return Camera tilt in degrees. 0 means vertical downward (map seen from above).
     */
    public float getTilt() {
        return tilt;
    }

    @Override
    public String toString() {
        return "Camera{" +
                "point=" + point +
                "," + "zoom=" + zoom +
                "," + "rotation=" + rotation +
                "," + "tilt=" + tilt +
        "}";
    }

}
