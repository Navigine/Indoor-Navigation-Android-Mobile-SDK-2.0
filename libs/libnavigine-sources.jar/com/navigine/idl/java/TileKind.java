package com.navigine.idl.java;

/**
 * Payload of a {@link com.navigine.idl.java.TileProvider TileProvider}.
 * {@code vector} is MVT and uses {@code schema}. {@code raster} is PNG, JPEG, or WebP imagery
 * on {@code LocationWindow.tileProvider}; {@code schema} is ignored and outdoor vector
 * geometry and labels are hidden. Indoor floors stay on top.
 */
public enum TileKind {
    /**
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * TileKind[] kinds = { TileKind.VECTOR, TileKind.RASTER };
     * System.out.println("Tile kinds: " + kinds.length);
     * }
     * </pre>
     * Vector tiles (MVT). Default.
     */
    VECTOR,
    /**
     * Raster imagery tiles.
     */
    RASTER,
    ;
}
