package com.navigine.idl.java;

/**
 * Class is used for storing <a href="https://en.wikipedia.org/wiki/Wi-Fi">WiFi</a>.
 * Referenced from {@link com.navigine.idl.java.Sublocation Sublocation}.
 */
public abstract class Wifi {
    /**
     * wifi's X and Y coordinates in meters as {@link com.navigine.idl.java.Point Point} (within the sublocation).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get WiFi point
     * Point point = wifi.getPoint();
     * if (point != null) {
     *    demonstratePointUsage(point);
     * }
     * }
     * </pre>
     * @return wifi's X and Y coordinates in meters as {@link Point Point} (within the sublocation).
     */
    public abstract Point getPoint();

    /**
     * wifi's location identifier.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get WiFi location ID
     * int locationId = wifi.getLocationId();
     * System.out.println("WiFi location ID: " + locationId);
     * }
     * </pre>
     * @return wifi's location identifier.
     */
    public abstract int getLocationId();

    /**
     * wifi's sublocation identifier.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get WiFi sublocation ID
     * int sublocationId = wifi.getSublocationId();
     * System.out.println("WiFi sublocation ID: " + sublocationId);
     * }
     * </pre>
     * @return wifi's sublocation identifier.
     */
    public abstract int getSublocationId();

    /**
     * wifi's name.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get WiFi name
     * String wifiName = wifi.getName();
     * System.out.println("WiFi name: " + wifiName);
     * }
     * </pre>
     * @return wifi's name.
     */
    public abstract String getName();

    /**
     * wifi's mac.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get WiFi MAC address
     * String mac = wifi.getMac();
     * System.out.println("WiFi MAC: " + mac);
     * }
     * </pre>
     * @return wifi's mac.
     */
    public abstract String getMac();

    /**
     * wifi's status. {@link com.navigine.idl.java.TransmitterStatus TransmitterStatus}
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get WiFi status
     * TransmitterStatus status = wifi.getStatus();
     * System.out.println("WiFi status: " + status);
     * }
     * </pre>
     * @return wifi's status. {@link TransmitterStatus TransmitterStatus}
     */
    public abstract TransmitterStatus getStatus();

    /**
     * Tells if this {@link Wifi} is valid or not. Any other method
     * (except for this one) called on an invalid {@link Wifi} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
