package com.navigine.idl.java;

import java.util.ArrayList;

/**
 * A polyline with specified number of points.
 */
public final class Polyline {


    /*package*/ final ArrayList<Point> points;

    /**
     * Default constructor for class Polyline
     */
    public Polyline(
            ArrayList<Point> points) {
        this.points = points;
    }

    /**
     * List of points to connect.
     * @return List of points to connect.
     */
    public ArrayList<Point> getPoints() {
        return points;
    }

    @Override
    public String toString() {
        return "Polyline{" +
                "points=" + points +
        "}";
    }

}
