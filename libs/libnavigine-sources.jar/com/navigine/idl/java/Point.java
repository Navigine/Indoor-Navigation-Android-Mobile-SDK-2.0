package com.navigine.idl.java;

/**
 * A point at the specified metrics coordinates.
 *
 * <p><b>Example:</b></p>
 * <pre>
 * {@code
 * // Create points with x, y coordinates
 * Point point1 = new Point(10.0, 20.0);
 * Point point2 = new Point(30.0, 40.0);
 * Point point3 = new Point(50.0, 60.0);
 * System.out.println("Created points: P1(" + point1.getX() + ", " + point1.getY() +
 *                  "), P2(" + point2.getX() + ", " + point2.getY() +
 *                  "), P3(" + point3.getX() + ", " + point3.getY() + ")");
 * }
 * </pre>
 */
public final class Point {


    /*package*/ final float x;

    /*package*/ final float y;

    /**
     * Default constructor for class Point
     */
    public Point(
            float x,
            float y) {
        this.x = x;
        this.y = y;
    }

    /**
     * point's `x` coordinate in meters.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get X coordinate
     * double x1 = point1.getX();
     * System.out.println("Point1 X coordinate: " + x1);
     * }
     * </pre>
     * @return point's {@code x} coordinate in meters.
     */
    public float getX() {
        return x;
    }

    /**
     * point's `y` coordinate in meters.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get Y coordinate
     * double y1 = point1.getY();
     * System.out.println("Point1 Y coordinate: " + y1);
     * }
     * </pre>
     * @return point's {@code y} coordinate in meters.
     */
    public float getY() {
        return y;
    }

    @Override
    public String toString() {
        return "Point{" +
                "x=" + x +
                "," + "y=" + y +
        "}";
    }

}
