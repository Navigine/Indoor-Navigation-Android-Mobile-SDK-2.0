package com.navigine.idl.java;

public enum LogLevel {
    ERROR,
    WARNING,
    INFO,
    DEBUGGING,
    ;
}
