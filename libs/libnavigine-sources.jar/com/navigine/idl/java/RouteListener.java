package com.navigine.idl.java;

import java.util.ArrayList;

/**
 * Class provides a callback to be invoked when {@link com.navigine.idl.java.RouteManager RouteManager}
 * updates routes to the target point or from point to point.
 * Referenced from {@link com.navigine.idl.java.RouteManager RouteManager}.
 * <p><b>Note:</b> The callback is invoked in the UI thread.</p>
 */
public abstract class RouteListener {
    /**
     * Called when new route has been calculated
     * @param paths calculated list of {@link com.navigine.idl.java.RoutePath RoutePath}s to added targets.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * public void onPathsUpdated(List<RoutePath> paths) {
     *    System.out.println("Routes updated successfully");
     *    demonstrateRoutePathUsage(paths);
     * }
     * }
     * </pre>
     */
    public abstract void onPathsUpdated(ArrayList<RoutePath> paths);
}
