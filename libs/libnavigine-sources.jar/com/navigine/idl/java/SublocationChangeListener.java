package com.navigine.idl.java;

/**
 * Class is used to listen for sublocation change events
 * Referenced from {@link com.navigine.idl.java.LocationWindow LocationWindow}.
 */
public abstract class SublocationChangeListener {
    /**
     * Called when active sublocation changes.
     * @param sublocationId New active sublocation identifier.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * @Override
     * public void onActiveSublocationChanged(int sublocationId) {
     *    System.out.println("Active sublocation changed to: " + sublocationId);
     * }
     * }
     * </pre>
     */
    public abstract void onActiveSublocationChanged(int sublocationId);
}
