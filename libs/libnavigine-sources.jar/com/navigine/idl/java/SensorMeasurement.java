package com.navigine.idl.java;

/**
 * Structure representing a sensor measurement with type, values, and timestamp.
 * Referenced from {@link com.navigine.idl.java.MeasurementListener MeasurementListener}.
 */
public final class SensorMeasurement implements Comparable<SensorMeasurement> {


    /*package*/ final SensorType type;

    /*package*/ final Vector3d values;

    /*package*/ final long time;

    /**
     * Default constructor for class SensorMeasurement
     */
    public SensorMeasurement(
            SensorType type,
            Vector3d values,
            long time) {
        this.type = type;
        this.values = values;
        this.time = time;
    }

    /**
     * Type of the sensor
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get sensor type
     * SensorType type = measurement.getType();
     * System.out.println("Sensor type: " + type);
     * }
     * </pre>
     * @return Type of the sensor
     */
    public SensorType getType() {
        return type;
    }

    /**
     * 3D vector containing sensor measurement values
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get sensor values
     * Vector3d values = measurement.getValues();
     * System.out.println("Sensor values - X: " + values.getX() + ", Y: " + values.getY() + ", Z: " + values.getZ());
     * }
     * </pre>
     * @return 3D vector containing sensor measurement values
     */
    public Vector3d getValues() {
        return values;
    }

    /**
     * Timestamp of the measurement in milliseconds
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get measurement timestamp
     * long time = measurement.getTime();
     * System.out.println("Measurement time: " + time + " ms");
     * }
     * </pre>
     * @return Timestamp of the measurement in milliseconds
     */
    public long getTime() {
        return time;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof SensorMeasurement)) {
            return false;
        }
        SensorMeasurement other = (SensorMeasurement) obj;
        return this.type == other.type &&
                this.values.equals(other.values) &&
                this.time == other.time;
    }

    @Override
    public int hashCode() {
        // Pick an arbitrary non-zero starting value
        int hashCode = 17;
        hashCode = hashCode * 31 + type.hashCode();
        hashCode = hashCode * 31 + values.hashCode();
        hashCode = hashCode * 31 + ((int) (time ^ (time >>> 32)));
        return hashCode;
    }

    @Override
    public String toString() {
        return "SensorMeasurement{" +
                "type=" + type +
                "," + "values=" + values +
                "," + "time=" + time +
        "}";
    }


    @Override
    public int compareTo(SensorMeasurement other)  {
        int tempResult;
        tempResult = this.type.compareTo(other.type);if (tempResult != 0) {
            return tempResult;
        }
        tempResult = this.values.compareTo(other.values);
        if (tempResult != 0) {
            return tempResult;
        }
        if (this.time < other.time) {
            tempResult = -1;
        } else if (this.time > other.time) {
            tempResult = 1;
        } else {
            tempResult = 0;
        }
        if (tempResult != 0) {
            return tempResult;
        }
        return 0;
    }
}
