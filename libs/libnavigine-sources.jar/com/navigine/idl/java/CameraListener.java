package com.navigine.idl.java;

/**
 * Class is used to listen for camera updates
 * Referenced from {@link com.navigine.idl.java.LocationWindow LocationWindow}.
 */
public abstract class CameraListener {
    /**
     * Triggered when the camera position changed.
     * If a movement is cancelled then reason represents initiator of cancellation.
     * @param reason reason of camera update.
     * @param finished true if the camera finished moving, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * @Override
     * public void onCameraPositionChanged(CameraUpdateReason reason, boolean finished) {
     *    String reasonText = (reason == CameraUpdateReason.GESTURES) ? "user gestures" : "application";
     *    String statusText = finished ? "finished" : "in progress";
     *    System.out.println("Camera position changed: " + reasonText + ", status: " + statusText);
     *    if (finished) {
     *        System.out.println("Camera movement completed");
     *    }
     * }
     * }
     * </pre>
     */
    public abstract void onCameraPositionChanged(CameraUpdateReason reason, boolean finished);
}
