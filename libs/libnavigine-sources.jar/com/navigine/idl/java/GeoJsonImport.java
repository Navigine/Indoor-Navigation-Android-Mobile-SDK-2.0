package com.navigine.idl.java;

import java.util.ArrayList;

/**
 * Polygons and polylines created from one GeoJSON document.
 * Points are not imported. The host styles and removes these objects itself.
 */
public abstract class GeoJsonImport {
    /**
     * Polygons from Polygon and MultiPolygon geometries.
     */
    public abstract ArrayList<PolygonMapObject> polygons();

    /**
     * Polylines from LineString and MultiLineString geometries.
     */
    public abstract ArrayList<PolylineMapObject> polylines();

    /**
     * Tells if this {@link GeoJsonImport} is valid or not. Any other method
     * (except for this one) called on an invalid {@link GeoJsonImport} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
