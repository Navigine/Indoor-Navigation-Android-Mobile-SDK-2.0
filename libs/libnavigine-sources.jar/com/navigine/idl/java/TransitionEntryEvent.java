package com.navigine.idl.java;

/**
 * Event describing entering another level/sublocation transition.
 * Referenced from {@link com.navigine.idl.java.RouteEvent RouteEvent}.
 */
public final class TransitionEntryEvent {


    /*package*/ final long from;

    /*package*/ final long to;

    /**
     * Default constructor for class TransitionEntryEvent
     */
    public TransitionEntryEvent(
            long from,
            long to) {
        this.from = from;
        this.to = to;
    }

    /**
     * Source level identifier.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * long from = event.getFrom();
     * System.out.println("Transition entry from: " + from);
     * }
     * </pre>
     * @return Source level identifier.
     */
    public long getFrom() {
        return from;
    }

    /**
     * Destination level identifier.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * long to = event.getTo();
     * System.out.println("Transition entry to: " + to);
     * }
     * </pre>
     * @return Destination level identifier.
     */
    public long getTo() {
        return to;
    }

    @Override
    public String toString() {
        return "TransitionEntryEvent{" +
                "from=" + from +
                "," + "to=" + to +
        "}";
    }

}
