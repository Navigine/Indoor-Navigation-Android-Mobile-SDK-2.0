package com.navigine.idl.java;

public final class RouteProgress {


    /*package*/ final GlobalPoint point;

    /*package*/ final Integer sublocationId;

    /*package*/ final float advance;

    /*package*/ final float remainingDistance;

    /*package*/ final float remainingTime;

    /*package*/ final int legIndex;

    /**
     * Default constructor for class RouteProgress
     */
    public RouteProgress(
            GlobalPoint point,
            Integer sublocationId,
            float advance,
            float remainingDistance,
            float remainingTime,
            int legIndex) {
        this.point = point;
        this.sublocationId = sublocationId;
        this.advance = advance;
        this.remainingDistance = remainingDistance;
        this.remainingTime = remainingTime;
        this.legIndex = legIndex;
    }

    public GlobalPoint getPoint() {
        return point;
    }

    public Integer getSublocationId() {
        return sublocationId;
    }

    public float getAdvance() {
        return advance;
    }

    public float getRemainingDistance() {
        return remainingDistance;
    }

    /**
     * Pedestrian ETA in seconds for the part of the route still ahead.
     * Outdoor legs use the OSRM duration scaled by the remaining fraction.
     * Indoor legs use a fixed walking speed (1.4 m/s). Not a traffic ETA.
     * @return Pedestrian ETA in seconds for the part of the route still ahead.
     */
    public float getRemainingTime() {
        return remainingTime;
    }

    public int getLegIndex() {
        return legIndex;
    }

    @Override
    public String toString() {
        return "RouteProgress{" +
                "point=" + point +
                "," + "sublocationId=" + sublocationId +
                "," + "advance=" + advance +
                "," + "remainingDistance=" + remainingDistance +
                "," + "remainingTime=" + remainingTime +
                "," + "legIndex=" + legIndex +
        "}";
    }

}
