package com.navigine.idl.java;

public final class RouteProgress {


    /*package*/ final GlobalPoint point;

    /*package*/ final Integer sublocationId;

    /*package*/ final float advance;

    /*package*/ final float remainingDistance;

    /*package*/ final int legIndex;

    /**
     * Default constructor for class RouteProgress
     */
    public RouteProgress(
            GlobalPoint point,
            Integer sublocationId,
            float advance,
            float remainingDistance,
            int legIndex) {
        this.point = point;
        this.sublocationId = sublocationId;
        this.advance = advance;
        this.remainingDistance = remainingDistance;
        this.legIndex = legIndex;
    }

    public GlobalPoint getPoint() {
        return point;
    }

    public Integer getSublocationId() {
        return sublocationId;
    }

    public float getAdvance() {
        return advance;
    }

    public float getRemainingDistance() {
        return remainingDistance;
    }

    public int getLegIndex() {
        return legIndex;
    }

    @Override
    public String toString() {
        return "RouteProgress{" +
                "point=" + point +
                "," + "sublocationId=" + sublocationId +
                "," + "advance=" + advance +
                "," + "remainingDistance=" + remainingDistance +
                "," + "legIndex=" + legIndex +
        "}";
    }

}
