package com.navigine.idl.java;

public final class RouteAnnotation {


    /*package*/ final RouteAnnotationType type;

    /*package*/ final GlobalPoint point;

    /*package*/ final Integer sublocationId;

    /*package*/ final float advance;

    /*package*/ final String title;

    /**
     * Default constructor for class RouteAnnotation
     */
    public RouteAnnotation(
            RouteAnnotationType type,
            GlobalPoint point,
            Integer sublocationId,
            float advance,
            String title) {
        this.type = type;
        this.point = point;
        this.sublocationId = sublocationId;
        this.advance = advance;
        this.title = title;
    }

    public RouteAnnotationType getType() {
        return type;
    }

    public GlobalPoint getPoint() {
        return point;
    }

    public Integer getSublocationId() {
        return sublocationId;
    }

    public float getAdvance() {
        return advance;
    }

    public String getTitle() {
        return title;
    }

    @Override
    public String toString() {
        return "RouteAnnotation{" +
                "type=" + type +
                "," + "point=" + point +
                "," + "sublocationId=" + sublocationId +
                "," + "advance=" + advance +
                "," + "title=" + title +
        "}";
    }

}
