package com.navigine.idl.java;

public final class BeaconProximityEntry {


    /*package*/ final int major;

    /*package*/ final int minor;

    /*package*/ final String uuid;

    /*package*/ final float rssi;

    /*package*/ final float frequency;

    /*package*/ final float quality;

    /*package*/ final Float distance;

    /**
     * Default constructor for class BeaconProximityEntry
     */
    public BeaconProximityEntry(
            int major,
            int minor,
            String uuid,
            float rssi,
            float frequency,
            float quality,
            Float distance) {
        this.major = major;
        this.minor = minor;
        this.uuid = uuid;
        this.rssi = rssi;
        this.frequency = frequency;
        this.quality = quality;
        this.distance = distance;
    }

    public int getMajor() {
        return major;
    }

    public int getMinor() {
        return minor;
    }

    public String getUuid() {
        return uuid;
    }

    public float getRssi() {
        return rssi;
    }

    public float getFrequency() {
        return frequency;
    }

    public float getQuality() {
        return quality;
    }

    public Float getDistance() {
        return distance;
    }

    @Override
    public String toString() {
        return "BeaconProximityEntry{" +
                "major=" + major +
                "," + "minor=" + minor +
                "," + "uuid=" + uuid +
                "," + "rssi=" + rssi +
                "," + "frequency=" + frequency +
                "," + "quality=" + quality +
                "," + "distance=" + distance +
        "}";
    }

}
