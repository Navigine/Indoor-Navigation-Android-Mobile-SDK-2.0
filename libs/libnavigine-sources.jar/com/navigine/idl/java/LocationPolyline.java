package com.navigine.idl.java;

/**
 * Class is used for representing certain polyline within the location {@link com.navigine.idl.java.Polyline Polyline}
 *
 * <p><b>Example:</b></p>
 * <pre>
 * {@code
 * List<Point> linePoints = Arrays.asList(new Point(0.0, 0.0), new Point(10.0, 10.0));
 * Polyline metricPolyline = new Polyline(linePoints);
 * LocationPolyline locationPolyline = new LocationPolyline(metricPolyline, 42, 7);
 * Polyline polylineBack = locationPolyline.getPolyline();
 * System.out.println("LocationPolyline: points " + polylineBack.getPoints().size());
 * }
 * </pre>
 */
public final class LocationPolyline {


    /*package*/ final Polyline polyline;

    /*package*/ final int locationId;

    /*package*/ final int sublocationId;

    /**
     * Default constructor for class LocationPolyline
     */
    public LocationPolyline(
            Polyline polyline,
            int locationId,
            int sublocationId) {
        this.polyline = polyline;
        this.locationId = locationId;
        this.sublocationId = sublocationId;
    }

    /**
     * Metrics polyline @see Polyline.
     * @return Metrics polyline @see Polyline.
     */
    public Polyline getPolyline() {
        return polyline;
    }

    /**
     * location polyline location identifier.
     * @return location polyline location identifier.
     */
    public int getLocationId() {
        return locationId;
    }

    /**
     * location polyline sublocation identifier.
     * @return location polyline sublocation identifier.
     */
    public int getSublocationId() {
        return sublocationId;
    }

    @Override
    public String toString() {
        return "LocationPolyline{" +
                "polyline=" + polyline +
                "," + "locationId=" + locationId +
                "," + "sublocationId=" + sublocationId +
        "}";
    }

}
