package com.navigine.idl.java;

import java.util.ArrayList;

/**
 * Polyline on the location view in WGS84 coordinates.
 *
 * <p><b>Example:</b></p>
 * <pre>
 * {@code
 * List<GlobalPoint> linePoints = Arrays.asList(
 *    new GlobalPoint(55.751, 37.617),
 *    new GlobalPoint(55.753, 37.620)
 * );
 * LocationPolyline locationPolyline = new LocationPolyline(linePoints, 7);
 * System.out.println("LocationPolyline: points " + locationPolyline.getPoints().size());
 * }
 * </pre>
 */
public final class LocationPolyline {


    /*package*/ final ArrayList<GlobalPoint> points;

    /*package*/ final Integer sublocationId;

    /**
     * Default constructor for class LocationPolyline
     */
    public LocationPolyline(
            ArrayList<GlobalPoint> points,
            Integer sublocationId) {
        this.points = points;
        this.sublocationId = sublocationId;
    }

    /**
     * Vertices in WGS84 {@link com.navigine.idl.java.GlobalPoint GlobalPoint}.
     * @return Vertices in WGS84 {@link GlobalPoint GlobalPoint}.
     */
    public ArrayList<GlobalPoint> getPoints() {
        return points;
    }

    /**
     * Floor this polyline is attached to, or null for the outdoor map.
     * @return Floor this polyline is attached to, or null for the outdoor map.
     */
    public Integer getSublocationId() {
        return sublocationId;
    }

    @Override
    public String toString() {
        return "LocationPolyline{" +
                "points=" + points +
                "," + "sublocationId=" + sublocationId +
        "}";
    }

}
