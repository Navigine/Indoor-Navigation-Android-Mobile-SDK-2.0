package com.navigine.idl.java;

/**
 * Rendering style for the remaining (not yet traveled) part of the route.
 * Referenced from {@link com.navigine.idl.java.RouteLayer RouteLayer}.
 */
public enum RouteRemainingStyle {
    /**
     * Continuous solid polyline.
     */
    SOLID,
    /**
     * Dashed polyline (see setRemainingDashLength / setRemainingGapLength).
     */
    DASHED,
    /**
     * Points placed along the route ({@link com.navigine.idl.java.DottedPolylineMapObject DottedPolylineMapObject}).
     */
    DOTTED,
    ;
}
