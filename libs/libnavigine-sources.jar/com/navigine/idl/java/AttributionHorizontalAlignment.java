package com.navigine.idl.java;

/**
 * Horizontal placement of the OSM attribution overlay.
 * Used with {@link com.navigine.idl.java.AttributionAlignment AttributionAlignment}.
 */
public enum AttributionHorizontalAlignment {
    /**
     * Align to the left edge of the map.
     */
    LEFT,
    /**
     * Center horizontally.
     */
    CENTER,
    /**
     * Align to the right edge of the map.
     */
    RIGHT,
    ;
}
