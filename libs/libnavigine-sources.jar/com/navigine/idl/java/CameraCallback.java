package com.navigine.idl.java;

/**
 * Callback specified after the camera movement is stopped
 * Referenced from: {@link com.navigine.idl.java.LocationWindow LocationWindow}.
 */
public abstract class CameraCallback {
    /**
     * Called when the move if finished.
     * @param completed determine whether the movement is finished or cancelled
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * @Override
     * public void onMoveFinished(boolean completed) {
     *    if (completed) {
     *        System.out.println("Camera movement completed successfully");
     *    } else {
     *        System.out.println("Camera movement was cancelled");
     *    }
     * }
     * }
     * </pre>
     */
    public abstract void onMoveFinished(boolean completed);
}
