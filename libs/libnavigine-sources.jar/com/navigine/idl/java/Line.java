package com.navigine.idl.java;

import java.util.ArrayList;

/**
 * A polyline with specified list of segments {@link com.navigine.idl.java.Segment Segment}
 * Referenced from {@link com.navigine.idl.java.PolylineMapObject PolylineMapObject}.
 */
public final class Line {


    /*package*/ final ArrayList<Segment> segments;

    /**
     * Default constructor for class Line
     */
    public Line(
            ArrayList<Segment> segments) {
        this.segments = segments;
    }

    /**
     * List of segments to connect.
     * @return List of segments to connect.
     */
    public ArrayList<Segment> getSegments() {
        return segments;
    }

    @Override
    public String toString() {
        return "Line{" +
                "segments=" + segments +
        "}";
    }

}
