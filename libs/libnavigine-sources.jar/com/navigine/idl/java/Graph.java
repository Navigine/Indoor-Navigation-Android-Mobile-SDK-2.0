package com.navigine.idl.java;

import java.util.ArrayList;

/**
 * Class is used for storing graph.
 * Referenced from {@link com.navigine.idl.java.Sublocation Sublocation}.
 */
public abstract class Graph {
    /**
     * List of connected vertexes {@link com.navigine.idl.java.GraphVertex GraphVertex}
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get graph vertices
     * java.util.ArrayList<GraphVertex> vertices = graph.getVertices();
     * System.out.println("Number of graph vertices: " + vertices.size());
     * }
     * </pre>
     * @return List of connected vertexes {@link GraphVertex GraphVertex}
     */
    public abstract ArrayList<GraphVertex> getVertexes();

    /**
     * List of edges that connected vertexes {@link com.navigine.idl.java.GraphEdge GraphEdge}
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get graph edges
     * java.util.ArrayList<GraphEdge> edges = graph.getEdges();
     * System.out.println("Number of graph edges: " + edges.size());
     * }
     * </pre>
     * @return List of edges that connected vertexes {@link GraphEdge GraphEdge}
     */
    public abstract ArrayList<GraphEdge> getEdges();

    /**
     * Tells if this {@link Graph} is valid or not. Any other method
     * (except for this one) called on an invalid {@link Graph} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
