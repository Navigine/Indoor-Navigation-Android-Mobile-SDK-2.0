package com.navigine.idl.java;

/**
 * Class is used to listen for interactions with location view
 * Referenced from {@link com.navigine.idl.java.LocationWindow LocationWindow}.
 */
public abstract class InputListener {
    /**
     * Called when a tap occurred.
     * @param screenPoint point in screen coordinates.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * @Override
     * public void onViewTap(Point screenPoint) {
     *    System.out.println("View tapped at screen position (" + screenPoint.x + ", " + screenPoint.y + ")");
     * }
     * }
     * </pre>
     */
    public abstract void onViewTap(android.graphics.PointF screenPoint);

    /**
     * Called when a double tap occurred.
     * @param screenPoint point in screen coordinates.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * @Override
     * public void onViewDoubleTap(Point screenPoint) {
     *    System.out.println("View double tapped at screen position (" + screenPoint.x + ", " + screenPoint.y + ")");
     * }
     * }
     * </pre>
     */
    public abstract void onViewDoubleTap(android.graphics.PointF screenPoint);

    /**
     * Called when a long tap occurred.
     * @param screenPoint point in screen coordinates.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * @Override
     * public void onViewLongTap(Point screenPoint) {
     *    System.out.println("View long tapped at screen position (" + screenPoint.x + ", " + screenPoint.y + ")");
     * }
     * }
     * </pre>
     */
    public abstract void onViewLongTap(android.graphics.PointF screenPoint);
}
