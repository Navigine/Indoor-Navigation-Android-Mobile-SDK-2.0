package com.navigine.idl.java;

/**
 * One arrow in a point batch. Heading is degrees clockwise from north.
 * {@code size} is pixels (the same unit as a symbol icon).
 */
public final class PointSprite {


    /*package*/ final GlobalPoint position;

    /*package*/ final float heading;

    /*package*/ final int color;

    /*package*/ final float size;

    /**
     * Default constructor for class PointSprite
     */
    public PointSprite(
            GlobalPoint position,
            float heading,
            int color,
            float size) {
        this.position = position;
        this.heading = heading;
        this.color = color;
        this.size = size;
    }

    public GlobalPoint getPosition() {
        return position;
    }

    /**
     * Degrees clockwise from north.
     * @return Degrees clockwise from north.
     */
    public float getHeading() {
        return heading;
    }

    public int getColor() {
        return color;
    }

    /**
     * Arrow length in pixels.
     * @return Arrow length in pixels.
     */
    public float getSize() {
        return size;
    }

    @Override
    public String toString() {
        return "PointSprite{" +
                "position=" + position +
                "," + "heading=" + heading +
                "," + "color=" + color +
                "," + "size=" + size +
        "}";
    }

}
