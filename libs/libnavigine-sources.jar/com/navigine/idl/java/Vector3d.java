package com.navigine.idl.java;

/**
 * Structure representing a 3D vector for sensor measurements.
 * Referenced from {@link com.navigine.idl.java.SensorMeasurement SensorMeasurement}.
 */
public final class Vector3d implements Comparable<Vector3d> {


    /*package*/ final float x;

    /*package*/ final float y;

    /*package*/ final float z;

    /**
     * Default constructor for class Vector3d
     */
    public Vector3d(
            float x,
            float y,
            float z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    /**
     * X-coordinate of the 3D vector
     * @return X-coordinate of the 3D vector
     */
    public float getX() {
        return x;
    }

    /**
     * Y-coordinate of the 3D vector
     * @return Y-coordinate of the 3D vector
     */
    public float getY() {
        return y;
    }

    /**
     * Z-coordinate of the 3D vector
     * @return Z-coordinate of the 3D vector
     */
    public float getZ() {
        return z;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Vector3d)) {
            return false;
        }
        Vector3d other = (Vector3d) obj;
        return this.x == other.x &&
                this.y == other.y &&
                this.z == other.z;
    }

    @Override
    public int hashCode() {
        // Pick an arbitrary non-zero starting value
        int hashCode = 17;
        hashCode = hashCode * 31 + Float.floatToIntBits(x);
        hashCode = hashCode * 31 + Float.floatToIntBits(y);
        hashCode = hashCode * 31 + Float.floatToIntBits(z);
        return hashCode;
    }

    @Override
    public String toString() {
        return "Vector3d{" +
                "x=" + x +
                "," + "y=" + y +
                "," + "z=" + z +
        "}";
    }


    @Override
    public int compareTo(Vector3d other)  {
        int tempResult;
        if (this.x < other.x) {
            tempResult = -1;
        } else if (this.x > other.x) {
            tempResult = 1;
        } else {
            tempResult = 0;
        }
        if (tempResult != 0) {
            return tempResult;
        }
        if (this.y < other.y) {
            tempResult = -1;
        } else if (this.y > other.y) {
            tempResult = 1;
        } else {
            tempResult = 0;
        }
        if (tempResult != 0) {
            return tempResult;
        }
        if (this.z < other.z) {
            tempResult = -1;
        } else if (this.z > other.z) {
            tempResult = 1;
        } else {
            tempResult = 0;
        }
        if (tempResult != 0) {
            return tempResult;
        }
        return 0;
    }
}
