package com.navigine.idl.java;

/**
 * Enum defining the placement mode for points along a polyline.
 * Referenced from {@link com.navigine.idl.java.DottedPolylineMapObject DottedPolylineMapObject}.
 */
public enum Placement {
    /**
     * Places points at each vertex of the polyline.
     */
    VERTEX,
    /**
     * Places points at the midpoint of each polyline segment.
     */
    MIDPOINT,
    /**
     * Places points at regular intervals along the polyline, controlled by spacing parameters.
     */
    SPACED,
    ;
}
