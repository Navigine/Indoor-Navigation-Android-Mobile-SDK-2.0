package com.navigine.idl.java;

public enum ReferenceEntryType {
    BEACON,
    WIFI,
    BLE,
    EDDYSTONE,
    MAGNET,
    ;
}
