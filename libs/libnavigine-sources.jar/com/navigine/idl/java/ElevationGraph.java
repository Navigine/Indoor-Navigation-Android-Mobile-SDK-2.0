package com.navigine.idl.java;

import java.util.ArrayList;

/**
 * Class describing a graph that connects the sublocations.
 * Referenced from {@link com.navigine.idl.java.Location Location}
 */
public abstract class ElevationGraph {
    /**
     * List of edges that connect two sublocations {@link com.navigine.idl.java.GraphEdge GraphEdge}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get elevation graph edges
     * java.util.ArrayList<GraphEdge> edges = elevationGraph.getEdges();
     * System.out.println("Number of elevation graph edges: " + edges.size());
     * // Demonstrate each edge
     * for (int i = 0; i < edges.size(); i++) {
     *    GraphEdge edge = edges.get(i);
     *    System.out.println("Elevation graph edge " + (i + 1) + ":");
     *    demonstrateGraphEdgeUsage(edge);
     * }
     * }
     * </pre>
     * @return List of edges that connect two sublocations {@link GraphEdge GraphEdge}.
     */
    public abstract ArrayList<GraphEdge> getEdges();

    /**
     * Tells if this {@link ElevationGraph} is valid or not. Any other method
     * (except for this one) called on an invalid {@link ElevationGraph} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
