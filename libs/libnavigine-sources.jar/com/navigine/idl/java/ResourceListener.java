package com.navigine.idl.java;

public abstract class ResourceListener {
    public abstract void onLoaded(String imageUrl, Image image);

    public abstract void onFailed(String imageUrl, java.lang.Error error);
}
