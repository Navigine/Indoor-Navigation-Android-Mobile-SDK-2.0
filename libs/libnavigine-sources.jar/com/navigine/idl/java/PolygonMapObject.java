package com.navigine.idl.java;

/**
 * Represents a polygon object on the location view.
 * Referenced from {@link com.navigine.idl.java.LocationWindow LocationWindow}.
 */
public abstract class PolygonMapObject extends MapObject {
    /**
     * Method is used to specify the source polygon of the object.
     * @param polygon Metrics coordinates of the polygon {@link com.navigine.idl.java.LocationPolygon LocationPolygon}.
     * @return true if success, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set polygon geometry
     * List<GlobalPoint> points = Arrays.asList(
     *    new GlobalPoint(100.0, 200.0),
     *    new GlobalPoint(150.0, 250.0),
     *    new GlobalPoint(200.0, 200.0),
     *    new GlobalPoint(150.0, 150.0)
     * );
     * LocationPolygon polygon = new LocationPolygon(points, 0);
     * boolean success = polygonMapObject.setPolygon(polygon);
     * System.out.println("Set polygon with " + points.size() + " points: " + success);
     * }
     * </pre>
     */
    public abstract boolean setPolygon(LocationPolygon polygon);

    /**
     * Method is used to specify the color of the object.
     * @param color Fill color.
     * @return true if success, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set polygon color
     * boolean colorSuccess = polygonMapObject.setColor(0xB300FF00);
     * System.out.println("Set polygon color to green with 70% opacity: " + colorSuccess);
     * }
     * </pre>
     */
    public abstract boolean setColor(int color);

    /**
     * Method is used to specify the rendering order of the object.
     * @param order The rendering order value. Default: 0.
     * @return true if success, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set polygon rendering order
     * boolean orderSuccess = polygonMapObject.setOrder(2);
     * System.out.println("Set polygon rendering order to 2: " + orderSuccess);
     * }
     * </pre>
     */
    public abstract boolean setOrder(int order);

    /**
     * Method is used to specify the color of the polygon’s outline.
     * @param color Outline color.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set polygon outline color
     * boolean outlineColorSuccess = polygonMapObject.setOutlineColor(0xFF0000FF);
     * System.out.println("Set polygon outline color to blue: " + outlineColorSuccess);
     * }
     * </pre>
     */
    public abstract boolean setOutlineColor(int color);

    /**
     * Method is used to specify the width of the polygon’s outline.
     * @param width Width of the outline in pixels.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set polygon outline width
     * boolean outlineWidthSuccess = polygonMapObject.setOutlineWidth(2.0);
     * System.out.println("Set polygon outline width to 2.0 pixels: " + outlineWidthSuccess);
     * }
     * </pre>
     */
    public abstract boolean setOutlineWidth(float width);

    /**
     * Method is used to specify the opacity of the polygon’s outline.
     * @param alpha Opacity multiplier (0 to 1). Values below 0 are set to 0. Default: 1.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set polygon outline alpha
     * boolean outlineAlphaSuccess = polygonMapObject.setOutlineAlpha(0.8);
     * System.out.println("Set polygon outline alpha to 0.8: " + outlineAlphaSuccess);
     * }
     * </pre>
     */
    public abstract boolean setOutlineAlpha(float alpha);

    /**
     * Method is used to specify the rendering order of the polygon’s outline.
     * @param order The rendering order value. Default: 0.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set polygon outline order
     * boolean outlineOrderSuccess = polygonMapObject.setOutlineOrder(1);
     * System.out.println("Set polygon outline order to 1: " + outlineOrderSuccess);
     * }
     * </pre>
     */
    public abstract boolean setOutlineOrder(int order);

    /**
     * Tells if this {@link PolygonMapObject} is valid or not. Any other method
     * (except for this one) called on an invalid {@link PolygonMapObject} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
