package com.navigine.idl.java;

/**
 * Represents a polygon object on the location view.
 * Referenced from {@link com.navigine.idl.java.LocationWindow LocationWindow}.
 */
public abstract class PolygonMapObject extends MapObject {
    /**
     * Method is used to specify the source polygon of the object.
     * @param polygon Metrics coordinates of the polygon {@link com.navigine.idl.java.LocationPolygon LocationPolygon}.
     * @return true if success, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set polygon geometry
     * List<Point> points = Arrays.asList(
     *    new Point(100.0, 200.0),
     *    new Point(150.0, 250.0),
     *    new Point(200.0, 200.0),
     *    new Point(150.0, 150.0)
     * );
     * Polygon metricPolygon = new Polygon(points);
     * LocationPolygon polygon = new LocationPolygon(metricPolygon, 1, 0);
     * boolean success = polygonMapObject.setPolygon(polygon);
     * System.out.println("Set polygon with " + points.size() + " points: " + success);
     * }
     * </pre>
     */
    public abstract boolean setPolygon(LocationPolygon polygon);

    /**
     * Method is used to specify the color of the object.
     * @param red Red RGBA component.
     * @param green Green RGBA component.
     * @param blue Blue RGBA component.
     * @param alpha Opacity multiplier. Values below 0 will be set to 0. Default: 1.
     * @return true if success, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set polygon color
     * boolean colorSuccess = polygonMapObject.setColor(0.0, 1.0, 0.0, 0.7);
     * System.out.println("Set polygon color to green with 70% opacity: " + colorSuccess);
     * }
     * </pre>
     */
    public abstract boolean setColor(float red, float green, float blue, float alpha);

    /**
     * Method is used to specify the rendering order of the object.
     * @param order The rendering order value. Default: 0.
     * @return true if success, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set polygon rendering order
     * boolean orderSuccess = polygonMapObject.setOrder(2);
     * System.out.println("Set polygon rendering order to 2: " + orderSuccess);
     * }
     * </pre>
     */
    public abstract boolean setOrder(int order);

    /**
     * Tells if this {@link PolygonMapObject} is valid or not. Any other method
     * (except for this one) called on an invalid {@link PolygonMapObject} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
