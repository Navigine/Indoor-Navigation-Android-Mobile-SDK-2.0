package com.navigine.idl.java;

/**
 * Class is used to handle information in {@link com.navigine.idl.java.PickListener PickListener}.
 * Referenced from {@link com.navigine.idl.java.PickListener PickListener}.
 */
public abstract class MapObjectPickResult {
    /**
     * WGS84 location of the picked map object {@link com.navigine.idl.java.GlobalPoint GlobalPoint}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * LocationPoint point = mapObjectPickResult.getPoint();
     * System.out.println("Map object picked at screen position (" + screenPosition.x + ", " + screenPosition.y + ")");
     * System.out.println("  Object location: (" + point.getX() + ", " + point.getY() + ")");
     * }
     * </pre>
     * @return WGS84 location of the picked map object {@link GlobalPoint GlobalPoint}.
     */
    public abstract GlobalPoint getPoint();

    /**
     * Floor the picked object is attached to, or null for the outdoor map.
     * @return Floor the picked object is attached to, or null for the outdoor map.
     */
    public abstract Integer getSublocationId();

    /**
     * Picked map object {@link com.navigine.idl.java.MapObject MapObject}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * MapObject mapObject = mapObjectPickResult.getMapObject();
     * System.out.println("  Object type: " + mapObject.getClass().getSimpleName());
     * }
     * </pre>
     * @return Picked map object {@link MapObject MapObject}.
     */
    public abstract MapObject getMapObject();
}
