package com.navigine.idl.java;

/**
 * Class is used to handle information in {@link com.navigine.idl.java.PickListener PickListener}.
 * Referenced from {@link com.navigine.idl.java.PickListener PickListener}.
 */
public abstract class MapObjectPickResult {
    /**
     * Location of the picked map object {@link com.navigine.idl.java.LocationPoint LocationPoint}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * LocationPoint point = mapObjectPickResult.getPoint();
     * System.out.println("Map object picked at screen position (" + screenPosition.x + ", " + screenPosition.y + ")");
     * System.out.println("  Object location: (" + point.getX() + ", " + point.getY() + ")");
     * }
     * </pre>
     * @return Location of the picked map object {@link LocationPoint LocationPoint}.
     */
    public abstract LocationPoint getPoint();

    /**
     * Picked map object {@link com.navigine.idl.java.MapObject MapObject}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * MapObject mapObject = mapObjectPickResult.getMapObject();
     * System.out.println("  Object type: " + mapObject.getClass().getSimpleName());
     * }
     * </pre>
     * @return Picked map object {@link MapObject MapObject}.
     */
    public abstract MapObject getMapObject();
}
