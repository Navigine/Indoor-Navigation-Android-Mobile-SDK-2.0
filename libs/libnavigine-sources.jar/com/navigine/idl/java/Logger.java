package com.navigine.idl.java;

import com.navigine.platform.NativeObject;
import com.navigine.platform.Subscription;

public abstract class Logger {
    public abstract void subscribe(LogListener listener);

    public abstract void unsubscribe(LogListener listener);

    /**
     * Tells if this {@link Logger} is valid or not. Any other method
     * (except for this one) called on an invalid {@link Logger} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();

    public static Logger getLogger()
    {
        return com.navigine.idl.java.internal.LoggerBinding.getLogger();
    }
}
