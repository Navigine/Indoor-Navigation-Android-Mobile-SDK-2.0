package com.navigine.idl.java;

/**
 * Style parameters for a map object title.
 * Used with {@link com.navigine.idl.java.MapObject MapObject} {@code setTitleWithStyle}.
 */
public final class TitleStyle {


    /*package*/ final float fontSize;

    /*package*/ final int color;

    /*package*/ final int outlineColor;

    /*package*/ final float outlineWidth;

    /*package*/ final TitleAnchor anchor;

    /*package*/ final boolean visible;

    /**
     * Default constructor for class TitleStyle
     */
    public TitleStyle(
            float fontSize,
            int color,
            int outlineColor,
            float outlineWidth,
            TitleAnchor anchor,
            boolean visible) {
        this.fontSize = fontSize;
        this.color = color;
        this.outlineColor = outlineColor;
        this.outlineWidth = outlineWidth;
        this.anchor = anchor;
        this.visible = visible;
    }

    /**
     * Default constructor for class TitleStyle
     */
    public TitleStyle() {
        this(12, 0xFF000000, 0xFFFFFFFF, 2, TitleAnchor.CENTER, true);
    }

    /**
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * TitleStyle titleStyle = new TitleStyle();
     * titleStyle.fontSize = 14f;
     * titleStyle.color = 0xFF3366CC;
     * titleStyle.outlineColor = 0xFFFFFFFF;
     * titleStyle.anchor = TitleAnchor.TOP;
     * titleStyle.visible = true;
     * }
     * </pre>
     * Font size in pixels.
     * @return <java>
     */
    public float getFontSize() {
        return fontSize;
    }

    /**
     * Title fill color.
     * @return Title fill color.
     */
    public int getColor() {
        return color;
    }

    /**
     * Title outline (halo) color.
     * @return Title outline (halo) color.
     */
    public int getOutlineColor() {
        return outlineColor;
    }

    /**
     * Title outline (halo) width in pixels.
     * @return Title outline (halo) width in pixels.
     */
    public float getOutlineWidth() {
        return outlineWidth;
    }

    /**
     * Title anchor relative to the placement point {@link com.navigine.idl.java.TitleAnchor TitleAnchor}.
     * @return Title anchor relative to the placement point {@link TitleAnchor TitleAnchor}.
     */
    public TitleAnchor getAnchor() {
        return anchor;
    }

    /**
     * Whether the title is visible.
     * @return Whether the title is visible.
     */
    public boolean getVisible() {
        return visible;
    }

    @Override
    public String toString() {
        return "TitleStyle{" +
                "fontSize=" + fontSize +
                "," + "color=" + color +
                "," + "outlineColor=" + outlineColor +
                "," + "outlineWidth=" + outlineWidth +
                "," + "anchor=" + anchor +
                "," + "visible=" + visible +
        "}";
    }

}
