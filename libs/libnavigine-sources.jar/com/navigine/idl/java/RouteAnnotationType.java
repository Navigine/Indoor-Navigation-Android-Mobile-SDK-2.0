package com.navigine.idl.java;

public enum RouteAnnotationType {
    START,
    FINISH,
    TRANSITION,
    MANEUVER,
    WARNING,
    ;
}
