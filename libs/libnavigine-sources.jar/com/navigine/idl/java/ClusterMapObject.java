package com.navigine.idl.java;

import com.navigine.common.NativeObject;
import com.navigine.common.Subscription;
import java.util.ArrayList;

/**
 * Runtime snapshot of a visible icon cluster on the location view.
 * Created and updated by {@link com.navigine.idl.java.ClusterMapObjectController ClusterMapObjectController}.
 * Member {@link com.navigine.idl.java.IconMapObject IconMapObject} instances are hidden while grouped; the cluster marker is shown instead.
 * <p><b>Note:</b> Position and membership are managed by the controller and cannot be changed through this interface.</p>
 * Use {@link com.navigine.idl.java.ClusterMapObjectListener ClusterMapObjectListener} ({@code onClusterChanged}) to refresh a custom cluster bitmap when the member count changes.
 */
public abstract class ClusterMapObject extends MapObject {
    /**
     * Method is used to specify the decoded raster for the cluster marker.
     * @param bitmap Image provider: Android com.navigine.image.ImageProvider; iOS UIImage via binding; Flutter navigine_sdk ImageProvider.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * ImageProvider clusterBitmap = ImageProvider.fromFile("/path/to/cluster.png", true);
     * boolean bitmapSuccess = cluster.setBitmap(clusterBitmap);
     * System.out.println("Set cluster bitmap from ImageProvider: " + bitmapSuccess);
     * }
     * </pre>
     */
    public abstract boolean setBitmap(com.navigine.image.ImageProvider bitmap);

    /**
     * Adds a listener for cluster state updates {@link com.navigine.idl.java.ClusterMapObjectListener ClusterMapObjectListener}.
     * @param listener Listener instance.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * cluster.addListener(clusterChangeListener);
     * System.out.println("Added cluster change listener, initial count: " + cluster.getCount());
     * }
     * </pre>
     */
    public abstract void addListener(ClusterMapObjectListener listener);

    /**
     * Removes a previously added listener.
     * @param listener Listener instance to remove.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * activeCluster.removeListener(clusterChangeListener);
     * System.out.println("Removed cluster change listener");
     * }
     * </pre>
     */
    public abstract void removeListener(ClusterMapObjectListener listener);

    /**
     * Cluster center in metrics coordinates.
     * @return Cluster center in metrics coordinates.
     */
    public abstract LocationPoint getPosition();

    /**
     * Number of icon map objects in the cluster (at least 2 while the cluster is visible).
     * @return Number of icon map objects in the cluster (at least 2 while the cluster is visible).
     */
    public abstract int getCount();

    /**
     * Icon map objects currently grouped into this cluster.
     * @return Icon map objects currently grouped into this cluster.
     */
    public abstract ArrayList<IconMapObject> getIconMapObjects();

    /**
     * Tells if this {@link ClusterMapObject} is valid or not. Any other method
     * (except for this one) called on an invalid {@link ClusterMapObject} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
