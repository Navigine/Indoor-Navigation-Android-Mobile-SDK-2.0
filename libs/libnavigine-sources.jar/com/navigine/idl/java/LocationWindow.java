package com.navigine.idl.java;

import com.navigine.platform.NativeObject;
import com.navigine.platform.Subscription;
import java.util.ArrayList;

/**
 * Interface for interacting with the location view.
 * Referenced from {@link com.navigine.view.LocationView LocationView}.
 */
public abstract class LocationWindow {
    /**
     * Method is used to switch the location view between sublocations (e.g., floors).
     * @param id Sublocation unique identifier {@link com.navigine.idl.java.Sublocation Sublocation}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set sublocation ID to switch between floors
     * locationWindow.setSublocationId(1);
     * System.out.println("Set sublocation ID to 1 (first floor)");
     * }
     * </pre>
     */
    public abstract void setSublocationId(int id);

    /**
     * Returns current sublocation ID if set, otherwise null.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * Integer currentId = locationWindow.getSublocationId();
     * if (currentId != null) {
     *    System.out.println("Current sublocation id: " + currentId);
     * } else {
     *    System.out.println("Current sublocation id is not set");
     * }
     * }
     * </pre>
     */
    public abstract Integer getSublocationId();

    /**
     * Calculates camera that fits provided bounding box.
     * @param boundingBox Metrics bounding box to enclose.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * BoundingBox boundingBox = new BoundingBox(new Point(0.0, 0.0), new Point(20.0, 30.0));
     * Camera camera = locationWindow.getEnclosingCamera(boundingBox);
     * System.out.println("Camera that fits bounding box: " + camera);
     * }
     * </pre>
     */
    public abstract Camera getEnclosingCamera(BoundingBox boundingBox);

    /**
     * Converts screen coordinates (pixels) to metrics coordinates (meters).
     * @param point (x,y) coordinates in screen pixels.
     * @return (x,y) coordinates in meters {@link com.navigine.idl.java.Point Point}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Convert screen position to meters
     * Point screenPoint = new Point(100.0, 200.0);
     * Point metersPoint = locationWindow.screenPositionToMeters(screenPoint);
     * System.out.printf("Screen position (%.1f, %.1f) converted to meters: (%.1f, %.1f)%n",
     *                 screenPoint.getX(), screenPoint.getY(), metersPoint.getX(), metersPoint.getY());
     * }
     * </pre>
     */
    public abstract Point screenPositionToMeters(android.graphics.PointF point);

    /**
     * Converts metrics coordinates (meters) to screen coordinates (pixels).
     * @param point (x,y) coordinates in meters {@link com.navigine.idl.java.Point Point}.
     * @param clipToViewport If true, coordinates outside the viewport are clipped to the viewport edge.
     * @return (x,y) coordinates in screen pixels.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Convert meters to screen position with clipping
     * Point metersPoint3 = new Point(50.0, 75.0);
     * Point screenPoint3 = locationWindow.metersToScreenPosition(metersPoint3, true);
     * System.out.printf("Meters position (%.1f, %.1f) converted to screen with clipping: (%.1f, %.1f)%n",
     *                 metersPoint3.getX(), metersPoint3.getY(), screenPoint3.getX(), screenPoint3.getY());
     * }
     * </pre>
     */
    public abstract android.graphics.PointF metersToScreenPosition(Point point, boolean clipToViewport);

    /**
     * Creates and adds a circle map object to the location view.
     * @return A CircleMapObject instance {@link com.navigine.idl.java.CircleMapObject CircleMapObject} if successful, null otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Add circle map object
     * circleMapObject = locationWindow.addCircleMapObject();
     * System.out.println("Added circle map object");
     * }
     * </pre>
     */
    public abstract CircleMapObject addCircleMapObject();

    /**
     * Removes a circle map object from the location view.
     * @param circleMapObject The circle map object instance {@link com.navigine.idl.java.CircleMapObject CircleMapObject}.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove circle map object
     * if (circleMapObject != null) {
     *    boolean removed = locationWindow.removeCircleMapObject(circleMapObject);
     *    System.out.println("Removed circle map object: " + removed);
     *    circleMapObject = null;
     * }
     * }
     * </pre>
     */
    public abstract boolean removeCircleMapObject(CircleMapObject circleMapObject);

    /**
     * Creates and adds an icon map object to the location view.
     * @return An IconMapObject instance {@link com.navigine.idl.java.IconMapObject IconMapObject} if successful, null otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Add icon map object
     * iconMapObject = locationWindow.addIconMapObject();
     * System.out.println("Added icon map object");
     * }
     * </pre>
     */
    public abstract IconMapObject addIconMapObject();

    /**
     * Removes an icon map object from the location view.
     * @param iconMapObject The icon map object instance {@link com.navigine.idl.java.IconMapObject IconMapObject}.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove icon map object
     * if (iconMapObject != null) {
     *    boolean removed = locationWindow.removeIconMapObject(iconMapObject);
     *    System.out.println("Removed icon map object: " + removed);
     *    iconMapObject = null;
     * }
     * }
     * </pre>
     */
    public abstract boolean removeIconMapObject(IconMapObject iconMapObject);

    /**
     * Creates an icon map object controller for the location view.
     * @return Cluster controller instance {@link com.navigine.idl.java.ClusterMapObjectController ClusterMapObjectController}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * clusterMapObjectController = locationWindow.addClusterMapObjectController();
     * System.out.println("Added cluster map object controller");
     * }
     * </pre>
     */
    public abstract ClusterMapObjectController addClusterMapObjectController();

    /**
     * Removes an icon map object controller from the location view.
     * @param controller The controller instance to remove.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * boolean controllerRemoved =
     *    locationWindow.removeClusterMapObjectController(clusterMapObjectController);
     * System.out.println("Removed cluster map object controller: " + controllerRemoved);
     * }
     * </pre>
     */
    public abstract boolean removeClusterMapObjectController(ClusterMapObjectController controller);

    /**
     * Creates and adds a polygon map object to the location view.
     * @return A PolygonMapObject instance {@link com.navigine.idl.java.PolygonMapObject PolygonMapObject} if successful, null otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Add polygon map object
     * polygonMapObject = locationWindow.addPolygonMapObject();
     * System.out.println("Added polygon map object");
     * }
     * </pre>
     */
    public abstract PolygonMapObject addPolygonMapObject();

    /**
     * Removes a polygon map object from the location view.
     * @param polygonMapObject The polygon map object instance {@link com.navigine.idl.java.PolygonMapObject PolygonMapObject}.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove polygon map object
     * if (polygonMapObject != null) {
     *    boolean removed = locationWindow.removePolygonMapObject(polygonMapObject);
     *    System.out.println("Removed polygon map object: " + removed);
     *    polygonMapObject = null;
     * }
     * }
     * </pre>
     */
    public abstract boolean removePolygonMapObject(PolygonMapObject polygonMapObject);

    /**
     * Creates and adds a polyline map object to the location view.
     * @return A PolylineMapObject instance {@link com.navigine.idl.java.PolylineMapObject PolylineMapObject} if successful, null otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Add polyline map object
     * polylineMapObject = locationWindow.addPolylineMapObject();
     * System.out.println("Added polyline map object");
     * }
     * </pre>
     */
    public abstract PolylineMapObject addPolylineMapObject();

    /**
     * Removes a polyline map object from the location view.
     * @param polylineMapObject The polyline map object instance {@link com.navigine.idl.java.PolylineMapObject PolylineMapObject}.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove polyline map object
     * if (polylineMapObject != null) {
     *    boolean removed = locationWindow.removePolylineMapObject(polylineMapObject);
     *    System.out.println("Removed polyline map object: " + removed);
     *    polylineMapObject = null;
     * }
     * }
     * </pre>
     */
    public abstract boolean removePolylineMapObject(PolylineMapObject polylineMapObject);

    /**
     * Creates and adds a polyline points map object to the location view.
     * @return A DottedPolylineMapObject instance {@link com.navigine.idl.java.DottedPolylineMapObject DottedPolylineMapObject} if successful, null otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Add dotted polyline map object
     * dottedPolylineMapObject = locationWindow.addDottedPolylineMapObject();
     * System.out.println("Added dotted polyline map object");
     * }
     * </pre>
     */
    public abstract DottedPolylineMapObject addDottedPolylineMapObject();

    /**
     * Removes a polyline points map object from the location view.
     * @param dottedPolylineMapObject The polyline points map object instance {@link com.navigine.idl.java.DottedPolylineMapObject DottedPolylineMapObject}.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove dotted polyline map object
     * if (dottedPolylineMapObject != null) {
     *    boolean removed = locationWindow.removeDottedPolylineMapObject(dottedPolylineMapObject);
     *    System.out.println("Removed dotted polyline map object: " + removed);
     *    dottedPolylineMapObject = null;
     * }
     * }
     * </pre>
     */
    public abstract boolean removeDottedPolylineMapObject(DottedPolylineMapObject dottedPolylineMapObject);

    /**
     * Creates and adds a 3D model map object (Wavefront OBJ + texture via ModelProvider).
     * @return A ModelMapObject instance {@link com.navigine.idl.java.ModelMapObject ModelMapObject} if successful, null otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * modelMapObject = locationWindow.addModelMapObject();
     * System.out.println("Added model map object: " + (modelMapObject != null));
     * }
     * </pre>
     */
    public abstract ModelMapObject addModelMapObject();

    /**
     * Removes a model map object from the location view.
     * @param modelMapObject The model instance to remove {@link com.navigine.idl.java.ModelMapObject ModelMapObject}.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * boolean removed = locationWindow.removeModelMapObject(modelMapObject);
     * System.out.println("Removed model map object: " + removed);
     * modelMapObject = null;
     * }
     * </pre>
     */
    public abstract boolean removeModelMapObject(ModelMapObject modelMapObject);

    /**
     * Removes all map objects from the location view.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove all map objects
     * locationWindow.removeAllMapObjects();
     * System.out.println("Removed all map objects");
     * }
     * </pre>
     */
    public abstract void removeAllMapObjects();

    /**
     * Selects a visible, interactive map object at the specified screen position.
     * Results are delivered to the PickListener via onMapObjectPickComplete {@link com.navigine.idl.java.PickListener PickListener}.
     * @param point Position in screen pixels to pick from.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Pick map object at screen position
     * Point screenPoint = new Point(100.0, 200.0);
     * locationWindow.pickMapObjectAt(screenPoint);
     * System.out.println("Picked map object at screen position (" + screenPoint.x + ", " + screenPoint.y + ")");
     * }
     * </pre>
     */
    public abstract void pickMapObjectAt(android.graphics.PointF point);

    /**
     * Selects visible map features (e.g., venues) at the specified screen position.
     * Results are delivered to the PickListener via onMapFeaturePickComplete {@link com.navigine.idl.java.PickListener PickListener}.
     * @param point Position in screen pixels to pick from.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Pick map feature at screen position
     * Point featurePoint = new Point(150.0, 250.0);
     * locationWindow.pickMapFeatureAt(featurePoint);
     * System.out.println("Picked map feature at screen position (" + featurePoint.x + ", " + featurePoint.y + ")");
     * }
     * </pre>
     */
    public abstract void pickMapFeatureAt(android.graphics.PointF point);

    /**
     * Adds a PickListener to receive picking result events.
     * <p><b>Note:</b> Remove the listener when no longer needed.</p>
     * @param listener The PickListener instance {@link com.navigine.idl.java.PickListener PickListener}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Add pick listener
     * pickListener = new PickListenerImpl();
     * locationWindow.addPickListener(pickListener);
     * System.out.println("Added pick listener");
     * }
     * </pre>
     */
    public abstract void addPickListener(PickListener listener);

    /**
     * Removes a previously added PickListener.
     * @param listener The PickListener instance to remove {@link com.navigine.idl.java.PickListener PickListener}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * locationWindow.removePickListener(listeners[i]);
     * System.out.println("Removed pick listener " + i);
     * }
     * </pre>
     */
    public abstract void removePickListener(PickListener listener);

    /**
     * Adds an InputListener to receive input events.
     * <p><b>Note:</b> Remove the listener when no longer needed.</p>
     * @param listener The InputListener instance {@link com.navigine.idl.java.InputListener InputListener}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Add input listener
     * inputListener = new InputListenerImpl();
     * locationWindow.addInputListener(inputListener);
     * System.out.println("Added input listener");
     * }
     * </pre>
     */
    public abstract void addInputListener(InputListener listener);

    /**
     * Removes a previously added InputListener.
     * @param listener The InputListener instance to remove {@link com.navigine.idl.java.InputListener InputListener}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove input listener
     * locationWindow.removeInputListener(inputListener);
     * inputListener = null;
     * System.out.println("Removed input listener");
     * }
     * </pre>
     */
    public abstract void removeInputListener(InputListener listener);

    /**
     * Adds a CameraListener to receive camera movement events.
     * <p><b>Note:</b> Remove the listener when no longer needed.</p>
     * @param listener The CameraListener instance {@link com.navigine.idl.java.CameraListener CameraListener}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Add camera listener
     * cameraListener = new CameraListenerImpl();
     * locationWindow.addCameraListener(cameraListener);
     * System.out.println("Added camera listener");
     * }
     * </pre>
     */
    public abstract void addCameraListener(CameraListener listener);

    /**
     * Removes a previously added CameraListener.
     * @param listener The CameraListener instance to remove {@link com.navigine.idl.java.CameraListener CameraListener}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove camera listener
     * locationWindow.removeCameraListener(cameraListener);
     * cameraListener = null;
     * System.out.println("Removed camera listener");
     * }
     * </pre>
     */
    public abstract void removeCameraListener(CameraListener listener);

    /**
     * Adds listener for sublocation change events.
     * @param listener Sublocation change listener {@link com.navigine.idl.java.SublocationChangeListener SublocationChangeListener}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * locationWindow.addSublocationChangeListener(listener);
     * System.out.println("Added sublocation change listener");
     * }
     * </pre>
     */
    public abstract void addSublocationChangeListener(SublocationChangeListener listener);

    /**
     * Removes previously added sublocation change listener.
     * @param listener Listener instance to remove {@link com.navigine.idl.java.SublocationChangeListener SublocationChangeListener}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * locationWindow.removeSublocationChangeListener(listener);
     * System.out.println("Removed sublocation change listener");
     * }
     * </pre>
     */
    public abstract void removeSublocationChangeListener(SublocationChangeListener listener);

    /**
     * Adds listener for outdoor scenario: when camera focuses on a building or leaves it.
     * @param listener Indoor building listener {@link com.navigine.idl.java.BuildingListener BuildingListener}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * locationWindow.addBuildingListener(buildingListener);
     * System.out.println("Added building listener");
     * }
     * </pre>
     */
    public abstract void addBuildingListener(BuildingListener listener);

    /**
     * Removes previously added indoor building listener.
     * @param listener Listener instance to remove {@link com.navigine.idl.java.BuildingListener BuildingListener}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * locationWindow.removeBuildingListener(buildingListener);
     * System.out.println("Removed building listener");
     * }
     * </pre>
     */
    public abstract void removeBuildingListener(BuildingListener listener);

    /**
     * Moves the map camera to a new position with an easing animation.
     * @param camera The new camera position {@link com.navigine.idl.java.Camera Camera}.
     * @param duration Animation duration in milliseconds.
     * @param callback Callback to execute when the animation completes {@link com.navigine.idl.java.CameraCallback CameraCallback}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Fly to position with smooth animation
     * Point targetPoint = new Point(150.0, 250.0);
     * Camera targetCamera = new Camera(targetPoint, 75.0, 45.0, 30.0);
     * CameraCallback callback = new CameraCallbackImpl();
     * locationWindow.flyTo(targetCamera, 2000, callback);
     * System.out.println("Started fly to animation to point (" + targetPoint.x + ", " + targetPoint.y + ")");
     * }
     * </pre>
     */
    public abstract void flyTo(Camera camera, int duration, CameraCallback callback);

    /**
     * Moves the map camera to a new position with a smooth pan-and-zoom animation.
     * @param camera The new camera position {@link com.navigine.idl.java.Camera Camera}.
     * @param duration Animation duration in milliseconds (-1 for default duration).
     * @param animationType The type of easing animation {@link com.navigine.idl.java.AnimationType AnimationType}.
     * @param callback Callback to execute when the animation completes {@link com.navigine.idl.java.CameraCallback CameraCallback}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Move to position with linear animation
     * Point targetPoint = new Point(200.0, 300.0);
     * Camera targetCamera = new Camera(targetPoint, 100.0, 90.0, 0.0);
     * CameraCallback callback = new CameraCallbackImpl();
     * locationWindow.moveTo(targetCamera, 1500, AnimationType.LINEAR, callback);
     * System.out.println("Started move to with linear animation");
     * }
     * </pre>
     */
    public abstract void moveTo(Camera camera, int duration, AnimationType animationType, CameraCallback callback);

    /**
     * Selects a map feature by its feature ID.
     * @param featureId The feature ID from the mapFeaturePickResult {@link com.navigine.idl.java.PickListener PickListener}.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Select map feature by ID
     * String featureId = "room_101";
     * boolean selected = locationWindow.selectMapFeature(featureId);
     * System.out.println("Selected map feature " + featureId + ": " + selected);
     * }
     * </pre>
     */
    public abstract boolean selectMapFeature(String featureId);

    /**
     * Deselects a map feature by its feature ID.
     * @param featureId The feature ID from the mapFeaturePickResult {@link com.navigine.idl.java.PickListener PickListener}.
     * @return true if the operation is successful, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Deselect specific map feature
     * boolean deselected = locationWindow.deselectMapFeature(featureId);
     * System.out.println("Deselected map feature " + featureId + ": " + deselected);
     * }
     * </pre>
     */
    public abstract boolean deselectMapFeature(String featureId);

    /**
     * Deselects all currently selected map features.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Deselect all map features
     * locationWindow.deselectAllMapFeatures();
     * System.out.println("Deselected all map features");
     * }
     * </pre>
     */
    public abstract void deselectAllMapFeatures();

    /**
     * Applies a typed filter to a specific map layer.
     * @param layer The map layer to apply the filter to.
     * @param conditions List of conditions (property + allowed values). Empty list resets the filter (show all).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Apply filter to venues layer
     * List<MapFilterCondition> conditions = new ArrayList<>();
     * conditions.add(new MapFilterCondition("category", Arrays.asList("Toilet", "Cafe")));
     * locationWindow.applyLayerFilter("venues", conditions);
     * System.out.println("Applied layer filter: show venues with category Toilet or Cafe");
     * }
     * </pre>
     */
    public abstract void applyLayerFilter(String layer, ArrayList<MapFilterCondition> conditions);

    /**
     * Specifies the zoom level of the location view, in pixels per meter.
     * Default: approximately 100 meters across the screen width.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set zoom factor
     * locationWindow.setZoomFactor(150.0);
     * System.out.println("Set zoom factor to 150.0");
     * }
     * </pre>
     * @return Specifies the zoom level of the location view, in pixels per meter.
     */
    public abstract float getZoomFactor();

    /**
     * Specifies the zoom level of the location view, in pixels per meter.
     * Default: approximately 100 meters across the screen width.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set zoom factor
     * locationWindow.setZoomFactor(150.0);
     * System.out.println("Set zoom factor to 150.0");
     * }
     * </pre>
     * @param newZoomFactor Specifies the zoom level of the location view, in pixels per meter.
     */
    public abstract void setZoomFactor(float newZoomFactor);

    /**
     * Minimum zoom level for the location view (pixels per meter).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set minimum zoom factor
     * locationWindow.setMinZoomFactor(50.0);
     * System.out.println("Set minimum zoom factor to 50.0");
     * }
     * </pre>
     * @return Minimum zoom level for the location view (pixels per meter).
     */
    public abstract float getMinZoomFactor();

    /**
     * Minimum zoom level for the location view (pixels per meter).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set minimum zoom factor
     * locationWindow.setMinZoomFactor(50.0);
     * System.out.println("Set minimum zoom factor to 50.0");
     * }
     * </pre>
     * @param newMinZoomFactor Minimum zoom level for the location view (pixels per meter).
     */
    public abstract void setMinZoomFactor(float newMinZoomFactor);

    /**
     * Maximum zoom level for the location view (pixels per meter).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set maximum zoom factor
     * locationWindow.setMaxZoomFactor(300.0);
     * System.out.println("Set maximum zoom factor to 300.0");
     * }
     * </pre>
     * @return Maximum zoom level for the location view (pixels per meter).
     */
    public abstract float getMaxZoomFactor();

    /**
     * Maximum zoom level for the location view (pixels per meter).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set maximum zoom factor
     * locationWindow.setMaxZoomFactor(300.0);
     * System.out.println("Set maximum zoom factor to 300.0");
     * }
     * </pre>
     * @param newMaxZoomFactor Maximum zoom level for the location view (pixels per meter).
     */
    public abstract void setMaxZoomFactor(float newMaxZoomFactor);

    /**
     * Specifies whether sublocation content sticks to screen borders.
     * If true, content sticks to screen bounds; if false, content is centered. Default: true.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set stick to border property
     * locationWindow.setStickToBorder(true);
     * System.out.println("Set stick to border to true");
     * }
     * </pre>
     * @return Specifies whether sublocation content sticks to screen borders.
     */
    public abstract boolean getStickToBorder();

    /**
     * Specifies whether sublocation content sticks to screen borders.
     * If true, content sticks to screen bounds; if false, content is centered. Default: true.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set stick to border property
     * locationWindow.setStickToBorder(true);
     * System.out.println("Set stick to border to true");
     * }
     * </pre>
     * @param newStickToBorder Specifies whether sublocation content sticks to screen borders.
     */
    public abstract void setStickToBorder(boolean newStickToBorder);

    /**
     * Current camera position in meters.
     * {@link com.navigine.idl.java.Camera Camera}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set camera position without animation
     * locationWindow.setCamera(newCamera);
     * System.out.println("Set camera position to (" + newPoint.x + ", " + newPoint.y + ") with zoom 50.0, rotation 0°, tilt 0°");
     * }
     * </pre>
     * @return Current camera position in meters.
     */
    public abstract Camera getCamera();

    /**
     * Current camera position in meters.
     * {@link com.navigine.idl.java.Camera Camera}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set camera position without animation
     * locationWindow.setCamera(newCamera);
     * System.out.println("Set camera position to (" + newPoint.x + ", " + newPoint.y + ") with zoom 50.0, rotation 0°, tilt 0°");
     * }
     * </pre>
     * @param newCamera Current camera position in meters.
     */
    public abstract void setCamera(Camera newCamera);

    /**
     * Specifies whether rotation gestures (e.g., two-finger rotation) are enabled.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set rotate gesture enabled
     * locationWindow.setRotateGestureEnabled(true);
     * System.out.println("Set rotate gesture enabled to true");
     * }
     * </pre>
     * @return Specifies whether rotation gestures (e.g., two-finger rotation) are enabled.
     */
    public abstract boolean getRotateGestureEnabled();

    /**
     * Specifies whether rotation gestures (e.g., two-finger rotation) are enabled.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set rotate gesture enabled
     * locationWindow.setRotateGestureEnabled(true);
     * System.out.println("Set rotate gesture enabled to true");
     * }
     * </pre>
     * @param newRotateGestureEnabled Specifies whether rotation gestures (e.g., two-finger rotation) are enabled.
     */
    public abstract void setRotateGestureEnabled(boolean newRotateGestureEnabled);

    /**
     * Specifies whether tilt gestures (e.g., two-finger parallel pan) are enabled.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set tilt gestures enabled
     * locationWindow.setTiltGesturesEnabled(true);
     * System.out.println("Set tilt gestures enabled to true");
     * }
     * </pre>
     * @return Specifies whether tilt gestures (e.g., two-finger parallel pan) are enabled.
     */
    public abstract boolean getTiltGesturesEnabled();

    /**
     * Specifies whether tilt gestures (e.g., two-finger parallel pan) are enabled.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set tilt gestures enabled
     * locationWindow.setTiltGesturesEnabled(true);
     * System.out.println("Set tilt gestures enabled to true");
     * }
     * </pre>
     * @param newTiltGesturesEnabled Specifies whether tilt gestures (e.g., two-finger parallel pan) are enabled.
     */
    public abstract void setTiltGesturesEnabled(boolean newTiltGesturesEnabled);

    /**
     * Specifies whether scroll gestures (e.g., pan gesture) are enabled.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set scroll gestures enabled
     * locationWindow.setScrollGesturesEnabled(true);
     * System.out.println("Set scroll gestures enabled to true");
     * }
     * </pre>
     * @return Specifies whether scroll gestures (e.g., pan gesture) are enabled.
     */
    public abstract boolean getScrollGesturesEnabled();

    /**
     * Specifies whether scroll gestures (e.g., pan gesture) are enabled.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set scroll gestures enabled
     * locationWindow.setScrollGesturesEnabled(true);
     * System.out.println("Set scroll gestures enabled to true");
     * }
     * </pre>
     * @param newScrollGesturesEnabled Specifies whether scroll gestures (e.g., pan gesture) are enabled.
     */
    public abstract void setScrollGesturesEnabled(boolean newScrollGesturesEnabled);

    /**
     * Specifies whether zoom gestures (e.g., two-finger pinch) are enabled.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set zoom gestures enabled
     * locationWindow.setZoomGesturesEnabled(true);
     * System.out.println("Set zoom gestures enabled to true");
     * }
     * </pre>
     * @return Specifies whether zoom gestures (e.g., two-finger pinch) are enabled.
     */
    public abstract boolean getZoomGesturesEnabled();

    /**
     * Specifies whether zoom gestures (e.g., two-finger pinch) are enabled.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set zoom gestures enabled
     * locationWindow.setZoomGesturesEnabled(true);
     * System.out.println("Set zoom gestures enabled to true");
     * }
     * </pre>
     * @param newZoomGesturesEnabled Specifies whether zoom gestures (e.g., two-finger pinch) are enabled.
     */
    public abstract void setZoomGesturesEnabled(boolean newZoomGesturesEnabled);

    /**
     * Radius for picking features on the map, in density-independent pixels.
     * Default: 0.5 dp.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set pick radius
     * locationWindow.setPickRadius(10.0);
     * System.out.println("Set pick radius to 10.0 pixels");
     * }
     * </pre>
     * @return Radius for picking features on the map, in density-independent pixels.
     */
    public abstract float getPickRadius();

    /**
     * Radius for picking features on the map, in density-independent pixels.
     * Default: 0.5 dp.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Set pick radius
     * locationWindow.setPickRadius(10.0);
     * System.out.println("Set pick radius to 10.0 pixels");
     * }
     * </pre>
     * @param newPickRadius Radius for picking features on the map, in density-independent pixels.
     */
    public abstract void setPickRadius(float newPickRadius);

    /**
     * List of currently selected map feature IDs.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get list of selected map features
     * List<String> selectedFeatures = locationWindow.getSelectedMapFeatures();
     * System.out.println("Currently selected map features: " + selectedFeatures.size() + " features");
     * for (String feature : selectedFeatures) {
     *    System.out.println("  - " + feature);
     * }
     * }
     * </pre>
     * @return List of currently selected map feature IDs.
     */
    public abstract ArrayList<String> getSelectedMapFeatures();

    /**
     * Tells if this {@link LocationWindow} is valid or not. Any other method
     * (except for this one) called on an invalid {@link LocationWindow} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();

    /**
     * Sets the state of a debug flag.
     * @param flag The debug flag to set {@link com.navigine.idl.java.DebugFlag DebugFlag}.
     * @param on Specifies whether the debug flag is enabled (true) or disabled (false).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * LocationWindow.setDebugFlag(DebugFlag.INFOS, true);
     * LocationWindow.setDebugFlag(DebugFlag.STATS, false);
     * System.out.println("Updated debug flags on LocationWindow");
     * }
     * </pre>
     */
    public static void setDebugFlag(DebugFlag flag, boolean on)
    {
        com.navigine.idl.java.internal.LocationWindowBinding.setDebugFlag(flag,
                                                                          on);
    }

    /**
     * Gets the state of a debug flag.
     * @param flag The debug flag to query {@link com.navigine.idl.java.DebugFlag DebugFlag}.
     * @return true if the debug flag is enabled, false otherwise.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * boolean infosOn = LocationWindow.getDebugFlag(DebugFlag.INFOS);
     * System.out.println("Debug flag INFOS enabled: " + infosOn);
     * }
     * </pre>
     */
    public static boolean getDebugFlag(DebugFlag flag)
    {
        return com.navigine.idl.java.internal.LocationWindowBinding.getDebugFlag(flag);
    }
}
