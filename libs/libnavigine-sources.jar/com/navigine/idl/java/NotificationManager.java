package com.navigine.idl.java;

import com.navigine.common.NativeObject;
import com.navigine.common.Subscription;

/**
 * Class is used to manage local {@link com.navigine.idl.java.Notification Notification}s
 * Notification should be created in CMS. Notification handle iBeacon signals,
 * detect proximity and notify user about event.
 * Referenced from {@link com.navigine.idl.java.NavigineSdk NavigineSdk}.
 */
public abstract class NotificationManager {
    /**
     * Method is used to add {@link com.navigine.idl.java.NotificationListener NotificationListener} class element which will notify
     * all incoming local notification events.
     * <p><b>Note:</b> Do not forget to remove listener if it is no longer needed!</p>
     * @param listener Corresponding {@link com.navigine.idl.java.NotificationListener NotificationListener} listener class.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Add notification listener
     * notificationManager.addNotificationListener(notificationListener);
     * System.out.println("Added notification listener");
     * }
     * </pre>
     */
    public abstract void addNotificationListener(NotificationListener listener);

    /**
     * Method is used for removing previously added {@link com.navigine.idl.java.NotificationListener NotificationListener} class element.
     * @param listener Corresponding {@link com.navigine.idl.java.NotificationListener NotificationListener} class to remove.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove notification listener
     * notificationManager.removeNotificationListener(notificationListener);
     * System.out.println("Removed notification listener");
     * }
     * </pre>
     */
    public abstract void removeNotificationListener(NotificationListener listener);
}
