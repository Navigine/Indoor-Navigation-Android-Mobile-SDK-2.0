package com.navigine.idl.java;

/**
 * Class describing user's position.
 * Referenced from: {@link com.navigine.idl.java.NavigationManager NavigationManager}, {@link com.navigine.idl.java.PositionListener PositionListener}.
 */
public final class Position {


    /*package*/ final GlobalPoint point;

    /*package*/ final double accuracy;

    /*package*/ final Double heading;

    /*package*/ final Double headingAccuracy;

    /*package*/ final LocationPoint locationPoint;

    /*package*/ final Double locationHeading;

    /**
     * Default constructor for class Position
     */
    public Position(
            GlobalPoint point,
            double accuracy,
            Double heading,
            Double headingAccuracy,
            LocationPoint locationPoint,
            Double locationHeading) {
        this.point = point;
        this.accuracy = accuracy;
        this.heading = heading;
        this.headingAccuracy = headingAccuracy;
        this.locationPoint = locationPoint;
        this.locationHeading = locationHeading;
    }

    /**
     * position in WGS84 coordinates.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get global point (WGS84 coordinates)
     * GlobalPoint globalPoint = position.getPoint();
     * if (globalPoint != null) {
     *    demonstrateGlobalPointUsage(globalPoint);
     * }
     * }
     * </pre>
     * @return position in WGS84 coordinates.
     */
    public GlobalPoint getPoint() {
        return point;
    }

    /**
     * Position accuracy in meters
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get position accuracy
     * double accuracy = position.getAccuracy();
     * System.out.println("Position accuracy: " + accuracy + " meters");
     * }
     * </pre>
     * @return Position accuracy in meters
     */
    public double getAccuracy() {
        return accuracy;
    }

    /**
     * Heading, angle of rotation about the -Z axis (in radians).
     * This value represents the angle between the device's Y
     * axis and the magnetic north pole. When facing north, this
     * angle is 0, when facing south, this angle is pi.
     * Likewise, when facing east, this angle is pi/2, and
     * when facing west, this angle is -pi/2. The range of
     * values is [-pi, pi].
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get heading (angle of rotation about the -Z axis in radians)
     * Double heading = position.getHeading();
     * if (heading != null) {
     *    System.out.println("Heading: " + heading + " radians");
     * }
     * }
     * </pre>
     * @return Heading, angle of rotation about the -Z axis (in radians).
     */
    public Double getHeading() {
        return heading;
    }

    /**
     * Heading accuracy in radians
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get heading accuracy
     * Double headingAccuracy = position.getHeadingAccuracy();
     * if (headingAccuracy != null) {
     *    System.out.println("Heading accuracy: " + headingAccuracy + " radians");
     * }
     * }
     * </pre>
     * @return Heading accuracy in radians
     */
    public Double getHeadingAccuracy() {
        return headingAccuracy;
    }

    /**
     * position in metrics coordinates at calculated location and sublocation @see LocationPoint
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get location point (metrics coordinates)
     * LocationPoint locationPoint = position.getLocationPoint();
     * if (locationPoint != null) {
     *    demonstrateLocationPointUsage(locationPoint);
     * }
     * }
     * </pre>
     * @return position in metrics coordinates at calculated location and sublocation @see LocationPoint
     */
    public LocationPoint getLocationPoint() {
        return locationPoint;
    }

    /**
     * Similar to `heading` but with respect to `sublocation north` (top of the image)
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get location heading (with respect to sublocation north)
     * Double locationHeading = position.getLocationHeading();
     * if (locationHeading != null) {
     *    System.out.println("Location heading: " + locationHeading + " radians");
     * }
     * }
     * </pre>
     * @return Similar to {@code heading} but with respect to {@code sublocation north} (top of the image)
     */
    public Double getLocationHeading() {
        return locationHeading;
    }

    @Override
    public String toString() {
        return "Position{" +
                "point=" + point +
                "," + "accuracy=" + accuracy +
                "," + "heading=" + heading +
                "," + "headingAccuracy=" + headingAccuracy +
                "," + "locationPoint=" + locationPoint +
                "," + "locationHeading=" + locationHeading +
        "}";
    }

}
