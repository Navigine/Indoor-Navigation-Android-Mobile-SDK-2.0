package com.navigine.idl.java;

/**
 * Class is used for representing certain point within the location.
 * Referenced from: {@link com.navigine.idl.java.AsyncRouteListener AsyncRouteListener}, {@link com.navigine.idl.java.AsyncRouteManager AsyncRouteManager}, {@link com.navigine.idl.java.CircleMapObject CircleMapObject},
 * {@link com.navigine.idl.java.IconMapObject IconMapObject}, {@link com.navigine.idl.java.MapObjectPickResult MapObjectPickResult},
 * {@link com.navigine.idl.java.NavigationManager NavigationManager}, {@link com.navigine.idl.java.Notification Notification}, {@link com.navigine.idl.java.Position Position}, {@link com.navigine.idl.java.RouteManager RouteManager},
 * {@link com.navigine.idl.java.RoutePath RoutePath}, {@link com.navigine.idl.java.Sublocation Sublocation}, {@link com.navigine.idl.java.Venue Venue}.
 */
public final class LocationPoint {


    /*package*/ final Point point;

    /*package*/ final int locationId;

    /*package*/ final int sublocationId;

    /**
     * Default constructor for class LocationPoint
     */
    public LocationPoint(
            Point point,
            int locationId,
            int sublocationId) {
        this.point = point;
        this.locationId = locationId;
        this.sublocationId = sublocationId;
    }

    /**
     * location point X and Y coordinates in meters as Point (within the sublocation).
     * @return location point X and Y coordinates in meters as Point (within the sublocation).
     */
    public Point getPoint() {
        return point;
    }

    /**
     * location point location identifier.
     * @return location point location identifier.
     */
    public int getLocationId() {
        return locationId;
    }

    /**
     * location point sublocation identifier.
     * @return location point sublocation identifier.
     */
    public int getSublocationId() {
        return sublocationId;
    }

    @Override
    public String toString() {
        return "LocationPoint{" +
                "point=" + point +
                "," + "locationId=" + locationId +
                "," + "sublocationId=" + sublocationId +
        "}";
    }

}
