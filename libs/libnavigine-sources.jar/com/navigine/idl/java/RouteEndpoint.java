package com.navigine.idl.java;

/**
 * Route endpoint in WGS84 coordinates.
 * When sublocationId is set, the endpoint is treated as indoor and projected
 * to that sublocation. When sublocationId is null, the endpoint is treated as
 * outdoor.
 * Referenced from {@link com.navigine.idl.java.RouteLayer RouteLayer}.
 */
public final class RouteEndpoint {


    /*package*/ final GlobalPoint point;

    /*package*/ final Integer sublocationId;

    /**
     * Default constructor for class RouteEndpoint
     */
    public RouteEndpoint(
            GlobalPoint point,
            Integer sublocationId) {
        this.point = point;
        this.sublocationId = sublocationId;
    }

    /**
     * Endpoint in WGS84 coordinates.
     * @return Endpoint in WGS84 coordinates.
     */
    public GlobalPoint getPoint() {
        return point;
    }

    /**
     * Floor id for an indoor endpoint, or null for outdoor.
     * @return Floor id for an indoor endpoint, or null for outdoor.
     */
    public Integer getSublocationId() {
        return sublocationId;
    }

    @Override
    public String toString() {
        return "RouteEndpoint{" +
                "point=" + point +
                "," + "sublocationId=" + sublocationId +
        "}";
    }

}
