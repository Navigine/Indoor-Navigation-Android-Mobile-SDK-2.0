package com.navigine.idl.java;

import java.util.ArrayList;

public abstract class BeaconProximityEstimatorListener {
    public abstract void onScanResultReady(ArrayList<BeaconProximityEntry> beacons);

    public abstract void onProgressChanged(float progress);

    public abstract void onFinished(ArrayList<BeaconProximityEntry> beacons);

    public abstract void onFailed(java.lang.Error error);
}
