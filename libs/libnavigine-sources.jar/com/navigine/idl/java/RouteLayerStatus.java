package com.navigine.idl.java;

public enum RouteLayerStatus {
    IDLE,
    ROUTE_UPDATED,
    MISSING_GRAPH,
    MISSING_LOCATION,
    MISSING_POSITION,
    MISSING_ROUTE,
    MISSING_PROJECTION,
    ;
}
