package com.navigine.idl.java;

import com.navigine.common.NativeObject;
import com.navigine.common.Subscription;

/**
 * Drives the map camera from a {@link com.navigine.idl.java.RouteLayer RouteLayer} and exposes
 * the next instruction. Does not draw the route.
 * Overview uses the window focus rect, so set {@code LocationWindow.focusRect} for
 * chrome (floor selector, banner) before switching to {@code OVERVIEW}.
 * Referenced from {@link com.navigine.idl.java.NavigineSdk NavigineSdk}.
 */
public abstract class GuidanceCamera {
    /**
     * Sets Free / Following / Overview.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * guidanceCamera.setMode(GuidanceCameraMode.FOLLOWING);
     * }
     * </pre>
     */
    public abstract void setMode(GuidanceCameraMode mode);

    /**
     * Current mode.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * System.out.println("Guidance mode: " + guidanceCamera.mode());
     * }
     * </pre>
     */
    public abstract GuidanceCameraMode mode();

    /**
     * Forces a top-down camera (tilt 0) in Following and Overview.
     * When false, Following uses a fixed forward tilt.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * guidanceCamera.set2DMode(false);
     * }
     * </pre>
     */
    public abstract void set2DMode(boolean enabled);

    /**
     * Returns true when top-down guidance is enabled.
     */
    public abstract boolean is2DMode();

    /**
     * When false, the camera is not moved. Instructions still update.
     */
    public abstract void setActive(boolean active);

    /**
     * Returns true when this controller may move the camera.
     */
    public abstract boolean isActive();

    /**
     * Latest next instruction, or null.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * RouteInstruction next = guidanceCamera.instruction();
     * if (next != null) {
     *    System.out.println("Next instruction: " + next.getTitle() + " " + next.getDistance() + " m");
     * }
     * }
     * </pre>
     */
    public abstract RouteInstruction instruction();

    /**
     * Adds a listener for mode and instruction changes.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * guidanceCamera.addListener(new GuidanceListener() {
     *    @Override
     *    public void onCameraModeChanged(GuidanceCameraMode mode) {
     *        System.out.println("Guidance camera mode: " + mode);
     *    }
     *    @Override
     *    public void onInstructionChanged(RouteInstruction instruction) {
     *        System.out.println("Next: " + (instruction == null ? "none" : instruction.getTitle()));
     *    }
     * });
     * }
     * </pre>
     */
    public abstract void addListener(GuidanceListener listener);

    /**
     * Removes a previously added listener.
     */
    public abstract void removeListener(GuidanceListener listener);

    /**
     * Tells if this {@link GuidanceCamera} is valid or not. Any other method
     * (except for this one) called on an invalid {@link GuidanceCamera} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
