package com.navigine.idl.java;

/**
 * A rectangle with specified origin and size.
 *
 * <p><b>Example:</b></p>
 * <pre>
 * {@code
 * // Create rectangle with x, y, width, height
 * Rectangle rect1 = new Rectangle(10, 20, 100, 150);
 * System.out.println("Created rectangle: x=" + rect1.getX() + ", y=" + rect1.getY() +
 *                  ", width=" + rect1.getWidth() + ", height=" + rect1.getHeight());
 * }
 * </pre>
 */
public final class Rectangle {


    /*package*/ final int x;

    /*package*/ final int y;

    /*package*/ final int width;

    /*package*/ final int height;

    /**
     * Default constructor for class Rectangle
     */
    public Rectangle(
            int x,
            int y,
            int width,
            int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    /**
     * rectangle's origin `x` coordinate.
     * @return rectangle's origin {@code x} coordinate.
     */
    public int getX() {
        return x;
    }

    /**
     * rectangle's origin `y` coordinate.
     * @return rectangle's origin {@code y} coordinate.
     */
    public int getY() {
        return y;
    }

    /**
     * rectangle's width.
     * @return rectangle's width.
     */
    public int getWidth() {
        return width;
    }

    /**
     * rectangle's height.
     * @return rectangle's height.
     */
    public int getHeight() {
        return height;
    }

    @Override
    public String toString() {
        return "Rectangle{" +
                "x=" + x +
                "," + "y=" + y +
                "," + "width=" + width +
                "," + "height=" + height +
        "}";
    }

}
