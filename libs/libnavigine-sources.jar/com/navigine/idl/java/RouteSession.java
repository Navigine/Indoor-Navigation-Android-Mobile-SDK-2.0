package com.navigine.idl.java;

import com.navigine.platform.NativeObject;
import com.navigine.platform.Subscription;

/**
 * Class is used for managing async route listeners
 * Referenced from {@link com.navigine.idl.java.AsyncRouteManager AsyncRouteManager}.
 */
public abstract class RouteSession {
    /**
     * Method is used to add {@link com.navigine.idl.java.AsyncRouteListener AsyncRouteListener} class element
     * which will notify async route events.
     * <p><b>Note:</b> Do not forget to remove listener if it is no longer needed!</p>
     * @param listener Corresponding {@link com.navigine.idl.java.AsyncRouteListener AsyncRouteListener} class.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Add route listener to session
     * session.addRouteListener(asyncRouteListener);
     * }
     * </pre>
     */
    public abstract void addRouteListener(AsyncRouteListener listener);

    /**
     * Method is used for removing previously added {@link com.navigine.idl.java.AsyncRouteListener AsyncRouteListener} class element.
     * @param listener Corresponding {@link com.navigine.idl.java.AsyncRouteListener AsyncRouteListener} class to remove.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove route listener
     * currentSession.removeRouteListener(asyncRouteListener);
     * }
     * </pre>
     */
    public abstract void removeRouteListener(AsyncRouteListener listener);

    /**
     * Tells if this {@link RouteSession} is valid or not. Any other method
     * (except for this one) called on an invalid {@link RouteSession} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
