package com.navigine.idl.java;

import java.util.ArrayList;

/**
 * Interface for managing multiple key-value storages, providing access and lifecycle control.
 * Referenced from {@link com.navigine.idl.java.NavigineSdk NavigineSdk}.
 */
public abstract class StorageManager {
    /**
     * Returns the list of all existing user storages.
     * @return List of storage names (implementation currently returns them in alphabetical order).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get list of all existing storages
     * List<String> storageList = storageManager.getStorageList();
     * System.out.println("Existing storages: " + storageList);
     * }
     * </pre>
     */
    public abstract ArrayList<String> getStorageList();

    /**
     * Returns a handle to a storage by name, creating it if it does not exist.
     * @param name Storage name (case-sensitive).
     * @return Key–value storage instance {@link com.navigine.idl.java.KeyValueStorage KeyValueStorage}
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get or create different storage instances
     * userStorage = storageManager.getStorage("user_preferences");
     * appStorage = storageManager.getStorage("app_settings");
     * cacheStorage = storageManager.getStorage("cache");
     * }
     * </pre>
     */
    public abstract KeyValueStorage getStorage(String name);

    /**
     * Removes the storage and all its persisted data. If the storage does not exist, this is a no-op.
     * <p><b>Note:</b> Existing handles to this storage become invalid after removal and further operations may fail.</p>
     * @param name Storage name (case-sensitive).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove storage and all its data
     * storageManager.removeStorage("test_storage");
     * System.out.println("Removed test storage");
     * }
     * </pre>
     */
    public abstract void removeStorage(String name);
}
