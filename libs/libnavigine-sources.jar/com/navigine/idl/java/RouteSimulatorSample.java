package com.navigine.idl.java;

/**
 * One sample while walking a polyline.
 * {@code advance} is meters from the start along the geometry.
 * {@code heading} is radians, clockwise from north (same sense as user-location course).
 * This is a pedestrian location fix: no accuracy noise, wheel speed, or
 * recorded-session clock.
 */
public final class RouteSimulatorSample {


    /*package*/ final GlobalPoint point;

    /*package*/ final Integer sublocationId;

    /*package*/ final float advance;

    /*package*/ final float heading;

    /**
     * Default constructor for class RouteSimulatorSample
     */
    public RouteSimulatorSample(
            GlobalPoint point,
            Integer sublocationId,
            float advance,
            float heading) {
        this.point = point;
        this.sublocationId = sublocationId;
        this.advance = advance;
        this.heading = heading;
    }

    public GlobalPoint getPoint() {
        return point;
    }

    public Integer getSublocationId() {
        return sublocationId;
    }

    public float getAdvance() {
        return advance;
    }

    public float getHeading() {
        return heading;
    }

    @Override
    public String toString() {
        return "RouteSimulatorSample{" +
                "point=" + point +
                "," + "sublocationId=" + sublocationId +
                "," + "advance=" + advance +
                "," + "heading=" + heading +
        "}";
    }

}
