package com.navigine.idl.java;

import com.navigine.platform.NativeObject;
import com.navigine.platform.Subscription;

/**
 * Class is used for notifying about entering or leaving {@link com.navigine.idl.java.Zone Zone}s.
 * Referenced from {@link com.navigine.idl.java.NavigineSdk NavigineSdk}.
 */
public abstract class ZoneManager {
    /**
     * Method is used to add {@link com.navigine.idl.java.ZoneListener ZoneListener} class element
     * which will notify entering or leaving {@link com.navigine.idl.java.Zone Zone}s.
     * <p><b>Note:</b> Do not forget to remove listener if it is no longer needed!</p>
     * @param listener Corresponding {@link com.navigine.idl.java.ZoneListener ZoneListener} class.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Add zone listener
     * zoneManager.addZoneListener(zoneListener);
     * System.out.println("Added zone listener");
     * }
     * </pre>
     */
    public abstract void addZoneListener(ZoneListener listener);

    /**
     * Method is used for removing previously added {@link com.navigine.idl.java.ZoneListener ZoneListener} class element.
     * @param listener Corresponding {@link com.navigine.idl.java.ZoneListener ZoneListener} class to remove.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove zone listener
     * zoneManager.removeZoneListener(zoneListener);
     * System.out.println("Removed zone listener");
     * }
     * </pre>
     */
    public abstract void removeZoneListener(ZoneListener listener);
}
