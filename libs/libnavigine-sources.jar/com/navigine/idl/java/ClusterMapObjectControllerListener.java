package com.navigine.idl.java;

/**
 * Listener for cluster lifecycle events on {@link com.navigine.idl.java.ClusterMapObjectController ClusterMapObjectController}.
 * Cluster pick is delivered via {@link com.navigine.idl.java.PickListener PickListener} ({@code pickMapObjectAt}).
 * {@code onClusterCreated} is called when a cluster appears (at least two icons grouped).
 * {@code onClusterDestroyed} is called when a cluster is removed (fewer than two icons remain or controller is cleared).
 */
public abstract class ClusterMapObjectControllerListener {
    /**
     * A new cluster marker appeared.
     * @param controller Cluster controller that owns the cluster.
     * @param cluster Newly created cluster. Use {@code getCount()} for the initial badge value.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * @Override
     * public void onClusterCreated(ClusterMapObjectController controller, ClusterMapObject cluster) {
     *    // [java_ClusterMapObject_addListener]
     *    cluster.addListener(clusterChangeListener);
     *    System.out.println("Added cluster change listener, initial count: " + cluster.getCount());
     *    // [java_ClusterMapObject_addListener]
     *    activeCluster = cluster;
     * }
     * }
     * </pre>
     */
    public abstract void onClusterCreated(ClusterMapObjectController controller, ClusterMapObject cluster);

    /**
     * A cluster marker was removed.
     * @param controller Cluster controller that owned the cluster.
     * @param clusterId Identifier of the destroyed cluster (same as {@link com.navigine.idl.java.ClusterMapObject ClusterMapObject} {@code getId()}).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * @Override
     * public void onClusterDestroyed(ClusterMapObjectController controller, int clusterId) {
     *    if (activeCluster != null && activeCluster.getId() == clusterId) {
     *        // [java_ClusterMapObject_removeListener]
     *        activeCluster.removeListener(clusterChangeListener);
     *        System.out.println("Removed cluster change listener");
     *        // [java_ClusterMapObject_removeListener]
     *        activeCluster = null;
     *    }
     *    System.out.println("Cluster destroyed, id: " + clusterId);
     * }
     * }
     * </pre>
     */
    public abstract void onClusterDestroyed(ClusterMapObjectController controller, int clusterId);
}
