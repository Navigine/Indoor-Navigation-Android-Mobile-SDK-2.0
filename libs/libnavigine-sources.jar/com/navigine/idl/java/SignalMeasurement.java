package com.navigine.idl.java;

/**
 * Structure representing a signal measurement with type, identifier, RSSI, distance, and timestamp.
 * Referenced from {@link com.navigine.idl.java.MeasurementListener MeasurementListener}.
 */
public final class SignalMeasurement implements Comparable<SignalMeasurement> {


    /*package*/ final SignalType type;

    /*package*/ final String id;

    /*package*/ final float rssi;

    /*package*/ final float distance;

    /*package*/ final long time;

    /**
     * Default constructor for class SignalMeasurement
     */
    public SignalMeasurement(
            SignalType type,
            String id,
            float rssi,
            float distance,
            long time) {
        this.type = type;
        this.id = id;
        this.rssi = rssi;
        this.distance = distance;
        this.time = time;
    }

    /**
     * Type of the signal
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get signal type
     * SignalType type = measurement.getType();
     * System.out.println("Signal type: " + type);
     * }
     * </pre>
     * @return Type of the signal
     */
    public SignalType getType() {
        return type;
    }

    /**
     * Unique identifier of the signal (e.g., MAC address or UUID)
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get signal identifier
     * String id = measurement.getId();
     * System.out.println("Signal ID: " + id);
     * }
     * </pre>
     * @return Unique identifier of the signal (e.g., MAC address or UUID)
     */
    public String getId() {
        return id;
    }

    /**
     * Received Signal Strength Indicator (RSSI) in dBm
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get RSSI value
     * double rssi = measurement.getRssi();
     * System.out.println("Signal RSSI: " + rssi + " dBm");
     * }
     * </pre>
     * @return Received Signal Strength Indicator (RSSI) in dBm
     */
    public float getRssi() {
        return rssi;
    }

    /**
     * Estimated distance to the signal source in meters
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get estimated distance
     * double distance = measurement.getDistance();
     * System.out.println("Signal distance: " + distance + " meters");
     * }
     * </pre>
     * @return Estimated distance to the signal source in meters
     */
    public float getDistance() {
        return distance;
    }

    /**
     * Timestamp of the measurement in milliseconds
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get measurement timestamp
     * long time = measurement.getTime();
     * System.out.println("Signal measurement time: " + time + " ms");
     * }
     * </pre>
     * @return Timestamp of the measurement in milliseconds
     */
    public long getTime() {
        return time;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof SignalMeasurement)) {
            return false;
        }
        SignalMeasurement other = (SignalMeasurement) obj;
        return this.type == other.type &&
                this.id.equals(other.id) &&
                this.rssi == other.rssi &&
                this.distance == other.distance &&
                this.time == other.time;
    }

    @Override
    public int hashCode() {
        // Pick an arbitrary non-zero starting value
        int hashCode = 17;
        hashCode = hashCode * 31 + type.hashCode();
        hashCode = hashCode * 31 + id.hashCode();
        hashCode = hashCode * 31 + Float.floatToIntBits(rssi);
        hashCode = hashCode * 31 + Float.floatToIntBits(distance);
        hashCode = hashCode * 31 + ((int) (time ^ (time >>> 32)));
        return hashCode;
    }

    @Override
    public String toString() {
        return "SignalMeasurement{" +
                "type=" + type +
                "," + "id=" + id +
                "," + "rssi=" + rssi +
                "," + "distance=" + distance +
                "," + "time=" + time +
        "}";
    }


    @Override
    public int compareTo(SignalMeasurement other)  {
        int tempResult;
        tempResult = this.type.compareTo(other.type);if (tempResult != 0) {
            return tempResult;
        }
        tempResult = this.id.compareTo(other.id);
        if (tempResult != 0) {
            return tempResult;
        }
        if (this.rssi < other.rssi) {
            tempResult = -1;
        } else if (this.rssi > other.rssi) {
            tempResult = 1;
        } else {
            tempResult = 0;
        }
        if (tempResult != 0) {
            return tempResult;
        }
        if (this.distance < other.distance) {
            tempResult = -1;
        } else if (this.distance > other.distance) {
            tempResult = 1;
        } else {
            tempResult = 0;
        }
        if (tempResult != 0) {
            return tempResult;
        }
        if (this.time < other.time) {
            tempResult = -1;
        } else if (this.time > other.time) {
            tempResult = 1;
        } else {
            tempResult = 0;
        }
        if (tempResult != 0) {
            return tempResult;
        }
        return 0;
    }
}
