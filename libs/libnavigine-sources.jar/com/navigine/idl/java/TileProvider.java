package com.navigine.idl.java;

/**
 * Outdoor tile source: vector MVT or raster imagery.
 * Set either {@code http} or {@code mbtiles}. When {@code mbtiles} is set, tiles are read only
 * from that file — no network. {@code kind} selects the payload. For {@code vector},
 * {@code schema} must match the tiles. For {@code raster}, {@code schema} is ignored.
 * Null {@code LocationWindow.tileProvider} keeps the default OSM Shortbread endpoint.
 * Referenced from {@link com.navigine.idl.java.LocationWindow LocationWindow} {@code tileProvider}.
 */
public final class TileProvider {


    /*package*/ final TileSchema schema;

    /*package*/ final HttpTileSource http;

    /*package*/ final MbtilesTileSource mbtiles;

    /*package*/ final int minZoom;

    /*package*/ final int maxZoom;

    /*package*/ final String attribution;

    /*package*/ final TileKind kind;

    /**
     * Default constructor for class TileProvider
     */
    public TileProvider(
            TileSchema schema,
            HttpTileSource http,
            MbtilesTileSource mbtiles,
            int minZoom,
            int maxZoom,
            String attribution,
            TileKind kind) {
        this.schema = schema;
        this.http = http;
        this.mbtiles = mbtiles;
        this.minZoom = minZoom;
        this.maxZoom = maxZoom;
        this.attribution = attribution;
        this.kind = kind;
    }

    /**
     * Default constructor for class TileProvider
     */
    public TileProvider(
            TileSchema schema,
            HttpTileSource http,
            MbtilesTileSource mbtiles,
            String attribution) {
        this(schema, http, mbtiles, 0, 14, attribution, TileKind.VECTOR);
    }

    /**
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * TileProvider osmHttp = new TileProvider(
     *    TileSchema.OPEN_MAP_TILES,
     *    http,
     *    null,
     *    0,
     *    14,
     *    null,
     *    TileKind.VECTOR);
     * TileProvider mbtiles = new TileProvider(
     *    TileSchema.SHORTBREAD,
     *    null,
     *    offline,
     *    0,
     *    14,
     *    null,
     *    TileKind.VECTOR);
     * }
     * </pre>
     * Tile schema {@link com.navigine.idl.java.TileSchema TileSchema}. Used when `kind` is vector.
     * @return <java>
     */
    public TileSchema getSchema() {
        return schema;
    }

    /**
     * Remote XYZ source {@link com.navigine.idl.java.HttpTileSource HttpTileSource}. Ignored when mbtiles is set.
     * @return Remote XYZ source {@link HttpTileSource HttpTileSource}. Ignored when mbtiles is set.
     */
    public HttpTileSource getHttp() {
        return http;
    }

    /**
     * Local MBTiles pack {@link com.navigine.idl.java.MbtilesTileSource MbtilesTileSource}.
     * @return Local MBTiles pack {@link MbtilesTileSource MbtilesTileSource}.
     */
    public MbtilesTileSource getMbtiles() {
        return mbtiles;
    }

    /**
     * Minimum source zoom. Default: 0.
     * @return Minimum source zoom. Default: 0.
     */
    public int getMinZoom() {
        return minZoom;
    }

    /**
     * Maximum source zoom (camera overzooms above this). Default: 14.
     * @return Maximum source zoom (camera overzooms above this). Default: 14.
     */
    public int getMaxZoom() {
        return maxZoom;
    }

    /**
     * Attribution overlay text. Null on a vector source: `© OpenStreetMap contributors`.
     * @return Attribution overlay text. Null on a vector source: {@code © OpenStreetMap contributors}.
     */
    public String getAttribution() {
        return attribution;
    }

    /**
     * Vector MVT or raster imagery {@link com.navigine.idl.java.TileKind TileKind}. Default: vector.
     * @return Vector MVT or raster imagery {@link TileKind TileKind}. Default: vector.
     */
    public TileKind getKind() {
        return kind;
    }

    @Override
    public String toString() {
        return "TileProvider{" +
                "schema=" + schema +
                "," + "http=" + http +
                "," + "mbtiles=" + mbtiles +
                "," + "minZoom=" + minZoom +
                "," + "maxZoom=" + maxZoom +
                "," + "attribution=" + attribution +
                "," + "kind=" + kind +
        "}";
    }

}
