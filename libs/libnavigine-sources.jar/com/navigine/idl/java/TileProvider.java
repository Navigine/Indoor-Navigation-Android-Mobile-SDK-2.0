package com.navigine.idl.java;

/**
 * Outdoor vector tile source.
 * Set either {@code http} or {@code mbtiles}. When {@code mbtiles} is set, tiles are read only
 * from that file — no network. {@code schema} must match the tiles. Null
 * {@code LocationWindow.tileProvider} keeps the default OSM Shortbread endpoint.
 * Referenced from {@link com.navigine.idl.java.LocationWindow LocationWindow} {@code tileProvider}.
 */
public final class TileProvider {


    /*package*/ final TileSchema schema;

    /*package*/ final HttpTileSource http;

    /*package*/ final MbtilesTileSource mbtiles;

    /*package*/ final int minZoom;

    /*package*/ final int maxZoom;

    /*package*/ final String attribution;

    /**
     * Default constructor for class TileProvider
     */
    public TileProvider(
            TileSchema schema,
            HttpTileSource http,
            MbtilesTileSource mbtiles,
            int minZoom,
            int maxZoom,
            String attribution) {
        this.schema = schema;
        this.http = http;
        this.mbtiles = mbtiles;
        this.minZoom = minZoom;
        this.maxZoom = maxZoom;
        this.attribution = attribution;
    }

    /**
     * Default constructor for class TileProvider
     */
    public TileProvider(
            TileSchema schema,
            HttpTileSource http,
            MbtilesTileSource mbtiles,
            String attribution) {
        this(schema, http, mbtiles, 0, 14, attribution);
    }

    /**
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * TileProvider osmHttp = new TileProvider(
     *    TileSchema.OPEN_MAP_TILES,
     *    http,
     *    null,
     *    0,
     *    14,
     *    null);
     * TileProvider mbtiles = new TileProvider(
     *    TileSchema.SHORTBREAD,
     *    null,
     *    offline,
     *    0,
     *    14,
     *    null);
     * }
     * </pre>
     * Tile schema {@link com.navigine.idl.java.TileSchema TileSchema}.
     * @return <java>
     */
    public TileSchema getSchema() {
        return schema;
    }

    /**
     * Remote XYZ source {@link com.navigine.idl.java.HttpTileSource HttpTileSource}. Ignored when mbtiles is set.
     * @return Remote XYZ source {@link HttpTileSource HttpTileSource}. Ignored when mbtiles is set.
     */
    public HttpTileSource getHttp() {
        return http;
    }

    /**
     * Local MBTiles pack {@link com.navigine.idl.java.MbtilesTileSource MbtilesTileSource}.
     * @return Local MBTiles pack {@link MbtilesTileSource MbtilesTileSource}.
     */
    public MbtilesTileSource getMbtiles() {
        return mbtiles;
    }

    /**
     * Minimum source zoom. Default: 0.
     * @return Minimum source zoom. Default: 0.
     */
    public int getMinZoom() {
        return minZoom;
    }

    /**
     * Maximum source zoom (camera overzooms above this). Default: 14.
     * @return Maximum source zoom (camera overzooms above this). Default: 14.
     */
    public int getMaxZoom() {
        return maxZoom;
    }

    /**
     * Attribution overlay text. Null: `© OpenStreetMap contributors`.
     * @return Attribution overlay text. Null: {@code © OpenStreetMap contributors}.
     */
    public String getAttribution() {
        return attribution;
    }

    @Override
    public String toString() {
        return "TileProvider{" +
                "schema=" + schema +
                "," + "http=" + http +
                "," + "mbtiles=" + mbtiles +
                "," + "minZoom=" + minZoom +
                "," + "maxZoom=" + maxZoom +
                "," + "attribution=" + attribution +
        "}";
    }

}
