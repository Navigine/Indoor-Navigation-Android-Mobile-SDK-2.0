package com.navigine.idl.java;

import java.util.ArrayList;

/**
 * Interface for key-value storage operations, allowing storage and retrieval of various data types.
 * Referenced from {@link com.navigine.idl.java.StorageManager StorageManager}.
 */
public abstract class KeyValueStorage {
    /**
     * Checks whether the key exists in the storage.
     * @param key Key to check.
     * @return true if a value is stored under the key (regardless of type).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Check if keys exist
     * boolean hasUserName = userStorage.contains("user_name");
     * boolean hasNonExistent = userStorage.contains("non_existent_key");
     * System.out.println("Contains 'user_name': " + hasUserName);
     * System.out.println("Contains 'non_existent_key': " + hasNonExistent);
     * }
     * </pre>
     */
    public abstract boolean contains(String key);

    /**
     * Returns all keys currently stored.
     * @return List of keys. Order is implementation-defined (not guaranteed).
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Get all stored keys
     * List<String> allKeys = userStorage.getKeys();
     * System.out.println("All stored keys: " + allKeys);
     * }
     * </pre>
     */
    public abstract ArrayList<String> getKeys();

    /**
     * Gets a 32-bit integer value.
     * Returns defaultValue if the key is missing or the stored type is not int.
     * @param key Lookup key.
     * @param defaultValue Value to return when not found or type mismatch.
     * @return Stored int32 or defaultValue.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Retrieve integer values with defaults
     * int userAge = userStorage.getInt("user_age", 0);
     * int loginCount = userStorage.getInt("login_count", 0);
     * int nonExistentInt = userStorage.getInt("non_existent_int", -1);
     * System.out.println("User age: " + userAge);
     * System.out.println("Login count: " + loginCount);
     * System.out.println("Non-existent int: " + nonExistentInt);
     * }
     * </pre>
     */
    public abstract int getInt(String key, int defaultValue);

    /**
     * Gets a 64-bit integer value.
     * Returns defaultValue if the key is missing or the stored type is not long.
     * @param key Lookup key.
     * @param defaultValue Value to return when not found or type mismatch.
     * @return Stored int64 or defaultValue.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Retrieve long values with defaults
     * long regTimestamp = userStorage.getLong("registration_timestamp", 0);
     * long lastLogin = userStorage.getLong("last_login_timestamp", 0);
     * long nonExistentLong = userStorage.getLong("non_existent_long", -1);
     * System.out.println("Registration timestamp: " + regTimestamp);
     * System.out.println("Last login timestamp: " + lastLogin);
     * System.out.println("Non-existent long: " + nonExistentLong);
     * }
     * </pre>
     */
    public abstract long getLong(String key, long defaultValue);

    /**
     * Gets a boolean value.
     * Returns defaultValue if the key is missing or the stored type is not bool.
     * @param key Lookup key.
     * @param defaultValue Value to return when not found or type mismatch.
     * @return Stored bool or defaultValue.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Retrieve boolean values with defaults
     * boolean isPremium = userStorage.getBool("is_premium", false);
     * boolean notificationsEnabled = userStorage.getBool("notifications_enabled", true);
     * boolean nonExistentBool = userStorage.getBool("non_existent_bool", false);
     * System.out.println("Is premium: " + isPremium);
     * System.out.println("Notifications enabled: " + notificationsEnabled);
     * System.out.println("Non-existent bool: " + nonExistentBool);
     * }
     * </pre>
     */
    public abstract boolean getBool(String key, boolean defaultValue);

    /**
     * Gets a 32-bit floating-point value.
     * Returns defaultValue if the key is missing or the stored type is not float.
     * @param key Lookup key.
     * @param defaultValue Value to return when not found or type mismatch.
     * @return Stored float or defaultValue.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Retrieve float values with defaults
     * float userRating = userStorage.getFloat("user_rating", 0.0f);
     * float temperature = userStorage.getFloat("temperature", 0.0f);
     * float nonExistentFloat = userStorage.getFloat("non_existent_float", -1.0f);
     * System.out.println("User rating: " + userRating);
     * System.out.println("Temperature: " + temperature);
     * System.out.println("Non-existent float: " + nonExistentFloat);
     * }
     * </pre>
     */
    public abstract float getFloat(String key, float defaultValue);

    /**
     * Gets a 64-bit floating-point value.
     * Returns defaultValue if the key is missing or the stored type is not double.
     * @param key Lookup key.
     * @param defaultValue Value to return when not found or type mismatch.
     * @return Stored double or defaultValue.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Retrieve double values with defaults
     * double userLat = userStorage.getDouble("user_location_lat", 0.0);
     * double userLng = userStorage.getDouble("user_location_lng", 0.0);
     * double nonExistentDouble = userStorage.getDouble("non_existent_double", -1.0);
     * System.out.println("User location lat: " + userLat);
     * System.out.println("User location lng: " + userLng);
     * System.out.println("Non-existent double: " + nonExistentDouble);
     * }
     * </pre>
     */
    public abstract double getDouble(String key, double defaultValue);

    /**
     * Gets a string value.
     * Returns defaultValue if the key is missing or the stored type is not string.
     * @param key Lookup key.
     * @param defaultValue Value to return when not found or type mismatch.
     * @return Stored string or defaultValue.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Retrieve string values with defaults
     * String userName = userStorage.getString("user_name", "Unknown");
     * String userEmail = userStorage.getString("user_email", "");
     * String nonExistent = userStorage.getString("non_existent_key", "default_value");
     * System.out.println("User name: " + userName);
     * System.out.println("User email: " + userEmail);
     * System.out.println("Non-existent key: " + nonExistent);
     * }
     * </pre>
     */
    public abstract String getString(String key, String defaultValue);

    /**
     * Stores a 32-bit integer value under the key, replacing any existing value.
     * @param key Key to set.
     * @param value Value to store.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Store integer values
     * userStorage.putInt("user_age", 25);
     * userStorage.putInt("login_count", 42);
     * System.out.println("Stored integer values");
     * }
     * </pre>
     */
    public abstract void putInt(String key, int value);

    /**
     * Stores a 64-bit integer value under the key, replacing any existing value.
     * @param key Key to set.
     * @param value Value to store.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Store long values
     * userStorage.putLong("registration_timestamp", 1640995200000L);
     * userStorage.putLong("last_login_timestamp", System.currentTimeMillis());
     * System.out.println("Stored long values");
     * }
     * </pre>
     */
    public abstract void putLong(String key, long value);

    /**
     * Stores a boolean value under the key, replacing any existing value.
     * @param key Key to set.
     * @param value Value to store.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Store boolean values
     * userStorage.putBool("is_premium", true);
     * userStorage.putBool("notifications_enabled", false);
     * System.out.println("Stored boolean values");
     * }
     * </pre>
     */
    public abstract void putBool(String key, boolean value);

    /**
     * Stores a 32-bit floating-point value under the key, replacing any existing value.
     * @param key Key to set.
     * @param value Value to store.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Store float values
     * userStorage.putFloat("user_rating", 4.5f);
     * userStorage.putFloat("temperature", 23.5f);
     * System.out.println("Stored float values");
     * }
     * </pre>
     */
    public abstract void putFloat(String key, float value);

    /**
     * Stores a 64-bit floating-point value under the key, replacing any existing value.
     * @param key Key to set.
     * @param value Value to store.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Store double values
     * userStorage.putDouble("user_location_lat", 55.7558);
     * userStorage.putDouble("user_location_lng", 37.6176);
     * System.out.println("Stored double values");
     * }
     * </pre>
     */
    public abstract void putDouble(String key, double value);

    /**
     * Stores a string value under the key, replacing any existing value.
     * @param key Key to set.
     * @param value Value to store.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Store string values
     * userStorage.putString("user_name", "John Doe");
     * userStorage.putString("user_email", "john.doe@example.com");
     * System.out.println("Stored string values");
     * }
     * </pre>
     */
    public abstract void putString(String key, String value);

    /**
     * Removes a value by key. No-op if the key does not exist.
     * @param key Key to remove.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Remove specific keys
     * userStorage.remove("user_age");
     * userStorage.remove("non_existent_key"); // No-op
     * System.out.println("Removed 'user_age' key");
     * }
     * </pre>
     */
    public abstract void remove(String key);

    /**
     * Removes all entries from the storage.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * // Clear all data
     * userStorage.clear();
     * System.out.println("Cleared all data from user storage");
     * }
     * </pre>
     */
    public abstract void clear();
}
