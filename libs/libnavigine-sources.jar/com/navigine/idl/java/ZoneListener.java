package com.navigine.idl.java;

/**
 * Class provides a callback to be invoked when {@link com.navigine.idl.java.ZoneManager ZoneManager}
 * detects entering/leaving zone events.
 * Referenced from {@link com.navigine.idl.java.ZoneManager ZoneManager}.
 * <p><b>Note:</b> The callback is invoked in the UI thread.</p>
 */
public abstract class ZoneListener {
    /**
     * Called when user handle particular zone event
     * @param zoneEvent handled {@link com.navigine.idl.java.ZoneEvent ZoneEvent}.
     *
     * <p><b>Example:</b></p>
     * <pre>
     * {@code
     * public void onZoneEvent(ZoneEvent zoneEvent) {
     *    System.out.println("Zone event detected");
     *    demonstrateZoneEventUsage(zoneEvent);
     * }
     * }
     * </pre>
     */
    public abstract void onZoneEvent(ZoneEvent zoneEvent);
}
