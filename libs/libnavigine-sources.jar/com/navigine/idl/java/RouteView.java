package com.navigine.idl.java;

import java.util.ArrayList;

public abstract class RouteView {
    public abstract long id();

    public abstract ArrayList<LocationPolyline> geometry();

    public abstract ArrayList<RouteAnnotation> annotations();

    public abstract float length();

    /**
     * Tells if this {@link RouteView} is valid or not. Any other method
     * (except for this one) called on an invalid {@link RouteView} will
     * throw {@link java.lang.RuntimeException}.
     */
    public abstract boolean isValid();
}
