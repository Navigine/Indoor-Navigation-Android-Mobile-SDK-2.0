package com.navigine.idl.java;

/**
 * Enum defining the type of map object.
 * Referenced from {@link com.navigine.idl.java.MapObject MapObject}.
 */
public enum MapObjectType {
    /**
     * Icon.
     * {@link com.navigine.idl.java.IconMapObject IconMapObject}
     */
    ICON,
    /**
     * Polygon.
     * {@link com.navigine.idl.java.PolygonMapObject PolygonMapObject}
     */
    POLYGON,
    /**
     * Polyline.
     * {@link com.navigine.idl.java.PolylineMapObject PolylineMapObject}
     */
    POLYLINE,
    /**
     * DottedPolyline.
     * {@link com.navigine.idl.java.DottedPolylineMapObject DottedPolylineMapObject}
     */
    DOTTED_POLYLINE,
    /**
     * Circle.
     * {@link com.navigine.idl.java.CircleMapObject CircleMapObject}
     */
    CIRCLE,
    /**
     * Model.
     * {@link com.navigine.idl.java.ModelMapObject ModelMapObject}
     */
    MODEL,
    /**
     * Icon cluster.
     * {@link com.navigine.idl.java.ClusterMapObject ClusterMapObject}
     */
    CLUSTER_MAP_OBJECT,
    ;
}
