package com.navigine.model;

import com.navigine.platform.ByteBufferUtils;
import com.navigine.image.ImageProvider;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.util.Log;

import java.lang.Object;
import java.util.UUID;
import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * @hidden
 * Provides the model data.
 */
public abstract class ModelProvider {
    /**
     * Returns the unique identifier for the model. Providers can be cached based on it.
     */
    public abstract String getId();

    /**
     * Returns a model data buffer.
     */
    public abstract ByteBuffer getModel();

    /**
     * Returns an image provider of the model texture.
     */
    public abstract ImageProvider getTexture();

    /**
     * Returns a model provider based on the given data.
     * Supports only OBJ format.
     */
    public static ModelProvider fromByteArray(final byte[] model, final ImageProvider texture) {
        final String id = "model/bytes:" + UUID.randomUUID().toString();
        return new ModelProvider() {
            @Override
            public String getId() { return id; }

            @Override
            public ByteBuffer getModel() {
                return ByteBufferUtils.fromByteArray(model);
            }

            @Override
            public ImageProvider getTexture() {
                return texture;
            }
        };
    }

    /**
     * Returns a model provider based on a given resource.
     * Supports only OBJ format.
     */
    public static ModelProvider fromResource(
            final Context context, final int resourceId, final ImageProvider texture) {
        final Resources resources = context.getResources();
        final String id = "model/resource:" + String.valueOf(resourceId);
        return new ModelProvider() {
            @Override
            public String getId() { return id; }

            @Override
            public ByteBuffer getModel() {
                try {
                    return ByteBufferUtils.fromResource(resources, resourceId);
                } catch (IOException ex) {
                    Log.e("navigine", "Can't load model from resource: " + String.valueOf(resourceId), ex);
                }
                return null;
            }

            @Override
            public ImageProvider getTexture() {
                return texture;
            }
        };
    }

    /**
     * Returns a model provider based on a given asset (from the assets/ directory).
     * Supports only OBJ format.
     */
    public static ModelProvider fromAsset(
            final Context context, final String assetName, final ImageProvider texture) {
        final AssetManager assetManager = context.getAssets();
        final String id = "model/asset:" + assetName;
        return new ModelProvider() {
            @Override
            public String getId() { return id; }

            @Override
            public ByteBuffer getModel() {
                try {
                    return ByteBufferUtils.fromAsset(assetManager, assetName);
                } catch (IOException ex) {
                    Log.e("navigine", "Can't load model from asset: " + assetName, ex);
                }
                return null;
            }

            @Override
            public ImageProvider getTexture() {
                return texture;
            }
        };
    }

    /**
     * Returns a model provider based on a model file from the internal storage.
     * Supports only OBJ format.
     */
    public static ModelProvider fromFile(final String fileName, final ImageProvider texture) {
        final String id = "model/file:" + fileName;
        return new ModelProvider() {
            @Override
            public String getId() { return id; }

            @Override
            public ByteBuffer getModel() {
                try {
                    return ByteBufferUtils.fromFile(fileName);
                } catch (IOException ex) {
                    Log.e("navigine", "Can't load model from file: " + fileName, ex);
                }
                return null;
            }

            @Override
            public ImageProvider getTexture() {
                return texture;
            }
        };
    }
}
