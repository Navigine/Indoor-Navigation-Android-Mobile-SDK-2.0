package com.navigine.network;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import android.util.Log;
import android.net.http.X509TrustManagerExtensions;

public final class CertificateVerifier {
    static public boolean verify(byte[][] nativeCertChain) {
        X509Certificate[] certChain = decodeChain(nativeCertChain);
        if (certChain == null)
            return false;

        X509TrustManager tm = getTrustManager();
        if (tm == null)
            return false;

        try {
            X509TrustManagerExtensions trustManager = new X509TrustManagerExtensions(tm);
            trustManager.checkServerTrusted(certChain, "TLS", "");
        } catch (CertificateException e) {
            Log.e("navigine.sdk", "Certificate is not valid: " + e.getMessage());
            return false;
        } catch (IllegalArgumentException e) {
            Log.e("navigine.sdk", "IllegalArgumentException: " + e.getMessage());
            return false;
        }
        return true;
    }

    static private X509Certificate[] decodeChain(byte[][] nativeCertChain) {
        try {
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            X509Certificate[] certChain = new X509Certificate[nativeCertChain.length];
            for(int i = 0; i < nativeCertChain.length; i++) {
                certChain[i] = (X509Certificate)cf.generateCertificate(
                    new ByteArrayInputStream(nativeCertChain[i]));
            }
            return certChain;
        } catch (CertificateException e) {
            Log.e("navigine.sdk", "Could not decode certificate");
            return null;
        }
    }

    static private X509TrustManager getTrustManager() {
        TrustManagerFactory factory;

        try {
            factory = TrustManagerFactory.getInstance(
                TrustManagerFactory.getDefaultAlgorithm());
            factory.init((KeyStore)null);
        } catch (NoSuchAlgorithmException e) {
            Log.e("navigine.sdk", "Algorithm is not supported");
            return null;
        } catch (KeyStoreException e) {
            Log.e("navigine.sdk", "Could not initialize keystore");
            return null;
        }

        TrustManager[] trustManagers = factory.getTrustManagers();
        if (trustManagers == null)
            return null;

        for (int i = 0; i < trustManagers.length; ++i)
            if (trustManagers[i] instanceof X509TrustManager)
                return (X509TrustManager)trustManagers[i];

        Log.e("navigine.sdk", "X509TrustManager is missing");
        return null;
    }
}
